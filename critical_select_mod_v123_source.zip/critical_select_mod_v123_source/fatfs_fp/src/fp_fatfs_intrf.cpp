#include "fp_fatfs_intrf.h"
#ifdef __GNUC__
//#	define _FILE_OFFSET_BITS 64		//required by ftello(), makes off_t 64-bit size.
#	include <unistd.h>   //fsync()
#	include <sys/stat.h>
#	include <sys/types.h>
#endif
#include <limits>       //std::numeric_limits
#include <assert.h>
#include "ff.h"         // FatFs main header.
#include "diskio.h"		// Declarations of disk functions
//#define NOMINMAX
//#include <windows.h>
#include "fp_fat32.h"

static_assert( sizeof(WCHAR)==2, "" );
static_assert( sizeof(TCHAR)==1, "" );
static_assert( sizeof(BYTE)==1, "" );

// as extern in a header.
FpData* Fpd = new FpData;

int     FpGetNextFreeFsIdent();
FpDisk* FpFindOpenedDisk( int pdrv2 );


//-----------------------------------------------------------------------
// Get Drive Status
//-----------------------------------------------------------------------

DSTATUS disk_status (
	BYTE pdrv		// Physical drive nmuber to identify the drive
)
{
	//assert(!"N.I. [vLawDCU]");
	//DSTATUS stat = STA_NOINIT;
	return 0;
}

//-----------------------------------------------------------------------
// Inidialize a Drive
//-----------------------------------------------------------------------

DSTATUS disk_initialize (
	BYTE pdrv				// Physical drive nmuber to identify the drive
)
{
	//Fpd->uCurrentDisk_
	//printf("FPA: disk_initialize(%d) [9WNVAJIy]\n", (int)pdrv );
	//return STA_NOINIT;
	return 0;
}

#ifdef FP_WINXX

bool fu_WinapiSeek( HANDLE hFile, uint64_t pos2 )
{
	static_assert( sizeof(LONG) == 4, "" );
	LONG nPos     = LONG( pos2 & 0xFFFFFFFF );
	LONG nPosHigh = LONG( pos2 >> 32 );
	if( 0xFFFFFFFF == SetFilePointer( hFile, nPos, &nPosHigh, FILE_BEGIN ) ){
		return 0;
	}
	return 1;
}
#endif
//-----------------------------------------------------------------------
// Read Sector(s)
//-----------------------------------------------------------------------

DRESULT disk_read (
	BYTE pdrv,		// Physical drive nmuber to identify the drive
	BYTE *buff,		// Data buffer to store read data
	LBA_t nSector,	// Start sector in LBA
	UINT nCount		// Number of sectors to read
)
{
	//printf("FPA: disk_read(%d,,%u,%u) [c8gpqExB]\n",
	//		(int)pdrv, (uint32_t)nSector, (uint32_t)nCount );
	//
	//const FpDisk* dsk = FpFindOpenedDisk( pdrv );
	const FpDisk* dsk = FpFindOpenedDisk( Fpd->nCurrentDisk );
	assert( dsk );
	assert( dsk->uSectorSize > 0 );
	const uint64_t bgn = uint64_t(dsk->uSectorSize) * nSector;
	const uint64_t endd = bgn + uint64_t(dsk->uSectorSize) * nCount;
	const uint64_t numread = endd - bgn;
#	ifdef FP_WINXX
		assert( dsk->handle2 );
		assert( dsk->handle2 != INVALID_HANDLE_VALUE );
		if( !fu_WinapiSeek( dsk->handle2, bgn ) ){
			return RES_ERROR;
		}
		if( numread ){
			DWORD nReadd = 0;
			//uint32_t,DWORD
			static_assert( sizeof(uint32_t) == sizeof(DWORD), "" );
			//NOMINMAX
			assert( numread <= uint64_t( (std::numeric_limits<uint32_t>::max)() ) );
			if( !ReadFile( dsk->handle2, buff, numread, &nReadd, nullptr ) ){
				return RES_ERROR;
			}
			if( uint64_t(nReadd) != numread ){
				return RES_ERROR;
			}
		}
#	else
		assert( dsk->fph2 );
		if( !FpSeek32( dsk->fph2, bgn ) ){
			//printf("[7B5LXo0]\n");
			return RES_ERROR;
		}
		if( 1 != std::fread( buff, numread, 1, dsk->fph2 ) ){
			//printf("[GuT7vCC]\n");
			return RES_ERROR;
		}
#	endif
	return RES_OK;
}

//-----------------------------------------------------------------------
// Write Sector(s)
//-----------------------------------------------------------------------

#if FF_FS_READONLY == 0   //[wMO2h39Ya] {

DRESULT disk_write (
	BYTE pdrv,			// Physical drive nmuber to identify the drive
	const BYTE *buff,	// Data to be written
	LBA_t nSector,		// Start sector in LBA
	UINT nCount			// Number of sectors to write
)
{
	//printf("FPA: disk_write(%d,,%u,%u) [v8gp4qj4x]\n",
	//		(int)pdrv, (uint32_t)nSector, (uint32_t)nCount );
	//const FpDisk* dsk = FpFindOpenedDisk( pdrv );
	const FpDisk* dsk = FpFindOpenedDisk( Fpd->nCurrentDisk );
	assert( dsk );
	assert( dsk->uSectorSize > 0 );
	const uint64_t bgn = uint64_t(dsk->uSectorSize) * nSector;
	const uint64_t endd = bgn + uint64_t(dsk->uSectorSize) * nCount;
	const uint64_t numbytes = endd - bgn;
#	ifdef FP_WINXX
		assert( dsk->handle2 );
		assert( dsk->handle2 != INVALID_HANDLE_VALUE );
		if( !fu_WinapiSeek( dsk->handle2, bgn ) ){
			//printf("ERROR: [94kck3lgneopke]\n");
			return RES_ERROR;
		}
		if( numbytes ){
			DWORD nWritten = 0;
			static_assert( sizeof(uint32_t) == sizeof(DWORD), "" );
			//NOMINMAX
			assert( numbytes <= uint64_t( (std::numeric_limits<uint32_t>::max)() ) );
			if( !WriteFile( dsk->handle2, buff, numbytes, &nWritten, nullptr ) ){
				//printf("ERROR: [%s] [95klnoklg0]\n", fu_WinapiGetLastError().c_str() );
				return RES_ERROR;
			}
			if( uint64_t(nWritten) != numbytes ){
				//printf("ERROR: [96rk402kcge]\n");
				return RES_ERROR;
			}
		}
#	else
		assert( dsk->fph2 );
		if( !FpSeek32( dsk->fph2, bgn ) ){
			//printf("FPA: ERROR: FpSeek32\n");
			return RES_ERROR;
		}
		if( 1 != std::fwrite( buff, numbytes, 1, dsk->fph2 ) ){
			//printf("FPA: ERROR: std::fwrite\n");
			return RES_ERROR;
		}
		//fflush( dsk->fph2 );
#	endif
	return RES_OK;
}

#endif   // [wMO2h39Ya] }

//-----------------------------------------------------------------------
// Miscellaneous Functions
//-----------------------------------------------------------------------

DRESULT disk_ioctl (
	BYTE pdrv,		// Physical drive nmuber (0..)
	BYTE cmd,		// Control code
	void *buff		// Buffer to send/receive control data
)
{
	//printf("FPA: disk_ioctl() pdrv:%d, cmd:%d\n", (int)pdrv, (int)cmd );
	//const FpDisk* dsk = FpFindOpenedDisk( pdrv );
	const FpDisk* dsk = FpFindOpenedDisk( Fpd->nCurrentDisk );
	assert( dsk );
	//CTRL_SYNC         0   // Complete pending write process (needed at FF_FS_READONLY == 0)
	//GET_SECTOR_COUNT  1   // Get media size (needed at FF_USE_MKFS == 1)
	//GET_SECTOR_SIZE   2   // Get sector size (needed at FF_MAX_SS != FF_MIN_SS)
	//GET_BLOCK_SIZE    3   // Get erase block size (needed at FF_USE_MKFS == 1)
	//CTRL_TRIM         4   // Inform device that the data on the block of sectors is no longer used (needed at FF_USE_TRIM == 1)
	if( cmd == GET_SECTOR_COUNT ){
		// GET_SECTOR_COUNT is used by: create_partition() and f_mkfs()
		//assert(!"disk_ioctl() - GET_SECTOR_COUNT not implemented [9qBlzrX]");
		assert( dsk->uSectorSize );
		assert( dsk->uFileSize );
		LBA_t* lpRslt = reinterpret_cast<LBA_t*>(buff);
		*lpRslt = LBA_t( dsk->uFileSize / dsk->uSectorSize );
		return RES_OK;
	}else if( cmd == GET_BLOCK_SIZE ){   // f_mkfs()
		//assert(!"disk_ioctl() - GET_BLOCK_SIZE Not implemented [kaUZ6RZ]");
		DWORD* lpDw = reinterpret_cast<DWORD*>(buff);
		//-*lpDw = FU_CommonBlockSize;
		//*lpDw = dsk->uSectorSize;
		*lpDw = dsk->uSectorSize ;// * 32;
		return RES_OK;
	}else if( cmd == GET_SECTOR_SIZE ){
		WORD* lpWrd = reinterpret_cast<WORD*>(buff);
		*lpWrd = static_cast<WORD>( dsk->uSectorSize );
		//printf("disk_ioctl() - GET_SECTOR_SIZE ret: %d\n", (int)(*lpWrd) );
		return RES_OK;
	}else if( cmd == CTRL_SYNC ){
		//printf("disk_ioctl() - CTRL_SYNC\n");
		// fflush (for FILE*),
		// ref: https://stackoverflow.com/a/13358458
		/*
			https://stackoverflow.com/a/13358458

			fflush (for FILE*), std::flush (for IOStream) to force your program to send to the OS.
			POSIX has
				sync(2) to ask to schedule writing its buffers, but can return before the writing is done (Linux is waiting that the data is send to the hardware before returning).
				fsync(2) which is guaranteed to wait for the data to be send to the hardware, but needs a file descriptor (you can get one from a FILE* with fileno(3), I know of no standard way to get one from an IOStream).
				O_SYNC as a flag to open(2).
			In all cases, the hardware may have it's own buffers (but if it has control on it, a good implementation will try to flush them also and ISTR that some disks are using capacitors so that they are able to flush whatever happens to the power) and network file systems have their own caveat.
		*/
		/*
			https://stackoverflow.com/a/13358691

			You can use fsync()/fdatasync() to force(Note 1) the data onto the storage. Those requres a file descriptor, as given by e.g. open(). The linux manpage have more linux specific info, particularly on the difference of fsync and fdatasync.
			If you don't use file desciptors directly, many abstractions will contain internal buffers residing in your process.
			e.g. if you use a FILE*, you first have to flush the data out of your application.
				//... open and write data to a FILE *myfile
				fflush(myfile);
				fsync(fileno(myfile));
			Note 1: These calls force the OS to ensure that any data in any OS cache is written to the drive, and the drive acknowledges that fact. Many hard-drives lie to the OS about this, and might stuff the data in cache memory on the drive.
		*/
#		ifdef FP_WINXX
			//assert( dsk->handle2 );
			assert( dsk->fph2 );
			if( std::fflush( dsk->fph2 ) ){	//if error.
				return RES_ERROR;
			}
#		endif
#		ifdef FP_UNIX
			assert( dsk->fph2 );
			if( fsync( fileno( dsk->fph2 ) ) ){
				return RES_ERROR;
			}
#		endif
		return RES_OK;
	}
	printf("cmd:%d\n", (int)cmd );
	assert(!"Not meant to be reached [V0ygeyV]");
	return RES_PARERR;
}

DWORD get_fattime( void )
{
	//assert(!"get_fattime() - N.I. [ueWoJ2i]");
	return 0;
}
const char* FpGetAnsiUppercaseCharacters()
{
	static const char* szAlnumUc = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	return szAlnumUc;
}
std::string FpToLower( const char* inp )
{
	std::string outp = inp;
	const size_t num = outp.size();
	const char* upcse = FpGetAnsiUppercaseCharacters();
	for( size_t i=0; i<num; i++ ){
		if( !!strchr( upcse, outp[i] ) ){
			outp[i] = outp[i] + ('a' - 'A');
		}
	}
	return outp;
}
/// Case insensitive string comparision. Ie. CI version of strcmp().
int FpCmpi( const char* sz2, const char* sz3, int len )
{
	std::string sr2, sr3;
	if( len == -1 ){
		if( !!strpbrk( sz2, FpGetAnsiUppercaseCharacters() ) ){
			sr2 = FpToLower( sz2 );
			sz2 = sr2.c_str();
		}
		if( !!strpbrk( sz3, FpGetAnsiUppercaseCharacters() ) ){
			sr3 = FpToLower( sz3 );
			sz3 = sr3.c_str();
		}
		return strcmp( sz2, sz3 );
	}else{
		sr2.assign( sz2, len );
		sr3.assign( sz3, len );
		return FpCmpi( sr2.c_str(), sr3.c_str(), -1 );
	}
}
bool FpSetDisk( const char* szDisk )
{
	assert( szDisk );
	assert( *szDisk );
	int nDsk = std::atoi( szDisk );
	assert( nDsk || *szDisk == '0' );
	Fpd->nCurrentDisk = nDsk;
	return 1L;
}
FpDisk* FpFindOpenedDisk( int pdrv2 )
{
	auto endd = Fpd->FpOpenedDisks.end();
	auto ir2 = std::find_if( Fpd->FpOpenedDisks.begin(), endd,
		[&]( const FpDisk& a )->bool{
			return a.nFsIdent == pdrv2;
		});
	if( ir2 == endd ){
		return nullptr;
	}
	return &(*ir2);
}
std::string FpCnvFatFsErrorCodeToStr( int nErrorCode, int nResultMode )
{
	using LocalElemTy = std::tuple<int,const char*,const char*>;
	static const std::vector< LocalElemTy > aCodes = {
		{FR_OK,"FR_OK","Succeeded",},
		{FR_DISK_ERR,"FR_DISK_ERR","A hard error occurred in the low level disk I/O layer",},
		{FR_INT_ERR,"FR_INT_ERR","Assertion failed",},
		{FR_NOT_READY,"FR_NOT_READY","The physical drive cannot work",},
		{FR_NO_FILE,"FR_NO_FILE","Could not find the file",},
		{FR_NO_PATH,"FR_NO_PATH","Could not find the path",},
		{FR_INVALID_NAME,"FR_INVALID_NAME","The path name format is invalid",},
		{FR_DENIED,"FR_DENIED","Access denied due to prohibited access or directory full",},
		{FR_EXIST,"FR_EXIST","Access denied due to prohibited access",},
		{FR_INVALID_OBJECT,"FR_INVALID_OBJECT","The file/directory object is invalid",},
		{FR_WRITE_PROTECTED,"FR_WRITE_PROTECTED","The physical drive is write protected",},
		{FR_INVALID_DRIVE,"FR_INVALID_DRIVE","The logical drive number is invalid",},
		{FR_NOT_ENABLED,"FR_NOT_ENABLED","The volume has no work area",},
		{FR_NO_FILESYSTEM,"FR_NO_FILESYSTEM","There is no valid FAT volume",},
		{FR_MKFS_ABORTED,"FR_MKFS_ABORTED","The f_mkfs() aborted due to any problem",},
		{FR_TIMEOUT,"FR_TIMEOUT","Could not get a grant to access the volume within defined period",},
		{FR_LOCKED,"FR_LOCKED","The operation is rejected according to the file sharing policy",},
		{FR_NOT_ENOUGH_CORE,"FR_NOT_ENOUGH_CORE","LFN working buffer could not be allocated",},
		{FR_TOO_MANY_OPEN_FILES,"FR_TOO_MANY_OPEN_FILES","Number of open files > FF_FS_LOCK",},
		{FR_INVALID_PARAMETER,"FR_INVALID_PARAMETER","Given parameter is invalid",},
	};
	auto endd = aCodes.end();
	auto ir2 = std::find_if( aCodes.begin(), endd, [&]( const LocalElemTy& a )->bool{
		return std::get<0>(a) == nErrorCode;
	});
	if( ir2 != endd ){
		if( nResultMode == 0 ){
			return std::string( std::get<1>(*ir2) );
		}else if( nResultMode == 1 ){
			return std::string( std::get<2>(*ir2) );
		}else if( nResultMode == 2 ){
			char bfr[256];
			std::snprintf( bfr, sizeof(bfr), "%s(%d) %s",
					std::get<1>(*ir2),
					std::get<0>(*ir2),
					std::get<2>(*ir2) );
			return bfr;
		}else{
			assert(0);
		}
	}
	return "";
}
std::string FpAddFsDisk( std::FILE* guid, uint64_t mDiskSize2 )
{
	int fsid2 = FpGetNextFreeFsIdent();
	assert( fsid2 >= 0 );
	//assert( fsid2 <= 255 );
	char bfr2[256];
	std::snprintf( bfr2, sizeof(bfr2), "%d:/", fsid2 );
	FpDisk dsk2;
	dsk2.nFsIdent    = static_cast<uint8_t>( fsid2 );
	dsk2.uSectorSize = FP_CommonSectorSize;
	dsk2.fph2        = guid;
	dsk2.uFileSize   = mDiskSize2;
	Fpd->FpOpenedDisks.push_back( dsk2 );
	return bfr2;
}
bool FpRemoveFsDisk( std::FILE* guid )
{
	auto ir2 = std::find_if( Fpd->FpOpenedDisks.begin(), Fpd->FpOpenedDisks.end(),
		[&guid]( const FpDisk& a )->bool{
			return guid == a.fph2;
	});
	if( ir2 == Fpd->FpOpenedDisks.end() ){
		return 0L;
	}
	Fpd->FpOpenedDisks.erase( ir2 );
	return 1L;
}
int FpGetNextFreeFsIdent()
{
/*	if( Fpd->FpOpenedDisks.empty() ){
		return 0;
	}
	int a = 0, b = 0;
	const auto endd = Fpd->FpOpenedDisks.end();
	const auto bgn = Fpd->FpOpenedDisks.begin();

	for( auto ir2 = bgn; ir2 != endd; ++ir2 ){
		for( auto ir3 = bgn; ir3 != endd; ++ir3 ){
			if( ir2 != ir3 ){
				//ir2->nFsIdent == ir3->nFsIdent
				;
			}
		}
	}
	return 0;//*/
	return Fpd->nNextDiskId++;//ir2->nFsIdent + 1;
}
std::string FpTrimStr( const std::string& inp, const std::string& charset2, const char* flags2, int limit2 )
{
	std::string outp;
	assert( limit2 >= -1 );
	int nCount = 0, nRCount = 0;
	bool bLeft = 1, bRight = 1;
	if( flags2 && *flags2 ){
		bLeft = !!strchr( flags2, 'L' );
		bRight = !!strchr( flags2, 'R' );
	}
	if( bLeft ){
		std::string::const_iterator a;
		for( a = inp.begin(); a != inp.end() && limit2 != nCount; ++a, nCount++ ){
			if( charset2.find( *a ) == std::string::npos )
				break;
		}
	}
	if( bRight ){
		std::string::const_reverse_iterator b;
		for( b = inp.rbegin(); b != inp.rend() && limit2 != nRCount; ++b, nRCount++ ){
			if( charset2.find( *b ) == std::string::npos )
				break;
		}
	}
	size_t nChop = static_cast<size_t>( nCount + nRCount );
	//assert( nChop <= inp.size() );
	if( nChop >= inp.size() ){
		return "";
	}
	outp = inp.substr( nCount, inp.size() - nChop );
	return outp;
}
std::string
FpStrReplace( std::string str, const std::string& from2,
			const std::string& to2, int nLimit, int* ouCount )
{
	int dmy0;
	ouCount = ( ouCount ? ouCount : &dmy0 );
	*ouCount = 0;
	assert( !from2.empty() );
	assert( nLimit >= -1 );
    size_t start_pos = 0;
    while( nLimit-- && ( start_pos = str.find( from2, start_pos ) ) != std::string::npos ){
        str.replace( start_pos, from2.length(), to2 );
        start_pos += to2.length(); // Handles case where 'to2' is a substring of 'from2'
        *ouCount += 1;
    }
    return str;
}
/// Given input path name splits it into dirname and basename pair.
/// Eg. "c:/temp/a.txt" ---> "c:/temp" and "a.txt".
/// Eg. "./data/x.txt"  ---> "./data"  and "x.txt".
/// Eg. "b.txt"         ---> ""        and "b.txt".
FpPair<std::string,std::string>
FpSplitPath( std::string inp2 )
{
	inp2 = FpTrimStr( inp2, "\\/", "R", -1 );
	{
		const char* inp = inp2.c_str();
		const char* sz2 = std::strrchr( inp, '/' );
		const char* sz3 = std::strrchr( inp, '\\' );
		//const char* maxval_ = std::max<const char*>( sz2, sz3 );
		//const char* maxval_ = (reinterpret_cast<const char*>(
		//			FpMax<size_t>( (size_t)sz2, (size_t)sz3 ) ));
		const char* maxval_ = FpMax<const char*>( sz2, sz3 );
		if( sz2 = maxval_ ){
			std::string dirname2( inp, sz2-inp );
			return { dirname2, &sz2[1] };
		}
		return {"", inp,};
	}
}
void FpStrExplode3( const char* inp,
					std::function<void(const char*, int len)> calbNewPart,
					const std::vector<std::string> lsGlueItems2,
					int nLimitSplitPoints, const char* szTrimLR )
{
	assert( !lsGlueItems2.empty() );
	const char* sz2 = inp;
	for( ; nLimitSplitPoints; --nLimitSplitPoints ){
		const char *sz3 = 0;
		int nLenGlue = -1;
		{
			const char* sz4;
			for( auto glue2 : lsGlueItems2 ){
				if( (sz4 = std::strstr( sz2, glue2.c_str() ) ) ){
					if( nLenGlue == -1 || sz4 < sz3 ){
						sz3 = sz4;
						nLenGlue = (int) glue2.size();
					}
				}
			}
		}
		if(!sz3)
			break;
		assert( nLenGlue != -1 );
		assert( sz2 <= sz3 );
		if( sz2 <= sz3 ){
			std::string str( sz2, sz3-sz2 );
			if( szTrimLR ){
				//str = hxdw_TrimStr( str, szTrimLR, "LR", -1 );
				str = FpTrimStr( str, szTrimLR, "LR", -1 );
			}
			calbNewPart( str.c_str(), (int) str.size() );
		}
		sz2 = sz3 + nLenGlue;
	}
	if( sz2 ){
		std::string str( sz2 );
		if( szTrimLR )
			str = FpTrimStr( str, szTrimLR, "LR", -1 );
		calbNewPart( str.c_str(), (int) str.size() );
	}
}
/**
	String explode into parts.
	\param nLimitSplitPoints - limit numer of splits, -1: no limit. eg. if set to 2, yelds 3 output parts.
	\param flags3 - optional, flags as c-string.
					'e': remove empty.
					't': remove tail empty.
*/
bool FpStrExplode2( const char* inp, std::vector<std::string>& parts2,
					const std::vector<std::string> lsGlueItems,
					int nLimitSplitPoints, const char* szTrimLR,
					const char* flags3 )
{
	assert( !lsGlueItems.empty() );
	FpStrExplode3( inp, [&]( const char* sz2, int len ){
		parts2.push_back( std::string( sz2, len ) );
	}, lsGlueItems, nLimitSplitPoints, szTrimLR );
	{	// process flags.
		const bool bRemoveEmpty = !!std::strchr( flags3, 'e');
		if( bRemoveEmpty ){
			auto ir2 = parts2.begin();
			for( ; ir2 != parts2.end(); ){
				if( ir2->empty() ){
					ir2 = parts2.erase( ir2 );
				}else{
					++ir2;
				}
			}
		}
		const bool bRmvTailEmpty = !!std::strchr( flags3, 't');
		if( bRmvTailEmpty ){
			int ii2 = (((int)parts2.size()) - 1 );
			for( ; ii2 > -1 && parts2[ii2].empty(); ii2-- ){
				auto ir3 = parts2.begin();
				std::advance( ir3, ii2 );
				parts2.erase( ir3 );
			}
		}
	}
	return 1;
}
/// Set file position.
/// hf_Seek64 -> FpSeek32
bool FpSeek32( FILE* hf, uint64_t position2 )
{
#	ifdef _MSC_VER
		int retv = fseek( hf, position2, SEEK_SET );
		if( retv )
			return 0;
	//	fseek( hf, 0, SEEK_SET );
	//	int fd = _fileno( hf );  //fileno
	//	if( fd == -1 )
	//		return 0;
	//	int64_t retv = _lseeki64( fd, (int64_t)position2, SEEK_SET );
	//	if( -1 == retv )
	//		return 0;
	//	if( position2 < 4000000000 ){
	//		uint32_t pos3 = ftell( hf );
	//		//assert( pos3 == position2 );
	//		if( pos3 != position2 )
	//			return 0;
	//	}
		return 1;
#	elif defined(__GNUC__)
		//
		// IMPORTANT:
		// Must use  fseeko() and ftello() as pairs and not other, fe. lseek64()
		// or fseek(). Otherwise there will be errorous stream pos movement
		// when using fread() and fwrite().
		//
		//assert( sizeof(off_t) >= 8 );
		assert( position2 <= 0xFFFFFFFF );
		//static_assert( sizeof(off_t) >= 8, "" );
		off_t pos3 = position2;
		off_t rs2 = fseeko( hf, pos3, SEEK_SET ); // --> ftello()
		//off_t rs2 = _lseeki64( fileno(hf), pos3, SEEK_SET );
		//off_t rs2 = _lseeki64( fileno(hf), position2, SEEK_SET );
		return !rs2;
#	else
		//hf_assert(!"Unknown platform");
		#error "Unknown platform [TPklSuP]"
		return 0;
#	endif
}
/// Get file size 64-bit compatible (only on MSVC).
/// hf_GetFileSize64
uint64_t FpGetFileSize32( FILE* hf4 )
{
	//_CRTIMP __int64 __cdecl _lseeki64(int, __int64, int);
	//_CRTIMP __int64 __cdecl _telli64(int);
	if( !hf4 ){
		return 0;
	}
#	ifdef _MSC_VER
		//const long oldpos = ftell( hf4 );
		if( fseek( hf4, 0, SEEK_END ) ){
			return 0;
		}
		const long endpos = ftell( hf4 );
		//if( oldpos >= 0 ){
		//	fseek( hf4, oldpos, SEEK_SET );
		//}
		return ( endpos >= 0 ? endpos : 0 );

	/*	fseek( hf4, 0, SEEK_SET );
		int fd = _fileno( hf4 );
		if( fd == -1 )
			return 0;
		if( -1 == _lseeki64( fd, 0, SEEK_END ) )
			return 0;
		int64_t retvSize = _telli64( fd );
		return ( retvSize == -1 ? 0 : retvSize );//*/
#	elif defined(__GNUC__)
		//#define _FILE_OFFSET_BITS 64
		//hf_assert( sizeof(off_t) >= 8 );
		fseeko( hf4, 0, SEEK_END );
		off_t retvPos = ftello( hf4 );
		return retvPos;
#	else
		hf_assert(0);
		return 0;
#	endif
}



