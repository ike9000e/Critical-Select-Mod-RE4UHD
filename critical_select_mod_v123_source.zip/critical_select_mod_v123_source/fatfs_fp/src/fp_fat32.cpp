#include "fp_fat32.h"
#include <assert.h>
#include <memory>   //shared_ptr
#include "ff.h"         // FatFs main header.
#include "fp_fatfs_intrf.h"
//#include <random>   //srand()
// /Zi
// /Z7

struct FpDiskImage::FATFS : public ::FATFS {};

FpDiskImage::FpDiskImage( const char* flags2 )
{
	flags2 = ( flags2 ? flags2 : "" );
	//printf
	mShowStdErs = !!strchr( flags2, 'e');
	assert( !mFatFs2 );
	mFatFs2 = new FATFS;
	memset( mFatFs2, 0, sizeof(FATFS) );
}
FpDiskImage::~FpDiskImage()
{
	safeClose();
	{
		assert( mFatFs2 );
		std::free( mFatFs2 );
		mFatFs2 = nullptr;
	}
}
bool FpDiskImage::safeClose()
{
	bool bSuccess = 1L;
	if( !mMountedName.empty() ){
		// un-mount
		//FRESULT rs3 = f_mount( nullptr, mMountedName.c_str(), 0 );   // 3rd param is 0 - un-mount.
		FRESULT rs3 = f_mount( nullptr, "0:/", 0 );   // 3rd param is 0 - un-mount.
		if( rs3 ){
			std::string err = FpCnvFatFsErrorCodeToStr( rs3, 2 );
			if( mShowStdErs )
				printf("FPA: ERROR: Un-mount failed [%s] [g70quAL]\n", err.c_str() );
			bSuccess = 0L;
		}
		mMountedName = "";
	}
	if( mFp2 ){
		FpRemoveFsDisk( mFp2 );
		fclose( mFp2 );
		mFp2 = nullptr;
	}
	mImageFileName = "";
	mDiskSize = 0;
	return bSuccess;
}
bool FpDiskImage::
openDiskImage( const char* szLocalPathFileName, const char* flags2 )
{
	assert( mFatFs2 );
	assert( mMountedName.empty() );
	assert( szLocalPathFileName );
	assert( *szLocalPathFileName );
	flags2 = ((flags2 && *flags2) ? flags2 : "");
	mImageFileName = szLocalPathFileName;
	const bool bMount = !strchr( flags2, 'q' );
	assert( !mFp2 );
	// "r+" = Open a file for read/write
	mFp2 = fopen( szLocalPathFileName, "r+b" );
	if( !mFp2 ){
		if( mShowStdErs )
			printf("FPA: ERROR: Failed opening local disk file [5NPfDq]\n" );
		return 0L;
	}
	assert( !mDiskSize );
	//mDiskSize = hf_GetFileSize64( mFp2 );
	mDiskSize = FpGetFileSize32( mFp2 );
	if( !mDiskSize ){
		if( mShowStdErs )
			printf("FPA: ERROR: Empty local disk file, 0-size [IMUY00C]\n" );
		safeClose();
		return 0L;
	}
	mMountedName = FpAddFsDisk( mFp2, mDiskSize );
	assert( !mMountedName.empty() );
	FpSetDisk( mMountedName.c_str() );
	if( bMount ){
		//FRESULT rs2 = f_mount( mFatFs2, mMountedName.c_str(), 1 );
		FRESULT rs2 = f_mount( mFatFs2, "0:/", 1 );
		if( rs2 != FR_OK ){
			std::string err = FpCnvFatFsErrorCodeToStr( rs2, 2 );
			if( mShowStdErs )
				printf("FPA: ERROR: Mounting failed [%s] [t272Q3]\n", err.c_str() );
			mMountedName = "";
			safeClose();
			return 0L;
		}
	}
	//FpSetDisk( mMountedName.c_str() );
	return 1L;
}
bool FpDiskImage::closeDiskImage()
{
	FpSetDisk( mMountedName.c_str() );
	if( !mFp2 ){
		if( mShowStdErs )
			printf("FPA: ERROR: No file opened [bhXnqUh]\n");
		return 0L;
	}
	assert( !mMountedName.empty() );
	safeClose();
	return 1L;
}
bool FpDiskImage::isDiskImageOpened()const
{
	return !!mFp2;
}
/**
	Creates filesystem on the opened disk image.
	Requires the disc image to be opened without
	mounting - the "q" flag on the openDiskImage() call.

	Minimum image file sizes tested given filesystem:
	- FAT16: 524288 B
	- FAT32: 32 MiB

	\param flags2 - flags as c-string:
			f: creates FAT16 filesystem.
			F: creates FAT32 filesystem.
*/
bool FpDiskImage::mkfs2( const char* flags2 )
{
	assert( !mMountedName.empty() );
	FpSetDisk( mMountedName.c_str() );
	char bfr[FF_MAX_SS];  //FF_MAX_SS=4096
	bool bFat32 = !!strchr( flags2, 'F' );

	MKFS_PARM mkfp;
	memset( &mkfp, 0, sizeof(MKFS_PARM) );
	mkfp.fmt = (bFat32 ? FM_FAT32 : FM_FAT);  //FM_FAT32,FM_FAT
	mkfp.n_fat = 1;
	mkfp.align = 0;
	mkfp.n_root = 0;
	mkfp.au_size = 0;
	FRESULT rs2 = f_mkfs( mMountedName.c_str(), &mkfp, bfr, sizeof(bfr) );
	if( rs2 != FR_OK ){
		std::string err = FpCnvFatFsErrorCodeToStr( rs2, 2 );
		if( mShowStdErs )
			printf("FPA: ERROR: f_mkfs failed [%s]\n", err.c_str() );
		return 0L;
	}
	return 1L;
}
std::string FpDiskImage::fixAnyPathTokens( std::string pathname )
{
	std::string outp;
	outp = FpStrReplace( pathname, "\\", "/", -1, nullptr );
	outp = FpTrimStr( outp, "/", "LR", -1 );
	return outp;
}
bool FpDiskImage::isWithPathPart( std::string pathname )
{
	const char* sz2 = std::strrchr( pathname.c_str(), '/' );
	const char* sz3 = std::strrchr( pathname.c_str(), '\\' );
	return sz2 || sz3;
}
/**
	Creates virtual file and allocates its bytes.
	\param fname - file name, on virtual dist, possibly with the path part.
	\param fsize2 - file size to allocate, initially.
	\param flags2 - Flags as C-string:
					z : zero fill.
					f : 0xFF fill.
					d : create path part if needed. ie. creates
						any missing parent directories.
*/
bool FpDiskImage::mkVFile( std::string fname, uint64_t fsize2, const char* flags2 )
{
	FpSetDisk( mMountedName.c_str() );
	fname = fixAnyPathTokens( fname );
	flags2 = flags2 ? flags2 : "";
	bool bZeroFill = !!strchr( flags2, 'z' );
	bool bFxxFill  = !!strchr( flags2, 'f' );
	bool bNkDirsIf = !!strchr( flags2, 'd' );
	if( bNkDirsIf ){
		if( !createDirsIfNeeded( fname ) ){
			return 0L;
		}
	}
	FIL fil2;
	memset( &fil2, 0, sizeof(FIL) );
	FRESULT rs2; //FA_CREATE_NEW,FA_CREATE_ALWAYS
	rs2 = f_open( &fil2, fname.c_str(), FA_WRITE|FA_READ|FA_CREATE_ALWAYS );
	if( rs2 != FR_OK ){
		std::string err = FpCnvFatFsErrorCodeToStr( rs2, 2 );
		if( mShowStdErs ){
			printf("FPA: ERROR: f_open failed [%s] [dluZJa]\n", err.c_str() );
			printf("     Path:[%s]\n", fname.c_str() );
		}
		return 0L;
	}
	rs2 = f_expand( &fil2, fsize2, 1 );
	if( rs2 != FR_OK ){
		std::string err = FpCnvFatFsErrorCodeToStr( rs2, 2 );
		if( mShowStdErs )
			printf("FPA: ERROR: f_expand failed [%s] [DdIMOHq]\n", err.c_str() );
		return 0L;
	}
	if( bZeroFill || bFxxFill ){
		f_lseek( &fil2, 0 );
		UINT dmy0;
		const uint64_t bufsize = 65536;
		char bfr3[bufsize];
		memset( bfr3, (bZeroFill ? 0 : 0xFF), bufsize );
		for( uint64_t pos = 0 ; pos < fsize2 ; pos += bufsize ){
			//uint64_t nfill = ( std::min<uint64_t>( bufsize, fsize2-pos ) )();
			uint64_t nfill = ( bufsize < fsize2-pos ? bufsize : fsize2-pos );
			f_write( &fil2, bfr3, nfill, &dmy0 );
		}
	}
	rs2 = f_close( &fil2 );
	if( rs2 != FR_OK ){
		std::string err = FpCnvFatFsErrorCodeToStr( rs2, 2 );
		if( mShowStdErs )
			printf("FPA: ERROR: f_close failed [%s] [RuYL2Gje]\n", err.c_str() );
		return 0L;
	}
	memset( &fil2, 0, sizeof(FIL) );
	return 1L;
}
bool FpDiskImage::isVFile( std::string pathname )const
{
	FpSetDisk( mMountedName.c_str() );
	return isVFileOrDir( pathname, 0L );
}
bool FpDiskImage::isVDir( std::string pathname )const
{
	FpSetDisk( mMountedName.c_str() );
	return isVFileOrDir( pathname, 1L );
}
bool FpDiskImage::isVFileOrDir( std::string pathname, bool bIfIsDir )const
{
	pathname = fixAnyPathTokens( pathname );
	if( bIfIsDir && mFp2 && (pathname.empty() || pathname=="/") ){ //if checking for root dir existence
		return 1L;
	}
	FILINFO finf2; FRESULT rs2;
	memset( &finf2, 0, sizeof(FILINFO) );
	rs2 = f_stat( pathname.c_str(), &finf2 );
	if( rs2 == FR_OK ){
		if( bIfIsDir == !!(finf2.fattrib & AM_DIR) ){
			return 1L;
		}
		return 0L;
	}else if( rs2 == FR_NO_FILE ){
		return 0L;
	}
	std::string err = FpCnvFatFsErrorCodeToStr( rs2, 2 );
	if( mShowStdErs )
		printf("FPA: ERROR: f_stat failed [%s] [1xwIXKvq]\n", err.c_str() );
	return 0L;
}
/**
	Examines only the dirname part of the 'pathname' and
	creates missing parent directories.
*/
bool FpDiskImage::createDirsIfNeeded( std::string pathname )
{
	pathname = fixAnyPathTokens( pathname );
	FRESULT rs2;
	if( isWithPathPart( pathname.c_str() ) ){
		std::vector<std::string> dirns2;
		std::string dirpart = *FpSplitPath( pathname );
		FpStrExplode2( dirpart.c_str(), dirns2, {"/",}, -1, "", "" );
		{
			std::string currpath = "";
			auto ir2 = dirns2.begin();
			for( size_t ii2=0; ir2 != dirns2.end(); ++ir2, ii2++ ){
				if(ii2)
					currpath += "/";
				currpath += *ir2;
				if( !isVDir( currpath.c_str() ) ){
					rs2 = f_mkdir( currpath.c_str() );
					if( rs2 != FR_OK ){
						std::string err = FpCnvFatFsErrorCodeToStr( rs2, 2 );
						if( mShowStdErs ){
							printf("FPA: ERROR: f_mkdir failed [%s] [lBauVvj]\n", err.c_str() );
							printf("     Dir: [%s]\n", currpath.c_str() );
						}
						return 0L;
					}
				}
			}
		}
	}
	return 1L;
}
bool FpDiskImage::enumVDirContents9( std::string dirname2,
		const char* flags3, std::function<void(const FpVFile&)> calb2,
		const std::string& srStartPath,
		int nDepth2
		)const
{
	FpSetDisk( mMountedName.c_str() );
	dirname2 = fixAnyPathTokens( dirname2 );
	flags3 = flags3 ? flags3 : "";
	bool bDirs  = !!strchr( flags3, 'd');
	bool bFiles = !!strchr( flags3, 'f');
	bool bRcv   = !!strchr( flags3, 'r');
	bool bSlmrk = !!strchr( flags3, 's');
	if( !bDirs && !bFiles ){
		bDirs = bFiles = 1L;
	}
	std::vector<std::string> aDirs;
	DIR pdr3; FRESULT rs2;
	memset( &pdr3, 0, sizeof(DIR) );
	std::shared_ptr<void> raii5( 0, [&](void*){
		if( pdr3.obj.fs ){
			f_closedir( &pdr3 );
			pdr3.obj.fs = 0;
		}
	});
	rs2 = f_opendir( &pdr3, dirname2.c_str() );
	if( rs2 != FR_OK ){
		std::string err = FpCnvFatFsErrorCodeToStr( rs2, 2 );
		if( mShowStdErs ){
			printf("FPA: ERROR: f_opendir failed [%s] [fzgpjU]\n", err.c_str() );
			printf("     Dir: [%s]\n", dirname2.c_str() );
		}
		return 0L;
	}
	FILINFO fni;
	memset( &fni, 0, sizeof(FILINFO) );
	f_readdir( &pdr3, nullptr );  //reset internal index to first.
	for( ;; ){
		rs2 = f_readdir( &pdr3, &fni );
		if( rs2 != FR_OK || !*fni.fname ){  //if end of dir.
			break;
		}
		std::string srPathn = dirname2;
		srPathn += (dirname2.empty() ? "" : "/");
		srPathn += fni.fname;
		bool bReport = 0L;
		const bool bDir2 = !!( fni.fattrib & AM_DIR );
		if( bDir2 ){
			//printf("d [%s/%s]\n", dirname2.c_str(), fni.fname );
			bReport = bDirs;
			if( bRcv ){
				aDirs.push_back( srPathn );
			}
		}else{
			//printf("f [%s/%s]\n", dirname2.c_str(), fni.fname );
			bReport = bFiles;
		}
		if( bReport ){
			assert( fni.fname );
			bool bBreak2 = 0L;
			FpVFile di2;
			di2.uFileLen   = static_cast<uint64_t>( fni.fsize );
			di2.srFName    = fni.fname;
			di2.srAbsPath  = srPathn;
			di2.bDir       = bDir2;
			di2.srDotDir   = bDir2 ? srPathn : dirname2;
			di2.nDepth     = nDepth2;//(bDir2 ? nDepth2 + 1 : nDepth2);
			di2.bBreak     = &bBreak2;
			di2.srRelPath  = getRelPathGivenAbsAndStart( di2.srAbsPath, srStartPath );
			assert( !di2.srRelPath.empty() ); //must be with at least file name.
			if( bSlmrk && bDir2 ){
				di2.srAbsPath += "/";
				di2.srRelPath += "/";
				di2.srFName   += "/";
			}
			calb2( di2 );
			if( bBreak2 ){
				return 0L;
			}
		}
	}
	if( bRcv ){
		for( auto ir2 = aDirs.begin(); ir2 != aDirs.end(); ++ir2 ){
			if( !enumVDirContents9( *ir2, flags3, calb2, srStartPath, nDepth2+1 ) ){
				return 0L;
			}
		}
	}
	return 1L;
}
/**
	Enumerates files|directories in the specified virtual directory
	on the opened disk image.
	\param pathname - Input path name. no leading or trailing slashes.
	                  Eg. "sub1/sub2".
	                  To enumerates the root directory, set it to "/".
	\param flags3 - Flags as C-string:
					f: retrieve files.
					d: retrieve directories.
					r: recurse to sub-directories.
					s: mark directories by appending the trailing slash
					   to the following member verialbes:
					   FpVFile::srFName, FpVFile::srAbsPath and FpVFile::srRelPath.
					b: sort so that files are ordered before parent directories.
					   i.e. the deletion order. delete files+dirs in
					   the order as they appear in the returned list.
*/
bool FpDiskImage::enumVDirContents2( std::string pathname,
		const char* flags3,
		std::function<void(const FpVFile&)> calb2 )const
{
	const bool bFilesFirst = !!strchr( flags3, 'b');
	if( !bFilesFirst ){
		return enumVDirContents9( pathname, flags3, calb2, pathname, 0 );
	}else{
		FpSetDisk( mMountedName.c_str() );
		pathname = fixAnyPathTokens( pathname );
		//
		std::vector<FpVFile> files2;
		bool rs4;
		rs4 = enumVDirContents9( pathname, flags3,
				[&files2]( const FpVFile& vfi )->void{
					files2.push_back( vfi );
				}, pathname, 0 );
		//std::srand( 42 );
		//std::random_shuffle( files2.begin(), files2.end() );
		std::sort( files2.begin(), files2.end(),
				[]( const FpVFile& a, const FpVFile& b )->bool{
					const int nCmp = FpCmpi( a.srDotDir.c_str(), b.srDotDir.c_str(), -1 );
					if( !nCmp ){
						if( !a.bDir && !b.bDir ){
							return (FpCmpi( a.srFName.c_str(), b.srFName.c_str(), -1 ) < 0);
						}
						return !a.bDir;
					}
					return nCmp > 0;
		});
		for( FpVFile& a : files2 ){
			bool bBreak2 = 0L;
			a.bBreak = &bBreak2;
			calb2( a );
			if( bBreak2 ){
				break;
			}
		}
		return rs4;
	}
}
bool FpDiskImage::enumVDirContents3( std::string pathname,
		const char* flags3,
		std::vector<FpVFile>* itemsOu )const
{
	bool rs4 = enumVDirContents2( pathname, flags3,
			[&]( const FpVFile& vfi )->void{
				itemsOu->push_back( vfi );
			});
	return rs4;
}

std::string FpDiskImage::getRelPathGivenAbsAndStart(
		std::string srAbsPath, std::string srStartPath )
{
	srAbsPath   = fixAnyPathTokens( srAbsPath );
	srStartPath = fixAnyPathTokens( srStartPath );
	const char* szAbs = srAbsPath.c_str();
	const char* pos2 = std::strstr( szAbs, srStartPath.c_str() );
	if( szAbs == pos2 ){
		std::string outp;
		outp = srAbsPath.substr( srStartPath.size(), std::string::npos );
		if( !outp.empty() && outp[0] == '/' ){
			outp = outp.substr( 1, std::string::npos );
		}
		return outp;
	}
	return "";
}
/**
	Removes file or directory.
	Directory must be empty, unless flag 'e' is set.
	Directory|file must be w/o the read-only, AM_RDO attribute,
	unless flag 'o' is set.
	\param flags2 - Flags as C-string:
	                'e' - empty the directory by deleting its contents first.
	                'o' - remove the read-only flag first. implied if 'e' is present.
*/
bool FpDiskImage::unlinkVf( std::string pathname, const char* flags2 )
{
	FpSetDisk( mMountedName.c_str() );
	pathname = fixAnyPathTokens( pathname );

	bool bEmptying = ( !!strchr( flags2, 'e') );
	bool bRmvRdo   = ( !!strchr( flags2, 'o') || bEmptying );
	FRESULT rs2;
	if( bRmvRdo ){   //attribute AM_RDO
		rs2 = f_chmod( pathname.c_str(), 0, AM_RDO );
		if( rs2 != FR_OK ){
			std::string err = FpCnvFatFsErrorCodeToStr( rs2, 2 );
			if( mShowStdErs )
				printf("FPA: ERROR: f_chmod failed [%s] [TB0PcfX]\n", err.c_str() );
			return 0L;
		}
	}
	if( bEmptying ){
		bool bDir3 = 0L;
		{
			FILINFO finf3;
			memset( &finf3, 0, sizeof(FILINFO) );
			rs2 = f_stat( pathname.c_str(), &finf3 );
			if( rs2 == FR_OK && (finf3.fattrib & AM_DIR) ){
				bDir3 = 1L;
			}
		}
		if( bDir3 ){
			std::vector<FpVFile> files3;
			bool rs4;
			rs4 = enumVDirContents3( pathname, "bfd", &files3 );
			if(!rs4)
				files3.clear();
			for( auto ir2 = files3.begin(); ir2 != files3.end(); ++ir2 ){
				// NOTE: must call non-recursive - no 'e' flag.
				if( !unlinkVf( ir2->srAbsPath, "o") ){
					return 0L;
				}
			}
		}
	}
	rs2 = f_unlink( pathname.c_str() );
	if( rs2 != FR_OK ){
		std::string err = FpCnvFatFsErrorCodeToStr( rs2, 2 );
		if( mShowStdErs ){
			printf("FPA: ERROR: f_unlink failed [%s] [19yit96]\n", err.c_str() );
			printf("     Path: [%s]\n", pathname.c_str() );
		}
		return 0L;
	}
	return 1L;
}
/**
	Writes file bytes by either replacing or appending contents.
	Creates new file if it doesn't exist.
	\param flags2 - Flags as C-string:
					r: replace contents.
					a: append contents. must not be specififed if 'r' is.
					o: remove the read-only flag first, if any.
					F: do not flush the disk image file after
					   writing this file. Not recommended.
*/
bool FpDiskImage::
putVFileBytes2( std::string pathname,
		const void* data2, uint64_t uNumBytes, const char* flags2 )
{
	FpSetDisk( mMountedName.c_str() );
	pathname = fixAnyPathTokens( pathname );
	bool bReplace       = !!strchr( flags2, 'r');
	bool bAppend        = !!strchr( flags2, 'a');
	bool bRmvRdo        = !!strchr( flags2, 'o');
	bool bFlushOnWriEnd =  !strchr( flags2, 'F');
	FRESULT rs2;
	assert( bReplace != bAppend  );
	if( bRmvRdo ){
		rs2 = f_chmod( pathname.c_str(), 0, AM_RDO );
		if( rs2 != FR_OK ){
			std::string err = FpCnvFatFsErrorCodeToStr( rs2, 2 );
			if( mShowStdErs )
				printf("FPA: ERROR: f_chmod failed [%s] [NLgcvzc]\n", err.c_str() );
			return 0L;
		}
	}
	FIL fil2;
	memset( &fil2, 0, sizeof(FIL) );
	std::shared_ptr<void> raii4( 0, [&](void*){
		if( fil2.obj.fs ){
			f_close( &fil2 );
			fil2.obj.fs = 0;
		}
		if( bFlushOnWriEnd ){
			fflush( mFp2 );
		}
	});
	{
		BYTE nMode = FA_WRITE|FA_READ;
		if( bReplace ){
			nMode |= FA_CREATE_ALWAYS; //Creates a new file. If the file is existing, it will be truncated and overwritten.
		}else if( bAppend ){
			nMode |= FA_OPEN_APPEND;  //Same as FA_OPEN_ALWAYS except the read/write pointer is set end of the file.
		}else{
			nMode |= FA_OPEN_ALWAYS;  //Opens the file if it is existing. If not, a new file will be created.
		}
		rs2 = f_open( &fil2, pathname.c_str(), nMode );
		if( rs2 != FR_OK ){
			std::string err = FpCnvFatFsErrorCodeToStr( rs2, 2 );
			if( mShowStdErs )
				printf("FPA: ERROR: f_open failed [%s] [RINL2Tf]\n", err.c_str() );
			return 0L;
		}
	}
	UINT writtenn = 0, uNumBytes2 = static_cast<UINT>(uNumBytes);
	rs2 = f_write( &fil2, data2, uNumBytes2, &writtenn );
	if( rs2 == FR_OK && uNumBytes2 != writtenn ){
		if( mShowStdErs ){
			printf("FPA: ERROR: f_write failed; requested:%d, written:%d [0Xg67Mp]\n",
					(int)uNumBytes2, (int)writtenn );
		}
		return 0L;
	}else if( rs2 != FR_OK ){
		std::string err = FpCnvFatFsErrorCodeToStr( rs2, 2 );
		if( mShowStdErs )
			printf("FPA: ERROR: f_write failed [%s] [RIjfS4zr]\n", err.c_str() );
		return 0L;
	}
	assert( rs2 == FR_OK );
	return 1L;
}
uint32_t FpDiskImage::getVFileSize( std::string pathname )const
{
	FpSetDisk( mMountedName.c_str() );
	pathname = fixAnyPathTokens( pathname );
	FIL fil2;
	memset( &fil2, 0, sizeof(FIL) );
	std::shared_ptr<void> raii4( 0, [&](void*){
		if( fil2.obj.fs ){
			f_close( &fil2 );
			fil2.obj.fs = 0;
		}
	});
	FRESULT rs2;
	rs2 = f_open( &fil2, pathname.c_str(), FA_READ|FA_OPEN_EXISTING );
	if( rs2 != FR_OK ){
		std::string err = FpCnvFatFsErrorCodeToStr( rs2, 2 );
		if( mShowStdErs )
			printf("FPA: ERROR: f_open failed [%s] [64XgZsJB]\n", err.c_str() );
		return 0;
	}
	uint32_t size2 = f_size( &fil2 );
	return size2;
}
/**
	Gets file bytes given pathname.
	flags2 - flags as c-string:
				'c': make sure output data is terminated by null byte.
*/
bool FpDiskImage::getVFileBytes2( std::string pathname,
		std::vector<uint8_t>* dataOu,
		uint64_t nStartAddr,
		std::pair<bool,uint64_t> nMaxRead, const char* flags2 )const
{
	FpSetDisk( mMountedName.c_str() );
	pathname = fixAnyPathTokens( pathname );
	bool bEnsureNullTerm = !!strchr( flags2, 'c' );
	assert( dataOu );
	FIL fil2;
	memset( &fil2, 0, sizeof(FIL) );
	std::shared_ptr<void> raii4( 0, [&](void*){
		if( fil2.obj.fs ){
			f_close( &fil2 );
			fil2.obj.fs = 0;
		}
		if( bEnsureNullTerm ){
			if( dataOu->empty() || *dataOu->rbegin() != 0 ){
				dataOu->push_back( 0 );
			}
		}
	});
	FRESULT rs2;
	rs2 = f_open( &fil2, pathname.c_str(), FA_READ|FA_OPEN_EXISTING );
	if( rs2 != FR_OK ){
		std::string err = FpCnvFatFsErrorCodeToStr( rs2, 2 );
		if( mShowStdErs )
			printf("FPA: ERROR: f_open failed [%s] [8VaRHCOI]\n", err.c_str() );
		return 0;
	}
	uint64_t nToRead = getVFileSize( pathname );
	if( nStartAddr >= nToRead ){
		if( mShowStdErs )
			printf("FPA: ERROR: start offset is past the end of file [CK3veny]\n");
		return 0L;
	}
	nToRead -= nStartAddr;
	nToRead = ( nMaxRead.first ? FpMin<uint64_t>( nMaxRead.second, nToRead ) : nToRead );
	if( !nToRead ){
		return 1L;
	}
	rs2 = f_lseek( &fil2, nStartAddr );
	if( rs2 != FR_OK ){
		std::string err = FpCnvFatFsErrorCodeToStr( rs2, 2 );
		if( mShowStdErs )
			printf("FPA: ERROR: f_lseek failed [%s] [7fJtCYqx]\n", err.c_str() );
		return 0L;
	}
	UINT nReadd = 0;
	dataOu->resize( nToRead, 0 );
	rs2 = f_read( &fil2, &(*dataOu)[0], nToRead, &nReadd );
	if( rs2 != FR_OK ){
		std::string err = FpCnvFatFsErrorCodeToStr( rs2, 2 );
		if( mShowStdErs )
			printf("FPA: ERROR: f_read failed [%s] [kxYegHa0]\n", err.c_str() );
		return 0L;
	}
	assert( nToRead );
	if( !nReadd ){
		if( mShowStdErs )
			printf("FPA: ERROR: f_read failed. Readd 0 bytes. [mN3ZlDux]\n");
		return 0L;
	}
	if( nReadd < dataOu->size() ){
		dataOu->resize( nReadd );
		dataOu->shrink_to_fit();
	}
	return 1L;
}
std::vector<uint8_t> FpDiskImage::
getVFileBytes3( std::string pathname, uint64_t nStartAddr, std::pair<bool,uint64_t> nMaxRead,
		const char* flags2 )const
{
	std::vector<uint8_t> outp;
	getVFileBytes2( pathname, &outp, nStartAddr, nMaxRead, flags2 );
	return outp;
}
