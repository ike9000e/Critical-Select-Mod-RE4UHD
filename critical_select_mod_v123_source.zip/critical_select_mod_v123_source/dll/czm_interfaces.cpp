#include "czm_interfaces.h"
#include <assert.h>

CzmCutscSkipDTO::
CzmCutscSkipDTO( CZM_CST eCtsType_, bool* bSkipCutscene_ )
	: eCtsType(eCtsType_)
	, bSkipCutscene(bSkipCutscene_)
{
}
uint16_t CzmRE4GlobDt::
pokeRoomIdValue( bool bSet, uint16_t uNewRoomId )
{
	if( bSet ){
		curRoomId_4FAC.v = uNewRoomId;
	}
	return curRoomId_4FAC.v;
}
bool CzmRE4Enemy::testEnemyType2( const std::array<uint8_t,2>& aTyAndSubTy )const
{
	return ( id_100.v == aTyAndSubTy[0] && type_101.v == aTyAndSubTy[1] );
}
CzmRE4Enemy::CzmRE4Enemy()
{
	std::memset( this, 0, sizeof(*this) );
}
CzmEnemyTypeAdp::
CzmEnemyTypeAdp( const CzmRE4Enemy* inp )
	: uEnmType( inp->id_100.v )
	, uEnmSubType( inp->type_101.v )
{
}
CzmEnemyTypeAdp::
CzmEnemyTypeAdp( const std::array<uint8_t,2>& aEnmTySubTy )
	: uEnmType( aEnmTySubTy[0] )
	, uEnmSubType( aEnmTySubTy[1] )
{
}
/// Returns true if enemy is of normal, humanoid type.
/// Fe. an enemy that can spawn head plagas.
bool CzmEnemyTypeAdp::isNormalHumanoidEnemyType()const
{
	//CZM_EEIT : uint8_t
	static const std::vector<uint8_t> aNormalHumanoidTypes = {
		CZM_EEIT::CZM_E7_Ganado,
		CZM_EEIT::CZM_E7_Ganado_Villager_12,
		CZM_EEIT::CZM_E7_Ganado_Villager_15,
		CZM_EEIT::CZM_E7_Ganado_Villager_and_Bella_Sisters,
		CZM_EEIT::CZM_E7_Ganado_Villager_17,
		CZM_EEIT::CZM_E7_Ganado_Soldier,
		CZM_EEIT::CZM_E7_Soldier,
		CZM_EEIT::CZM_E7_Soldier2,
		CZM_EEIT::CZM_E7_HeavySoldier,
		CZM_EEIT::CZM_E7_Zealot,
		CZM_EEIT::CZM_E7_Zealot2,
		CZM_EEIT::CZM_E7_Zealot3,
		CZM_EEIT::CZM_E7_Zealot4,
		CZM_EEIT::CZM_E7_Zealot5,
		CZM_EEIT::CZM_E7_Zealot6,
		CZM_EEIT::CZM_E7_VillagerSW,
		CZM_EEIT::CZM_E7_VillagerSW2,
		CZM_EEIT::CZM_E7_SoldierSW,
	};
	if( isSpecialHumanoidEnemyType() ){
		return 0L;
	}
	auto a = std::find( aNormalHumanoidTypes.begin(), aNormalHumanoidTypes.end(), uEnmType );
	if( a != aNormalHumanoidTypes.end() ){
		return 1L;
	}
	return 0L;
}
/// Returns true for enemies such as Captain JJ,
/// Super Salvador and Garrador (aka. berserker).
bool CzmEnemyTypeAdp::isSpecialHumanoidEnemyType()const
{
	const std::array<uint8_t,2> aEnmTySubTy = {
		uEnmType, uEnmSubType,};

	// exceptions for special ganados needed.
	if( aEnmTySubTy[0] == CZM_EEIT::CZM_E7_Soldier ){
		if( aEnmTySubTy[1] == CZM_EESTM::CZM_E8_CaptainJJ ){
			return 1L;
		}
	}
	if( aEnmTySubTy[0] == CZM_EEIT::CZM_E7_Ganado_Soldier ){
		if( aEnmTySubTy[1] == CZM_EESTM::CZM_E8_SuperSalvador ){
			return 1L;
		}
	}
	// Garradors
	if( aEnmTySubTy[0] == CZM_EEIT::CZM_E7_Zealot5 ){
		if( aEnmTySubTy[1] == CZM_EESTM::CZM_E8_RegularGarradorWith1B ){
			return 1L;
		}
	}
	if( aEnmTySubTy[0] == CZM_EEIT::CZM_E7_Zealot6 ){
		const bool cond2 = (
			aEnmTySubTy[1] == CZM_EESTM::CZM_E8_RegularGarradorWith1C ||
			aEnmTySubTy[1] == CZM_EESTM::CZM_E8_ArmoredGarradorWith1C );
		if(cond2){
			return 1L;
		}
	}
	return 0L;
}
/// Returns true if enemy is of lethal type.
/// For example villagers, monks, bosses.
/// Excludes harmless animals, etc.
bool CzmEnemyTypeAdp::isLethalEnemyType()const
{
	static const std::vector<uint8_t> aLethalEnemies = {
		CZM_EEIT::CZM_E7_Snake,
		CZM_EEIT::CZM_E7_Colmillos,
		CZM_EEIT::CZM_E7_Plagas_C_r20F,
		CZM_EEIT::CZM_E7_El_Gigante,
		CZM_EEIT::CZM_E7_Verdugo,
		CZM_EEIT::CZM_E7_Novistador,
		CZM_EEIT::CZM_E7_DelLago,
		CZM_EEIT::CZM_E7_No_0_Sadler,
		CZM_EEIT::CZM_E7_No_0_Sadler_after_transformation,
		CZM_EEIT::CZM_E7_U3,
		CZM_EEIT::CZM_E7_MendezAForm,
		CZM_EEIT::CZM_E7_MendezBForm,
		CZM_EEIT::CZM_E7_Regenerator_and_Iron_Maiden,
		CZM_EEIT::CZM_E7_Salazar,
		CZM_EEIT::CZM_E7_Krauser,
		CZM_EEIT::CZM_E7_Robot_0x3A,
		CZM_EEIT::CZM_E7_TruckOrWagon,
		CZM_EEIT::CZM_E7_KnightType,
		CZM_EEIT::CZM_E7_Saddler_SW,
		CZM_EEIT::CZM_E7_ShipCannon,
	};
	if( this->isNormalHumanoidEnemyType() ){
		return 1L;
	}
	if( this->isSpecialHumanoidEnemyType() ){
		return 1L;
	}
	auto ir2 = aLethalEnemies.begin();
	for( ; ir2 != aLethalEnemies.end(); ++ir2 ){
		if( *ir2 == this->uEnmType ){
			return 1L;
		}
	}
	return 0L;
}
/// To enumerate enemies by index.
/// Should be called in a loop, starting with index 0.
/// Returns null when input index is too large.
CzmRE4Enemy* CzmEnmMgrMvDTO::getNextEnemy2( size_t nIndex2 )const
{
	assert( pEnMgr2 );
	CzmRe4EnmyMgr* thisp = pEnMgr2;
	if( nIndex2 < (size_t)thisp->m_nArray_8.v ){
		CzmRE4Enemy* enm3 = (CzmRE4Enemy*) ( (uint8_t*) thisp->m_Array_4.v + nIndex2 * thisp->m_blockSize_C.v );
		return enm3;
	}
	return nullptr;
}
CzmRE4EmList& CzmRE4EmList::setSampleEnemy2()
{
	// Villager-0 in r100, ESL entry:
	// static const uint8_t anVil00z[] = {
	//     0x00,0x12,0x00,0x00,0x24,0x00,0x00,0x20,0xF4,0x01,0x00,0x02,0xC6,0xE1,0x56,0x00,
	//     0xCD,0xF1,0x00,0x00,0xF3,0x17,0x00,0x00,0x00,0x01,0x0B,0x00,0x00,0x00,0x00,0x00,
	// };
	memset( this, 0, sizeof(*this) );
	id_1   = 0x12;
	type_2 = 0x00;
	set_3  = 0x00;
	flag_4 = 0x00000000;  //0x20000024
	hp_8 = 1200;
	emset_no_A = 0x00;
	Character_B = 0x02;
	*((uint16_t*)&s_pos_C.x) = 0xE1C6;
	*((uint16_t*)&s_pos_C.y) = 0x0056;
	*((uint16_t*)&s_pos_C.z) = 0xF1CD;
	*((uint16_t*)&s_ang_12.x) = 0x0000;
	*((uint16_t*)&s_ang_12.y) = 0x17F3;
	*((uint16_t*)&s_ang_12.z) = 0x0000;
	room_18 = 0x100;
	*((uint16_t*)&Guard_r_1A) = 0x000B;
	return *this;
}
uint64_t czm_ArrayToFlags( const bool* pArray, size_t num )
{
	uint64_t out2 = 0;
	const uint64_t oneflag = 1;
	for( size_t ii2 = 0; ii2 < num; ii2++ ){
		out2 |= ( pArray[ii2] ? oneflag << ii2 : 0 );
	}
	return out2;
}


