#include "czm_utils.h"
#include <windows.h>
#include <memory>
#include <array>
#include <assert.h>
#include <xinput.h>   //XInputGetState()
#include "Minhook.h"
#include "imgui.h"
#include "detours.h"
#include "hxdw_utils.h"
#include "hxdw_process.h"
#include "hxdw_detours_misc.h"
#include "hxdw_checksum.h"  //HxdwMd5
#include "fp_fat32.h"   //FpDiskImage
// warning C4091: 'typedef ': ignored on left of '<unnamed-enum-hdBase>' when no variable is declared

BOOL __stdcall czm_PeekMessageW( MSG* msg, HWND hw2, UINT wMsgFilterMin, UINT wMsgFilterMax, UINT wRemoveMsg );
BOOL __stdcall czm_PeekMessageA( MSG* msg, HWND hw2, UINT wMsgFilterMin, UINT wMsgFilterMax, UINT wRemoveMsg );
uint32_t czm_XinputDetoursInit();
uint32_t czm_XinputDetoursDeinit();
DWORD WINAPI czm_XInputGetState( DWORD dwUserIndex, XINPUT_STATE* pStateOut );
void czm_EachHotPred2( std::function< void(const CzmEachHPatchDTO&)> calb2 );

const std::vector<std::pair<int,int> > CzmData::aUIButtonMap = {
	{ XINPUT_GAMEPAD_DPAD_DOWN, ImGuiKey_DownArrow,},
	{ XINPUT_GAMEPAD_DPAD_UP, ImGuiKey_UpArrow,},
	{ XINPUT_GAMEPAD_DPAD_LEFT, ImGuiKey_LeftArrow,},
	{ XINPUT_GAMEPAD_DPAD_RIGHT, ImGuiKey_RightArrow,},
	{ XINPUT_GAMEPAD_LEFT_SHOULDER, ImGuiKey_ModCtrl,},
	{ XINPUT_GAMEPAD_A, ImGuiKey_Space,},
	{ XINPUT_GAMEPAD_BACK, ImGuiKey_Escape,},
	{ XINPUT_GAMEPAD_X, ImGuiKey_Tab,},
	{ XINPUT_GAMEPAD_Y, ImGuiKey_Enter,},
	{ XINPUT_GAMEPAD_LEFT_THUMB, ImGuiKey_PageUp,},
	{ XINPUT_GAMEPAD_RIGHT_THUMB, ImGuiKey_PageDown,},
};
const int16_t CzmData::nUIButtonMask = ( XINPUT_GAMEPAD_RIGHT_SHOULDER | XINPUT_GAMEPAD_START );
const int16_t CzmData::nUICloseButtons = ( XINPUT_GAMEPAD_START | XINPUT_GAMEPAD_B );
const uint32_t CzmData::uUIButtonIntervalMs = 333;
const size_t CzmData::nMaxLogItems = 128;

bool czm_Print2( const char* fmt, const std::vector<HxdwPrintAdp> args4 )
{
	std::string sr3 = hxdw_StrPrintf( fmt, args4 );
	return hxdw_StdPrint2( sr3.c_str() );
}

std::string czm_ToStrFmt( const char* fmt, int64_t inp )
{
	assert( fmt );
	{
		int ii2 = 0;
		for( const char* ptr = fmt; (ptr = std::strchr( ptr, '%' )); ii2++, ptr++ );
		assert( ii2 == 1 && "Format string must contain exactly one percent character [iBnasZ]");
	}
	char bfr4[64];
	std::snprintf( bfr4, sizeof(bfr4), fmt, inp );
	return bfr4;
}
bool czm_AnySystemModkeyDown()
{
	static const std::array<int,5> ar2 = { VK_SHIFT,VK_CONTROL,VK_MENU,VK_LWIN,VK_RWIN,};
	for( auto ir2 = ar2.begin(); ir2 != ar2.end(); ++ir2 ){
		if( 0x8000 & GetAsyncKeyState( *ir2 ) ){
			return 1;
		}
	}
	return 0;
}
CzmSettings::CzmSettings()
	: placeholder0_(0)
{
	bCritDmgScale = 0L;
	fCritDmgScale2 = 1.f;
//	uWpnCheckFlags2 = 0;//5000000123; //0;
	srWpnCheckFlags4 = "---";

	bCutscSkip2 = 0L;
	bDeltaCutscSkip = 0L;
	bDelLagoKO = 0L;
	bYclAb = 0L;
	bMrchWASkip = 0L;

	bPlagasOvr = 0L;
	nPrsChance = 50;
	bPrsSpwNoLimit = 0L;
	bNoTypeCParasite = 0L;
	bNoParasiteChOne = 0L;

	//bShowEnmStatsAa = 0L;
	//bShowEnmStatsBa = 0L;
	uShowEnmStats = 0;
}
bool CzmSettings::equalsWith( const CzmSettings& otherr )const
{
//	size_t num = sizeof(*this);
//	return !memcmp( this, &otherr, num );
	//srWpnCheckFlags4
	bool rs2;
	rs2 = ( this->serialize3().getAsString() == otherr.serialize3().getAsString() );
	return rs2;
}
hxdw_IniData2 CzmSettings::serialize3()const
{
	hxdw_IniData2 outp;
	WppPrinter<> printerr;
	printerr.print2( *this, [&]( std::string name2, std::string value2 ){
		outp.setValue("s_settings", name2.c_str(), value2.c_str() );
	});
	return outp;
}
bool CzmSettings::deserialize3( const hxdw_IniData2& vInpIni )
{
	vInpIni.eachVariable( {"s_settings",},
		[&]( const char* s, const char* kname, const char* value2 )->bool{
			//WppAmplifier<int> amplifier2( kname, atoi(value2) );
			WppAmplifier<std::string> amplifier2( kname, std::string(value2) );
			amplifier2.apply2( this );
			return 1L;
	});
	return 1L;
}
uint32_t czm_Win32DetoursInit()
{
	HMODULE hUser32Dll = 0;
	hxdw_EnumerateProcessModules( 0, [&]( const HxdwModOnEnum& inp )->bool{
			auto bn2 = hxdw_SplitPath( inp.srPath ).second;
			assert( !bn2.empty() );
			if( !hxdw_StrCmpOpt( bn2.c_str(), "user32.dll", -1, "i" ) ){
				hUser32Dll = (HMODULE)inp.hDll;
				return 0L;
			}
			return 1L;
		});
	assert( hUser32Dll );
	{
		//
		// NOTE: MinHook fails to detour a function that is already detoured.
		//       MS Detours library detours that function correctly, instead.
		//
		Czm->fnOgPeekMessageA = GetProcAddress( hUser32Dll, "PeekMessageA");
		assert( Czm->fnOgPeekMessageA );
		Czm->fnOgPeekMessageW = GetProcAddress( hUser32Dll, "PeekMessageW");
		assert( Czm->fnOgPeekMessageW );
		//
		DetourTransactionBegin();
		DetourUpdateThread( GetCurrentThread() );
		std::shared_ptr<void*> raii4( nullptr, [&]( void* ){
			DetourTransactionCommit();
		});
		Czm->bKeyboardNavError = 1L;
		LONG rs2 = DetourAttach( &Czm->fnOgPeekMessageA, czm_PeekMessageA );
		if( rs2 ){   //NO_ERROR=0; ERROR_INVALID_BLOCK
			std::string msg = hxdw_DetoursErrorToString( rs2 );
			czm_Print2("CZM: ERROR: Detouring PeekMessageA failed. Code:[%d:%s] [qYijfM]\n", { (int)rs2, msg,} );
		}else{
			rs2 = DetourAttach( &Czm->fnOgPeekMessageW, czm_PeekMessageW );
			if( rs2 ){
				std::string msg = hxdw_DetoursErrorToString( rs2 );
				czm_Print2("CZM: ERROR: Detouring PeekMessageW failed. Code:[%d:%s] [XAjpoj]\n", { (int)rs2, msg,} );
			}else{
				Czm->bKeyboardNavError = 0L; //mark no-error.
			}
		}
		//DWORD dwOldProt = 0;
		//bool rs2 = !!VirtualProtect( pPkMsgFunc, 16, PAGE_EXECUTE_READWRITE, &dwOldProt );
		//assert(rs2);
	}
	uint32_t rs2 = czm_XinputDetoursInit();
	assert( !rs2 );

	return 0;
}

uint32_t czm_XinputDetoursInit()
{
	const char* aXinputDllNames[] = {   //taken from ImGui
		"xinput1_4.dll",   // Windows 8+
		"xinput1_3.dll",   // DirectX SDK
		"xinput9_1_0.dll", // Windows Vista, Windows 7
		"xinput1_2.dll",   // DirectX SDK
		"xinput1_1.dll",   // DirectX SDK
	};
	assert( Czm );
	assert( !Czm->hXInputDll );
	hxdw_EnumerateProcessModules( 0, [&](const HxdwModOnEnum& in2)->bool{
		for( size_t ii2=0; ii2 < CzmArrSize(aXinputDllNames); ii2++ ){
			auto bn2 = hxdw_SplitPath( in2.srPath ).second;
			assert( !bn2.empty() );
			if( !hxdw_StrCmpOpt( bn2.c_str(), aXinputDllNames[ii2], -1, "i" ) ){
				assert( in2.hDll );
				Czm->hXInputDll = in2.hDll;
				return 0L;
			}
		}
		return 1L;
	});
	czm_Print2("CZM: XInput Enabled: [%a]\n", { std::string( Czm->hXInputDll ? "Yes": "No"),} );
	if( Czm->hXInputDll ){
		Czm->fnOgXInputGetState = GetProcAddress( (HMODULE)Czm->hXInputDll, "XInputGetState");
		assert( Czm->fnOgXInputGetState );
		DetourTransactionBegin();
		DetourUpdateThread( GetCurrentThread() );
		std::shared_ptr<void*> raii4( nullptr, [&]( void* ){
			DetourTransactionCommit();
		});
		LONG rs2 = DetourAttach( &Czm->fnOgXInputGetState, czm_XInputGetState );
		if( rs2 ){   //NO_ERROR=0
			std::string msg = hxdw_DetoursErrorToString( rs2 );
			czm_Print2("CZM: ERROR: Detouring XInputGetState failed. Code:[%d:%s] [d9WSSU]\n", { (int)rs2, msg,} );
			Czm->bGamepadNavError = 1L;
		}
	}
	return 0;
}

uint32_t czm_Win32DetoursDeinit()   //czm_Win32DetoursInit()
{
	czm_XinputDetoursDeinit();
	{
		//MH_DisableHook( czm_PeekMessageW );
		//MH_DisableHook( czm_PeekMessageA );
		DetourTransactionBegin();
		DetourUpdateThread( GetCurrentThread() );
		DetourDetach( &Czm->fnOgPeekMessageW, czm_PeekMessageW );
		DetourDetach( &Czm->fnOgPeekMessageA, czm_PeekMessageA );
		DetourTransactionCommit();
	}
	return 0;
}
uint32_t czm_XinputDetoursDeinit()   //czm_XinputDetoursInit()
{
	assert( Czm );
	if( Czm->hXInputDll && Czm->fnOgXInputGetState ){
		DetourTransactionBegin();
		DetourUpdateThread( GetCurrentThread() );
		DetourDetach( &Czm->fnOgXInputGetState, czm_XInputGetState );
		DetourTransactionCommit();
	}
	return 0;
}




// IMGUI_IMPL_WIN32_DISABLE_GAMEPAD
/*
	struct XINPUT_GAMEPAD{
		WORD  wButtons;
		BYTE  bLeftTrigger;
		BYTE  bRightTrigger;
		SHORT sThumbLX;
		SHORT sThumbLY;
		SHORT sThumbRX;
		SHORT sThumbRY;
	};
	XINPUT_GAMEPAD::wButtons:
		XINPUT_GAMEPAD_DPAD_UP 	0x0001
		XINPUT_GAMEPAD_DPAD_DOWN 	0x0002
		XINPUT_GAMEPAD_DPAD_LEFT 	0x0004
		XINPUT_GAMEPAD_DPAD_RIGHT 	0x0008
		XINPUT_GAMEPAD_START 	0x0010
		XINPUT_GAMEPAD_BACK 	0x0020
		XINPUT_GAMEPAD_LEFT_THUMB 	0x0040
		XINPUT_GAMEPAD_RIGHT_THUMB 	0x0080
		XINPUT_GAMEPAD_LEFT_SHOULDER 	0x0100
		XINPUT_GAMEPAD_RIGHT_SHOULDER 	0x0200
		XINPUT_GAMEPAD_A 	0x1000
		XINPUT_GAMEPAD_B 	0x2000
		XINPUT_GAMEPAD_X 	0x4000
		XINPUT_GAMEPAD_Y 	0x8000
//*/
void czm_ProcessUIKey( uint16_t nXInputButtons )
{
	assert( Czm );
	ImGuiIO& io3 = ImGui::GetIO();
	const auto& ls2 = CzmData::aUIButtonMap;
	for( auto ir2 = ls2.begin(); ir2 != ls2.end(); ++ir2 ){
		if( nXInputButtons & ir2->first ){
			if( !(Czm->nXInputButtons2 & ir2->first) ){
				io3.AddKeyEvent( ir2->second, 1L );
				Czm->nXInputButtons2 |= ir2->first;
			}
		}else{
			if( Czm->nXInputButtons2 & ir2->first ){
				io3.AddKeyEvent( ir2->second, 0L );
				Czm->nXInputButtons2 &= ~ir2->first;
			}
		}
	}
	if( Czm->bUIOpened && Czm->bFocusNeedleOn ){
		// seecret LB+B
		bool cond2 = (
			(nXInputButtons & (
			XINPUT_GAMEPAD_LEFT_THUMB|XINPUT_GAMEPAD_B)));
		if( !cond2 ){
			cond2 = ( (0x8000 & GetAsyncKeyState('B') &&
				0x8000 & GetAsyncKeyState(VK_CONTROL)) );
		}
		if( cond2 ){
			Czm->bGBossesTabOn = 1L;
		}
		const bool cond3 = (
			nXInputButtons & (
			XINPUT_GAMEPAD_LEFT_THUMB|XINPUT_GAMEPAD_Y));
		if( cond3 ){
			Czm->bGBossesTabOn = 0L;
		}
	}
}
//XInputGetState
DWORD WINAPI czm_XInputGetState( DWORD dwUserIndex, XINPUT_STATE* pStateOut )
{
	assert( Czm );
	assert( Czm->fnOgXInputGetState );
	using fn_t = decltype(czm_XInputGetState)*;
	DWORD retv = ((fn_t)Czm->fnOgXInputGetState)( dwUserIndex, pStateOut );
	if( retv == ERROR_SUCCESS ){
		const WORD bt2 = pStateOut->Gamepad.wButtons;
		const int16_t msk2 = CzmData::nUIButtonMask;
		bool bActv = ( (bt2 & msk2) == msk2 && !(bt2 & (~msk2)) );
		std::shared_ptr<int> raii2( nullptr, [&]( int* ){
			Czm->bUIButtonHeld = bActv;
		});
		if( bActv ){
			pStateOut->Gamepad.wButtons &= ~msk2;
			uint32_t uNow = (uint32_t) hxdw_GetTimeTicksMs();
			if( uNow > Czm->uUIButtonTimePos + CzmData::uUIButtonIntervalMs || !Czm->bUIButtonHeld ){
				Czm->bUIOpened = !Czm->bUIOpened;
				Czm->uUIButtonTimePos = uNow;
			}
		}
		if( Czm->bUIOpened ){
			std::shared_ptr<int> raii3( nullptr, [&]( void* ){
				memset( &pStateOut->Gamepad, 0, sizeof(pStateOut->Gamepad) );
			});
			czm_ProcessUIKey( pStateOut->Gamepad.wButtons );
			{
				const bool cond3 = (
					pStateOut->Gamepad.wButtons & CzmData::nUICloseButtons &&
					!(pStateOut->Gamepad.wButtons & ~CzmData::nUICloseButtons));
				if( cond3 ){
					Czm->bUIOpened = 0L;
					Czm->uUIButtonTimePos = (uint32_t) hxdw_GetTimeTicksMs();
					Czm->bClosingUI = 1L;
				}
			}
		}
		if( Czm->bClosingUI ){
			uint32_t uNow = (uint32_t) hxdw_GetTimeTicksMs();
			if( uNow < Czm->uUIButtonTimePos + CzmData::uUIButtonIntervalMs ){
				pStateOut->Gamepad.wButtons &= ~CzmData::nUICloseButtons;
			}else{
				Czm->bClosingUI = 0L;
			}
		}
	}
	return retv;
}

CzmData::CzmData()
{
	//pG -> .data+0x13F3C //CzmRE4GlobDt //
	assert( !ppGD );
	ppGD = (CzmRE4GlobDt**)hxdw_GetPtrGivenInSectionOffset( 0, nullptr, ".data", 0x13F3C );
	assert( ppGD );

	// pPL -> .data+0x64054
	assert( !ppPlayerGD );
	ppPlayerGD = (CzmRE4Enemy**)hxdw_GetPtrGivenInSectionOffset( 0, nullptr, ".data", 0x64054 );
	assert( ppPlayerGD );
}
CzmData::~CzmData()
{
	if( Czm->pDbfs ){
		delete Czm->pDbfs;
		Czm->pDbfs = nullptr;
	}
}
void CzmData::addLog3( const char* fmt, const std::vector<HxdwPrintAdp> args4 )
{
	std::string sr3 = hxdw_StrPrintf( fmt, args4 );
	for(; aLogText.size() > CzmData::nMaxLogItems ;){
		aLogText.erase( aLogText.begin() );
	}
	aLogText.push_back( CzmLogItem{ sr3,} );
}

CzmPair<const char*,size_t>
CzmData::getLogText2( int nIndex_ )const
{
	if( nIndex_ == -1 ){
		return CzmPair<const char*,size_t>("", aLogText.size() );
	}
	size_t nIndex = (size_t)nIndex_;
	assert( nIndex < aLogText.size() );
	const CzmLogItem* itm2 = &aLogText[nIndex];
	CzmPair<const char*,size_t> outp(
			itm2->srText2.c_str(), aLogText.size() );
	return outp;
}
void CzmData::clearLogText2()
{
	aLogText.clear();
	aLogItemTrack = {0,0,};
}
CzmWndGeomMgr::CzmWndGeomMgr( std::array<float,4> aDflt )
	: aFXywh( aDflt )
{
}
std::string CzmWndGeomMgr::serialize2()const
{
	char bfr2[256];
	std::snprintf( bfr2, sizeof(bfr2),
			"%d,%d,%d,%d,%f,%f,%f,%f",
			aNXywh[0], aNXywh[1],
			aNXywh[2], aNXywh[3],
			aFXywh[0], aFXywh[1],
			aFXywh[2], aFXywh[3]);
	return bfr2;
}
void CzmWndGeomMgr::deserialize2( const char* inp )
{
	{
		const char* sz2 = inp;
		size_t num = 0;
		for(; (sz2 = std::strchr(sz2,',')); sz2 += 1, num += 1 ){}
		assert( (num == 7 || num == 8) && "Number of commas in the input string missmatch [SqPR0n]" );
	}
	std::sscanf( inp, "%d,%d,%d,%d,%f,%f,%f,%f",
		&aNXywh[0], &aNXywh[1],
		&aNXywh[2], &aNXywh[3],
		&aFXywh[0], &aFXywh[1],
		&aFXywh[2], &aFXywh[3]);
}
std::array<int,4> CzmWndGeomMgr::getWindowGeometry()
{
	ImVec2 xy2 = ImGui::GetWindowPos();
	ImVec2 wh2 = ImGui::GetWindowSize();
	std::array<int,4> outp = {
		int(xy2.x), int(xy2.y),
		int(wh2.x), int(wh2.y),};
	return outp;
}
std::array<float,4> CzmWndGeomMgr::getWindowFGeometry()
{
	const auto gmtr2 = getWindowGeometry();
	const ImVec2 dmn4 = ImGui::GetMainViewport()->WorkSize;
	std::array<float,4> out2 = {
		gmtr2[0] / dmn4.x, gmtr2[1] / dmn4.y,
		gmtr2[2] / dmn4.x, gmtr2[3] / dmn4.y,};
	return out2;
}
void CzmWndGeomMgr::updateOnWindowBegin()
{
	if( bNeedGmtryUpdate ){
		ImVec2 xyPos = ImVec2( (float)aNXywh[0], (float)aNXywh[1] );
		ImVec2 whSize = ImVec2( (float)aNXywh[2], (float)aNXywh[3] );
		ImGui::SetWindowPos( xyPos );
		ImGui::SetWindowSize( whSize );
		bNeedGmtryUpdate = 0L;
	}
}
void CzmWndGeomMgr::updateOnWindowEnd()
{
	if( ImGui::IsMouseDown( ImGuiMouseButton_Left ) ){
		aNXywh = getWindowGeometry();
	}
}
void CzmWndGeomMgr::onRezChange( std::array<int,2> aOldRez, std::array<int,2> aNewRez )
{
	std::array<float,4> fracs2 = aFXywh;
	if( aOldRez[0] && aOldRez[1] ){
		fracs2 = {
			float( double(aNXywh[0]) / aOldRez[0] ),
			float( double(aNXywh[1]) / aOldRez[1] ),
			float( double(aNXywh[2]) / aOldRez[0] ),
			float( double(aNXywh[3]) / aOldRez[1] ),
		};
	}
	aNXywh = {
		int( fracs2[0] * aNewRez[0] ),
		int( fracs2[1] * aNewRez[1] ),
		int( fracs2[2] * aNewRez[0] ),
		int( fracs2[3] * aNewRez[1] ),
	};
	bNeedGmtryUpdate = 1L;
}

void czm_SetupUIElements()
{
	{
		//bool show_demo_window = 1;
		//ImGui::ShowDemoWindow(&show_demo_window);
	}
	if( Czm->bShowStartupTip ){
		const uint32_t uNow2 = (uint32_t) hxdw_GetTimeTicksMs();
		Czm->uStartupTipOpenedAtMs = ( Czm->uStartupTipOpenedAtMs ? Czm->uStartupTipOpenedAtMs : uNow2 );
		const uint32_t nEndsAt = (Czm->uStartupTipOpenedAtMs + Czm->uStartupTipDurationMs);
		if( uNow2 < nEndsAt ){
			double pos2 = (double(nEndsAt-uNow2) / Czm->uStartupTipDurationMs);
			const int flags3 = ( ImGuiWindowFlags_NoCollapse |
				ImGuiWindowFlags_NoTitleBar |
				ImGuiWindowFlags_NoScrollbar |
				ImGuiWindowFlags_NoResize );
			ImGui::SetNextWindowBgAlpha( 1.0f ); //1.0f: fully opaque.
			ImGui::Begin( Czm->szAppName, nullptr, flags3 );
			ImGui::Text("%s : Press", Czm->szAppName );
			ImGui::SameLine();
			ImGui::TextColored( {1,1,0,1,},"F5");
			ImGui::SameLine();
			ImGui::Text("or");
			ImGui::SameLine();
			ImGui::TextColored( {1,1,0,1,},"RIGHT_SHOULDER+START");
			ImGui::SameLine();
			ImGui::Text("to open the setup window.");
			if( Czm->bKeyboardNavError ){
				ImGui::TextColored( {1,0,1,1,},"WARNING: No keyboard navigation.");
			}
			if( Czm->bGamepadNavError ){
				ImGui::TextColored( {1,0,1,1,},"WARNING: No gamepad navigation.");
			}
			ImGui::PushItemWidth( ImGui::GetWindowSize().x );
			ImGui::ProgressBar( float(pos2), {0.f, 1.f,} );
			ImGui::PopItemWidth();

			ImGui::End();
		}else{
			Czm->bShowStartupTip = 0L;
		}
	}
	if( Czm->bShowLogWindow ){
		int flags2 = ( ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoTitleBar );
		if( !Czm->bUIOpened ){
			ImGui::SetNextWindowBgAlpha( 0.3f );  //1.0f: fully opaque.
			flags2 |= ImGuiWindowFlags_NoScrollbar;
			flags2 |= ImGuiWindowFlags_NoResize;
		}
		char bfrA[128];
		snprintf( bfrA, sizeof(bfrA), "<<< Log Window - %s >>>", Czm->szAppName );
		ImGui::Begin( bfrA, nullptr, flags2 );
		Czm->cLogWndGmtr.updateOnWindowBegin();
		if( Czm->bUIOpened ){
			ImGui::Text( bfrA );
			if( ImGui::Button("Clear") ){
				Czm->clearLogText2();
			}
			ImGui::SameLine();
			ImGui::Checkbox("Auto scroll", &Czm->bLogAutoScroll );
		}
		for( size_t ii2 = 0; ii2 < +Czm->getLogText2(); ii2++ ){
			ImGui::Text( *Czm->getLogText2( (int) ii2) );
		}
		{
			if( Czm->bLogAutoScroll && *Czm->aLogItemTrack < +Czm->getLogText2() ){
				Czm->aLogItemTrack.first = +Czm->getLogText2();
				Czm->aLogItemTrack.second = 2;
			}
			if( Czm->aLogItemTrack.second ){
				--Czm->aLogItemTrack.second;
				ImGui::SetScrollY( ImGui::GetScrollMaxY() );
			}
		}
		Czm->cLogWndGmtr.updateOnWindowEnd();
		ImGui::End();
	}
	if( Czm->bUIOpened ){
		CzmSettings se2 = Czm->se3;

		std::string srWndName = Czm->szAppName + std::string(" - Settings");
		ImGui::Begin( srWndName.c_str(), nullptr, ImGuiWindowFlags_NoCollapse );
		Czm->cSettingsWndGmtr.updateOnWindowBegin();
		{
			if( ImGui::SmallButton("[Close]""##tyJsLnt") ){
				Czm->bUIOpened = 0L;
			}
			ImGui::SameLine();
			if( ImGui::SmallButton("[Save Settings]""##P3LQ2DF") ){
				bool rs2; std::string data2;
				assert( Czm->pDbfs );  //[s_settings]
				data2 = Czm->se3.serialize3().getAsString();
				czm_Print2("CZM: INI settings save size: %a bytes\n", { data2.size(),});
				rs2 = Czm->pDbfs->putVFileBytes2( Czm->srSettingsIniVFname.c_str(), data2.c_str(), data2.size(), "r" );
				Czm->srUIFileMessage = { ImGui::GetTime(),
					(rs2 ? "Saved" : "ERROR: Settings save failed."),
				};
			}
			ImGui::SameLine();
			if( ImGui::SmallButton("[Clear Settings]""##nEhH7FN") ){
				se2 = CzmSettings();
			}
			ImGui::SameLine();
			if( ImGui::SmallButton("[Reload Settings]""##tBlT7Rc") ){
				std::vector<uint8_t> data3;
				data3 = Czm->pDbfs->getVFileBytes3( Czm->srSettingsIniVFname.c_str(),
							0, {0L,0,}, "c" );
				auto ini4 = hxdw_ParseINIData( (const char*)&data3[0], -1 );
				if( !ini4.isINIEmpty() ){
					se2.deserialize3( ini4 );
				}
				Czm->srUIFileMessage = { ImGui::GetTime(),
					(!ini4.isINIEmpty() ? "Reloaded" : "ERROR: Settings reload failed."),
				};
			}
			if( *Czm->srUIFileMessage ){
				if( *Czm->srUIFileMessage + 3.0 > ImGui::GetTime() ){
					ImGui::Text( (+Czm->srUIFileMessage).c_str() );
				}else{
					*Czm->srUIFileMessage = 0.0;
					ImGui::Text("");
				}
			}else{
				ImGui::Text("");
			}
			// ImGuiTabBarFlags, ImGuiTabItemFlags
			ImGui::BeginTabBar("tabs_kZZeZT", ImGuiTabBarFlags_FittingPolicyScroll );
			if( ImGui::BeginTabItem("Crit. Options", nullptr, 0x0 ) ){
				//static float fDmgSc = 1.f;
				//float fOldDmgSc = se2.fCritDmgScale2;
				//bool bOldCritDmgScale = se2.bCritDmgScale;
				if( ImGui::Checkbox("Enable Critical Damage Scaling", &se2.bCritDmgScale ) ){
					//fOldDmgSc = se2.fCritDmgScale2 * -1.f; //forces update, espec. when disabling.
				}
				{
					ImGui::SameLine();
					static bool bCdsTooltip = 0L;
					if( ImGui::SmallButton("?##uSIiuQ7") ){
						bCdsTooltip = !bCdsTooltip;
					}
					if( bCdsTooltip ){
						ImGui::Text(
							"This works only on humanoid enemies.\n"
							"I.e. this is the damage done with headshots.");
					}
				}
				if( !se2.bCritDmgScale ){
					ImGui::BeginDisabled();
				}
				ImGui::InputFloat("Crit. Scale", &se2.fCritDmgScale2, 0.1f, 0.5f, "%f", 0x0 );
				if( ImGui::Button("Reset""##xRRQ5E2") ){
					se2.fCritDmgScale2 = 1.f;
				}
				ImGui::SameLine();
				if( ImGui::Button("Zero""##q2RLeF2") ){
					se2.fCritDmgScale2 = 0.f;
				}
				ImGui::SameLine();
				if( ImGui::Button("x10""##faiVyeB") ){
					se2.fCritDmgScale2 *= 10.f;
				}
				ImGui::Text("");
				czm_CreateWeaponTypeUIItems( &se2.srWpnCheckFlags4 );
				if( !se2.bCritDmgScale ){
					ImGui::EndDisabled();
				}
				ImGui::EndTabItem();
			}
			if( ImGui::BeginTabItem("Skips", nullptr, 0x0 ) ){
				{
					{
						ImGui::Checkbox("Cutscene Skip""##bCutscSkip2", &se2.bCutscSkip2 );
						Czm->bFocusNeedleOn = ImGui::IsItemFocused(); //bGBossesTabOn
						ImGui::SameLine();
						static bool bCsSkpTooltip = 0L;
						if( ImGui::SmallButton("?##6JaESm") ){
							bCsSkpTooltip = !bCsSkpTooltip;
						}
						if( bCsSkpTooltip ){
							ImGui::Text(
								"Auto skips most of the skippable cutscenes in the game.\n"
								"Done at the first possible frame.");
						}
					}{
						if( ImGui::Checkbox("Make Krauser knife fight cutscenes skippable", &se2.bDeltaCutscSkip ) ){
							//czm_EachHotPred2( [&]( const CzmEachHPatchDTO& in2){
							//	in2.hp3->setCutsceneDeltaSkipable( se2.bDeltaCutscSkip );
							//});
						}
					}
				}{
					if( ImGui::Checkbox("Del Lago insta KO", &se2.bDelLagoKO ) ){
						//czm_EachHotPred2( [&]( const CzmEachHPatchDTO& in2){
						//	in2.hp3->setDelLagoInstaKO( se2.bDelLagoKO );
						//});
					}
				}{
					if( ImGui::Checkbox("You CAN leave Ashley behind", &se2.bYclAb ) ){
						//czm_EachHotPred2( [&]( const CzmEachHPatchDTO& in2){
						//	in2.hp3->setCanLeaveAshleyBehind( se2.bYclAb );
						//});
					}
					if( ImGui::Checkbox("Skip the one-time-per-room merchant \x22""Welcome!\x22 animation", &se2.bMrchWASkip ) ){
						//czm_EachHotPred2( [&]( const CzmEachHPatchDTO& in2){
						//	in2.hp3->setMerchantWelcomeAnimSkip( se2.bMrchWASkip );
						//});
					}
				}
				ImGui::EndTabItem();
			}
			if( ImGui::BeginTabItem("Parasite", nullptr, 0x0 ) ){
				ImGui::Checkbox("Enable Plagas Spawn Override", &se2.bPlagasOvr );
				{
					ImGui::SameLine();
					static bool bPrsOnTooltip = 0L;
					if( ImGui::SmallButton("?##2c2gKaD") ){
						bPrsOnTooltip = !bPrsOnTooltip;
					}
					if( bPrsOnTooltip ){
						ImGui::Text(
							"Also forces the new spawn setting in all chapters,\n"
							"on all eligible enemies, on all eligible kills and in all game modes.\n"
							"Doesn't work in all rooms. eg. start area (r100) or cabin fight area.");
					}
				}
				if( !se2.bPlagasOvr ){
					ImGui::BeginDisabled();
				}
				if( ImGui::InputInt("Parasite Chance %", &se2.nPrsChance, 1, 10, 0x0 ) ){
					se2.nPrsChance = CzmClamp<int,int>( se2.nPrsChance, 0, 100 );
				//	bChanged = 1L;
				}
				if( ImGui::Button("100%##WDeguF") ){
					se2.nPrsChance = 100;
				}
				ImGui::SameLine();
				if( ImGui::Button("0%##IJVwNy") ){
					se2.nPrsChance = 0;
				}
				if( !se2.bPlagasOvr ){
					ImGui::EndDisabled();
				}
				ImGui::Checkbox("Allow Unlimited Parasite Spawns", &se2.bPrsSpwNoLimit );
				{
					ImGui::Checkbox("Disable Parasite Type C", &se2.bNoTypeCParasite );
					ImGui::SameLine();
					static bool bPrsCTooltip = 0L;
					if( ImGui::SmallButton("?##klQbW0") ){
						bPrsCTooltip = !bPrsCTooltip;
					}
					if( bPrsCTooltip ){
						ImGui::Text(
							"Replaces parasite type C (spider-like) with the other parasite.\n"
							"Encountered first in room r20F - the free R.L. room.");
					}
				}{
					if( ImGui::Checkbox("Disable Parasite Spawn in Chapter 1", &se2.bNoParasiteChOne ) ){
						//czm_EachHotPred2( [&]( const CzmEachHPatchDTO& in2){
						//	in2.hp3->setNoParasiteInIntialChapters( se2.bNoParasiteChOne );
						//});
					}
					ImGui::SameLine();
					static bool bPrsCh1Tooltip = 0L;
					if( ImGui::SmallButton("?##sDMC0d") ){
						bPrsCh1Tooltip = !bPrsCh1Tooltip;
					}
					if( bPrsCh1Tooltip ){
						// subchapters, from 1-1 to 1-3, but not 2-1 and forth.
						ImGui::Text(
							"May disable parasite override in the other game modes.");
					}
				}
				ImGui::EndTabItem();
			}
			if( ImGui::BeginTabItem("UI Setup", nullptr, 0x0 ) ){
				int nRqScale = 0;
				nRqScale -= !!ImGui::Button("Scale -");
				ImGui::SameLine();
				nRqScale += !!ImGui::Button("Scale +");
				if( nRqScale ){
					Czm->fUIScale2 *= ( nRqScale > 0 ? 1.1f : 1.0f/1.1f );
					ImGuiIO& io2 = ImGui::GetIO();
					io2.FontGlobalScale = Czm->fUIScale2;
				}
				ImGui::SameLine();
				if( ImGui::Button("Reset") ){
					ImGui::GetIO().FontGlobalScale = Czm->fUIScale2 = 1.0f;
				}
				if( Czm->bGBossesTabOn ){
					ImGui::Checkbox("Show Log Window", &Czm->bShowLogWindow );
				}
				ImGui::EndTabItem();
			}
			if( ImGui::BeginTabItem("Stats", nullptr, 0x0 ) ){
				{
					assert( Czm );
					assert( Czm->ppGD );
					assert( *Czm->ppGD );
					std::array<bool,64> aFlStats = czm_FlagsToArray<64>( se2.uShowEnmStats );

					ImGui::Checkbox("Enable Stats", &aFlStats[0] );//bShowEnmStatsAa
					ImGui::SameLine();
					ImGui::Checkbox("2""##JTrlkw8", &aFlStats[1] );
					ImGui::SameLine();
					ImGui::Checkbox("3""##Tt9WiTO", &aFlStats[2] );
					se2.uShowEnmStats = czm_ArrayToFlags( &aFlStats[0], aFlStats.size() );
					if( se2.uShowEnmStats & 0x1 ){ //se2.bShowEnmStatsAa
						ImGui::Text("Current room id: %s",
							czm_ToStrFmt("r%03X", int64_t((**Czm->ppGD).curRoomId_4FAC.v) ).c_str() );
						ImGui::Text("Dynamic Difficulty points/level: %u/%u",
							uint32_t((**Czm->ppGD).dynamicDifficultyPoints_4F94.v),
							uint32_t((**Czm->ppGD).dynamicDifficultyLevel_4F98.v) );
						ImGui::Text("PlayTime: %u",
							int((**Czm->ppGD).playTime_4FA4.v) );
						ImGui::Text("Chapter: %u",
							uint32_t((**Czm->ppGD).chapter_4F9A.v) );
					}
					if( se2.uShowEnmStats & 0x2 ){
						ImGui::Text("Kill Count c/g: %u/%u",
							uint32_t((**Czm->ppGD).c_kill_cnt_8464.v),
							uint32_t((**Czm->ppGD).g_kill_cnt_8468.v) );
						ImGui::Text("Continue count: %u",
							uint32_t((**Czm->ppGD).r_continue_cnt_4FA0.v) );
						ImGui::Text("Hit count c/g: %u/%u",
							((**Czm->ppGD).c_hit_cnt_846C.v),
							((**Czm->ppGD).g_hit_cnt_8470.v) );
						ImGui::Text("Shot count c/g: %u/%u",
							((**Czm->ppGD).c_shot_cnt_8474.v),
							((**Czm->ppGD).g_shot_cnt_8478.v) );
						{
							CzmRE4Vec vp2 = { 0.f, 0.f, 0.f,};
							if( Czm->ppPlayerGD && *Czm->ppPlayerGD ){
								vp2 = (**Czm->ppPlayerGD).position_94.v;
							}
							ImGui::Text("Player pos (f32): [%f, %f, %f]", vp2.x, vp2.y, vp2.z );
							CzmRE4Svec vs2 = czm_ConvPosToRE4Svec( vp2 );
							ImGui::Text("Player pos (hex): [%02X %02X %02X %02X %02X %02X]",
									((uint8_t*)&vs2.x)[0],
									((uint8_t*)&vs2.x)[1],
									((uint8_t*)&vs2.y)[0],
									((uint8_t*)&vs2.y)[1],
									((uint8_t*)&vs2.z)[0],
									((uint8_t*)&vs2.z)[1] );
						}
					}
					if( se2.uShowEnmStats & 0x4 ){
						ImGui::Text("Current Enemies (%u):", Czm->aCurEnmList.size() );
						if( Czm->aCurEnmList.empty() ){
							ImGui::Text("    <empty-list>");
						}else{
							auto ir2 = Czm->aCurEnmList.begin();
							for( int ii2 = 0; ir2 != Czm->aCurEnmList.end(); ++ir2, ii2++ ){
								//ir2 : CzmRE4Enemy
								ImGui::Text("%-2d: [%02X,%02X] h:%4d/%-4d, uid:%3u, "
									"F:%08X-%08X-%08X",
									(int)ii2+1,
									ir2->id_100.v,
									ir2->type_101.v,
									ir2->hp_324.v,
									ir2->hp_max_326.v,
									ir2->guid_F8.v,
									ir2->flag_3D0.v,
									ir2->be_flag_4.v,
									ir2->m_StatusFlag_3CC.v
									//ir2->Item_id_3DE.v,
									//ir2->Item_num_3E0.v,
									//ir2->Item_flg_3E2.v,
									//ir2->Auto_item_flg_3E4.v,
									//ir2->flags_3E8.v
									);
							}
						}
					}
				}
				ImGui::EndTabItem();
				Czm->bStatsEnabled = 1L;
			}
			if( ImGui::BeginTabItem("About", nullptr, 0x0 ) ){
				if( Czm->srVersionCalc.empty() ){
					Czm->srVersionCalc = czm_CalcProgramVersion();
				}
				ImGui::Indent( ImGui::GetWindowSize().x * 0.05f );
				ImGui::Text("");
				std::string srNameText;
				srNameText = hxdw_StrPrintf("\n\x20\x20%a\x20\x20\n\x20",
					{ std::string(Czm->szAppName),});
				ImGui::Button( srNameText.c_str() );
				ImGui::Text("");
				ImGui::Text("Version: %s", Czm->srVersionCalc.c_str() );
				ImGui::Text("");
				ImGui::Text("Author: ike9000" );
				ImGui::Text("");
				ImGui::Text("Web page: %s", CZM_APP_URL );
				//ImGui::Button("");
				ImGui::Unindent();
				ImGui::EndTabItem();
			}
			ImGui::EndTabBar();
		}
		Czm->cSettingsWndGmtr.updateOnWindowEnd();
		ImGui::End();
		if( !se2.equalsWith( Czm->se3 ) ){
			czm_Print2("!::equalsWith(), [%a]-[%a]\n", {
					(int)se2.uShowEnmStats,
					(int)Czm->se3.uShowEnmStats,});
			czm_UpdateSettingsViaCallbacks( se2, Czm->se3, 0L );
			Czm->se3 = se2;
		}
	}
}
void czm_CreateWeaponTypeUIItems( std::string* srIoWpnFlags_ )
{
	static_assert( sizeof(int) >= sizeof(bool), "");
	assert( Czm );
	std::string& srIoWpnFlags3 = *srIoWpnFlags_;
	std::vector<int> aWpnCheckFlags2;
	{
		srIoWpnFlags3.resize( czm_GetWeaponTypeCount(), '-');
		aWpnCheckFlags2.resize( czm_GetWeaponTypeCount(), 0 );
		std::transform( srIoWpnFlags3.begin(), srIoWpnFlags3.end(), aWpnCheckFlags2.begin(),
				[]( char a )->int{ return a == 'x'; });
	}
	auto lmbCheckByWpnGrTy = [&]( CZM_EWGR eWGrTy )->void{
		const std::vector<CZM_EWT> guns2 = czm_GetWeaponGroupTypeWeapons( eWGrTy );
		const bool bShiftDown = ImGui::GetIO().KeyShift;
		size_t ii3 = 0;
		for( auto& flg : aWpnCheckFlags2 ){
			auto rs3 = czm_GetWeaponTypeByIndex( ii3 );
			bool flg2 = std::any_of( guns2.begin(), guns2.end(),
					[&rs3]( CZM_EWT a )->bool{
						return +rs3 == a;
					});
			flg = ( bShiftDown && flg ? flg : flg2 );
			ii3++;
		}
	};
	const int nNumCols = 3;
	if( ImGui::BeginTable("table_hNaOSq", nNumCols, 0u) ){
		{
			size_t ii2;
			CzmPair<bool,CZM_EWT> rs3;
			for( ii2 = 0; *(rs3 = czm_GetWeaponTypeByIndex(ii2)); ii2++ ){
				if( !( ii2 % nNumCols ) ){
					ImGui::TableNextRow( 0u, 4);
				}
				ImGui::TableNextColumn();
				std::string sr2 = czm_GetWeaponTypeName2( +rs3, 0L );

				assert( ii2 < aWpnCheckFlags2.size() );
				bool* ptr = (bool*) &aWpnCheckFlags2[ii2];
				ImGui::Checkbox( sr2.c_str(), ptr );
			}
			assert( ii2 == czm_GetWeaponTypeCount() );
		}
		ImGui::EndTable();
		//
		if( ImGui::Button("Clear Selection") ){
			for( auto& a : aWpnCheckFlags2 )
				a = 0L;
		}
		ImGui::SameLine();
		if( ImGui::Button("Invert Selection") ){
			for( auto& a : aWpnCheckFlags2 )
				a = !a;
		}
		if( ImGui::Button("Select Pistols") ){
			lmbCheckByWpnGrTy( CZM_EWGR::CZM_E5_Pistols );
		}
		ImGui::SameLine();
		if( ImGui::Button("Select Shotguns") ){
			lmbCheckByWpnGrTy( CZM_EWGR::CZM_E5_Shotguns );
		}
		ImGui::SameLine();
		if( ImGui::Button("Select Rifles") ){
			lmbCheckByWpnGrTy( CZM_EWGR::CZM_E5_Rifles );
		}
		if( ImGui::Button("Select Magnums") ){
			lmbCheckByWpnGrTy( CZM_EWGR::CZM_E5_Magnums );
		}
		ImGui::SameLine();
		if( ImGui::Button("Select Mele") ){
			lmbCheckByWpnGrTy( CZM_EWGR::CZM_E5_Mele );
		}
		ImGui::SameLine();
		if( ImGui::Button("Select Explosives") ){
			lmbCheckByWpnGrTy( CZM_EWGR::CZM_E5_Explosives );
		}
		if( ImGui::Button("Select Cheat Weapons") ){
			lmbCheckByWpnGrTy( CZM_EWGR::CZM_E5_CheatWeapons );
		}
		{
			assert( aWpnCheckFlags2.size() == srIoWpnFlags3.size() );
			std::transform( aWpnCheckFlags2.begin(), aWpnCheckFlags2.end(), srIoWpnFlags3.begin(),
				[]( int a )->char{ return a ? 'x' : '-'; });
		}
	}
}
void czm_UpdateFromConfigFile()
{
	assert( Czm );
	Czm->srSelfFullPath  = hxdw_GetModuleFileNameFromAddr( czm_UpdateFromConfigFile );
	Czm->srSelfDir       = hxdw_SplitPath( Czm->srSelfFullPath ).first;
	Czm->srSelfBaseName  = hxdw_SplitPath( Czm->srSelfFullPath ).second;
	Czm->srSelfIniPath   = hxdw_StrPrintf("%a\\%a.ini", { Czm->srSelfDir, ( hxdw_SplitExt(Czm->srSelfBaseName).first),});
	Czm->srSelfDbfPath   = hxdw_StrPrintf("%a\\%a.bin", { Czm->srSelfDir, ( hxdw_SplitExt(Czm->srSelfBaseName).first),});
	Czm->srSelfIniBFName = hxdw_SplitPath( Czm->srSelfIniPath ).second;
	//MessageBox( 0, Czm->srSelfIniPath.c_str(), "", 0 );
	{
		assert( !Czm->ini2 );
		Czm->ini2 = new hxdw_IniData2;
	}{
		assert( !Czm->pDbfs );
		Czm->pDbfs = new FpDiskImage;
		bool rs2;
		rs2 = Czm->pDbfs->openDiskImage( Czm->srSelfDbfPath.c_str(), "");
		assert( rs2 && "Couldn't open configuration database [C4tzMoL]" );
		{
			//Czm->pDbfs->putVFileBytes2(
			//		Czm->srDllConfVBFName.c_str(), (const uint8_t*)"", 0, "r" );
			std::vector<uint8_t> data2;
			data2 = Czm->pDbfs->getVFileBytes3( Czm->srDllConfVBFName.c_str(), 0, {0,0,}, "c" );
			*Czm->ini2 = hxdw_ParseINIData( (const char*)&data2[0], -1 );
			if( hxdw_FileExists( Czm->srSelfIniPath.c_str() ) ){
				auto ini9 = hxdw_ParseINIFile( Czm->srSelfIniPath.c_str() );
				Czm->ini2->updateFrom( ini9 );
			}
		}{
			std::vector<uint8_t> data2;
			data2 = Czm->pDbfs->getVFileBytes3( Czm->srSettingsIniVFname.c_str(), 0, {0,0,}, "c" );
			auto ini4 = hxdw_ParseINIData( (const char*)&data2[0], -1 );
			Czm->se3.deserialize3( ini4 );
		}
	}{
		assert( Czm->ini2 );
		Czm->bShowStartupTip = std::atoi(
			Czm->ini2->getValue("s_main", "bShowStartupTip", "1").c_str() );
		Czm->bAllocConsoleFlag = std::atoi(
			Czm->ini2->getValue("s_main", "bAllocConsoleFlag", "0").c_str() );
		Czm->bStayDormant = std::atoi(
			Czm->ini2->getValue("s_main", "bStayDormant", "0").c_str() );
		Czm->bDbgFeaturesOn = std::atoi(
			Czm->ini2->getValue("s_main", "bDbgFeaturesOn", "0").c_str() );
		std::string sr2;
		if( !(sr2 = Czm->ini2->getValue("s_main", "anUIKeySuite", "116")).empty() ){
			Czm->anUIKeySuite = czm_DecodeHotKeySuite( sr2, {VK_F5,} );  // VK_F5=0x74=116_d
			assert( !Czm->anUIKeySuite.empty() );
		}
	}
}
/// Calculates program version from executable file contents via MD5 checksums in INI.
std::string czm_CalcProgramVersion()
{
	assert( Czm );
	assert( Czm->ini2 );
	const char* szUnkVerText = "unknown";
	std::string srMd5x;
	{
		std::vector<uint8_t> data2;
		data2 = hxdw_GetBinaryFileContents( Czm->srSelfFullPath.c_str(), 32*1000*1024 );
		if( data2.empty() ){
			return szUnkVerText;
		}
		{
			HxdwMd5 cMd5;
			cMd5.update2( &data2[0], (uint32_t) data2.size() );
			cMd5.finalize2();
			srMd5x = cMd5.getHexDigest();
		}
	}
	std::string srVersion;
	Czm->ini2->eachVariable( {"s_versions",},
		[&]( const char* sec_, const char* kname, const char* value2 )->bool{
			if( !hxdw_StrCmpOpt( srMd5x.c_str(), kname, -1, "i") ){
				srVersion = value2;
				return 0L;
			}
			return 1L;
	});
	if( srVersion.empty() ){
		return szUnkVerText;
	}
	return srVersion;
}
bool CzmHotPatchMgr::SHpDep::operator==( CZM_EHPT e )const
{
	return e == eHpTy2;
}
void CzmHotPatchMgr::
addHotPatchDependency( const std::vector<CZM_EHPT>& list2, const char* szGuid )
{
	assert( szGuid );
	assert( *szGuid );
	// check for ones already exitsting, add ref-count or create new.
	for( auto ir2 = list2.begin(); ir2 != list2.end(); ++ir2 ){
		auto ir3 = std::find( aHPatches.begin(), aHPatches.end(), *ir2 );
		if( ir3 == aHPatches.end() ){
			SHpDep hpd2;
			hpd2.eHpTy2  = *ir2;
			hpd2.pHPatch = czm_CreateHotPatchByType( *ir2 );
			hpd2.aGuids.push_back( szGuid );
			assert( hpd2.pHPatch );
			int rs2 = hpd2.pHPatch->install2();
			assert( !rs2 );
			aHPatches.push_back( hpd2 );
		}else{
			bool bExists = std::any_of( ir3->aGuids.begin(), ir3->aGuids.end(),
					[&]( const std::string& a )->bool{ return a == szGuid; } );
			if( !bExists ){
				ir3->aGuids.push_back( szGuid );
			}
		}
	}
}
void CzmHotPatchMgr::
removeHotPatchDependency( const std::vector<CZM_EHPT>& list2, const char* szGuid )
{
	assert( szGuid );
	assert( *szGuid );
	for( auto ir2 = list2.begin(); ir2 != list2.end(); ++ir2 ){
		auto ir3 = std::find( aHPatches.begin(), aHPatches.end(), *ir2 );
		if( ir3 != aHPatches.end() ){
			auto ir4 = std::find( ir3->aGuids.begin(), ir3->aGuids.end(), std::string(szGuid) );
			if( ir4 != ir3->aGuids.end() ){
				ir3->aGuids.erase(ir4);
				if( ir3->aGuids.empty() ){
					assert( ir3->pHPatch );
					int rs2 = ir3->pHPatch->uninstall2();
					assert( !rs2 );
					czm_DeleteHotPatch( ir3->pHPatch );
					aHPatches.erase( ir3 );
					//ir3 = aHPatches.end();
				}
			}
		}
	}
}
/*
template<class Txx>
const char* czm_ToCStr( Txx inp )
{
	static size_t index2 = 0;
	static std::vector<std::string> aBfr( 16, "");
	aBfr[index2] = std::to_string(inp);
	size_t old_index = index2;
	index2 += 1;
	if( index2 == aBfr.size() )
		index2 = 0;
	assert( index2 < aBfr.size() );
	return aBfr[old_index].c_str();
}
template const char* czm_ToCStr<int>( int inp );//*/

void czm_UpdateSettingsViaCallbacks( const CzmSettings& seNew, const CzmSettings& seOld, bool bAll )
{
	const CzmSettings& snw = seNew, &sbb = seOld;
	if( snw.bCritDmgScale != sbb.bCritDmgScale || snw.fCritDmgScale2 != sbb.fCritDmgScale2 || bAll ){
		czm_EachHotPred2( [&]( const CzmEachHPatchDTO& in2){
			in2.hp3->setCriticalDamageScale( snw.bCritDmgScale ? snw.fCritDmgScale2 : 1.f );
		});
	}
	if( snw.bCutscSkip2 != sbb.bCutscSkip2 || bAll ){
		czm_EachHotPred2( [&]( const CzmEachHPatchDTO& in2){
			in2.hp3->setCutsceneSkipEnabled( snw.bCutscSkip2 );
		});
	}
	if( snw.bDeltaCutscSkip != sbb.bDeltaCutscSkip || bAll ){
		czm_EachHotPred2( [&]( const CzmEachHPatchDTO& in2){
			in2.hp3->setCutsceneDeltaSkipable( snw.bDeltaCutscSkip );
		});
	}
	if( snw.bDelLagoKO != sbb.bDelLagoKO || bAll ){
		czm_EachHotPred2( [&]( const CzmEachHPatchDTO& in2){
			in2.hp3->setDelLagoInstaKO( snw.bDelLagoKO );
		});
	}
	if( snw.bYclAb != sbb.bYclAb || bAll ){
		czm_EachHotPred2( [&]( const CzmEachHPatchDTO& in2){
			in2.hp3->setCanLeaveAshleyBehind( snw.bYclAb );
		});
	}
	if( snw.bMrchWASkip != sbb.bMrchWASkip || bAll ){
		czm_EachHotPred2( [&]( const CzmEachHPatchDTO& in2){
			in2.hp3->setMerchantWelcomeAnimSkip( snw.bMrchWASkip );
		});
	}
	if( snw.bPlagasOvr != sbb.bPlagasOvr || bAll ){
		czm_EachHotPred2( [&]( const CzmEachHPatchDTO& in2){
			in2.hp3->setParasiteSpawnManipEnabled( snw.bPlagasOvr );
		});
	}
	if( snw.nPrsChance != sbb.nPrsChance || bAll ){
		float fPrsChance = float(float(snw.nPrsChance) / 100.f);
		czm_EachHotPred2( [&]( const CzmEachHPatchDTO& in2){
			in2.hp3->setParasiteSpawnChance( fPrsChance );
		});
	}
	if( snw.bPrsSpwNoLimit != sbb.bPrsSpwNoLimit || bAll ){
		czm_EachHotPred2( [&]( const CzmEachHPatchDTO& in2){
			in2.hp3->setParasiteSpawnNoLimit( snw.bPrsSpwNoLimit );
		});
	}
	if( snw.bNoTypeCParasite != sbb.bNoTypeCParasite || bAll ){
		czm_EachHotPred2( [&]( const CzmEachHPatchDTO& in2){
			in2.hp3->setDisableTypeCParasite( snw.bNoTypeCParasite );
		});
	}
	if( snw.bNoParasiteChOne != sbb.bNoParasiteChOne || bAll ){
		czm_EachHotPred2( [&]( const CzmEachHPatchDTO& in2){
			in2.hp3->setNoParasiteInIntialChapters( snw.bNoParasiteChOne );
		});
	}
	//if( snw.bShowEnmStatsAa != sbb.bShowEnmStatsAa || bAll ){}
	if( snw.uShowEnmStats != sbb.uShowEnmStats || bAll ){
		czm_EachHotPred2( [&]( const CzmEachHPatchDTO& in2){
			//in2.hp3->setEnemyStatsEnabled( !!snw.bShowEnmStatsAa );
			in2.hp3->setEnemyStatsEnabled( !!snw.uShowEnmStats );
		});
	}
	if( snw.srWpnCheckFlags4 != sbb.srWpnCheckFlags4 || bAll ){
		std::vector<int> aWpnCheckFlags3;
		aWpnCheckFlags3.resize( snw.srWpnCheckFlags4.size(), 0L );
		std::transform( snw.srWpnCheckFlags4.begin(), snw.srWpnCheckFlags4.end(), aWpnCheckFlags3.begin(),
				[]( char a )->int{ return a == 'x'; });
		auto ls2 = czm_CnvWeaponTypeIndexesToTypes( aWpnCheckFlags3 );
		czm_EachHotPred2( [&ls2]( const CzmEachHPatchDTO& in2){
			in2.hp3->setAlterableDamageTypes( ls2 );
		});
	}
}
std::vector<int> czm_DecodeHotKeySuite( std::string inp, const std::vector<int>& dflt2 )
{
	std::vector<int> outp;
	std::vector<std::string> parts2;
	hxdw_StrExplode( inp.c_str(), parts2, {"+",",",}, 8, "\x20\t", "");
	for( auto ir2 = parts2.begin(); ir2 != parts2.end(); ++ir2 ){
		int key2 = atoi( ir2->c_str() );
		if( key2 ){
			outp.push_back( key2 );
		}
	}
	return outp;
}
bool
czm_TestHotKeyOnKeyDownMessage( const std::vector<int>& aSuite, int nFirstKeyFromMsg )
{
	assert( nFirstKeyFromMsg );
	auto b = std::find( aSuite.begin(), aSuite.end(), nFirstKeyFromMsg );
	if( b == aSuite.end() ){
		return 0L;
	}
	for( auto a = aSuite.begin(); a != aSuite.end(); ++a ){
		if( b != a ){
			if( !(0x8000 & GetAsyncKeyState(*a)) ){
				return 0L;
			}
		}
	}
	return 1L;
}
