#include "czm_reiv_tools.h"
#include <assert.h>
//#include "hxdw_utils.h"
#include "hxdw_process.h"
#include "czm_interfaces.h"
#include "czm_utils.h"

uint32_t czm_CallMemberFuncViaEcx( void* thisptr2, void* fnc2, uint32_t* pArgs, uint32_t nNumArgs )
{
	uint32_t retval;
	retval = 0;
	__asm{
			mov   ecx, 0
		lb_begin2:
			cmp   ecx, nNumArgs
			jz    lb_done2
			mov   eax, pArgs
			mov   eax, [eax+ecx*4]
			push  eax
			inc   ecx
			jmp   lb_begin2
		lb_done2:
			mov ecx, thisptr2   ;// this-ptr in ECX
			call fnc2
			mov retval, eax
	}
	return retval;
}

/// Converts position. Returns f32 vector.
CzmRE4Vec czm_ConvRE4SvecToPos( const CzmRE4Svec& vec16 )
{
	CzmRE4Vec ou2;
	ou2.x = float( static_cast<double>( vec16.x ) * 10.0 );
	ou2.y = float( static_cast<double>( vec16.y ) * 10.0 );
	ou2.z = float( static_cast<double>( vec16.z ) * 10.0 );
	return ou2;
}
CzmRE4Svec czm_ConvPosToRE4Svec( const CzmRE4Vec& vec )
{
	CzmRE4Svec outp;
	static_assert( std::is_same<decltype(outp.x),int16_t>::value, "");
	outp.x = int16_t( static_cast<double>( vec.x ) / 10.0 );
	outp.y = int16_t( static_cast<double>( vec.y ) / 10.0 );
	outp.z = int16_t( static_cast<double>( vec.z ) / 10.0 );
	return outp;
}

CzmRE4Vec czm_ConvRE4SvecToRotation( const CzmRE4Svec& vec16 )
{
	CzmRE4Vec outp;
	// auto pFltSix = (float*)hxdw_GetPtrGivenInSectionOffset( 0, 0, ".data", 0xE3F4 );
	// assert( *pFltSix == 6.2831855f );
	constexpr float fFltSix = 6.2831855f;
	constexpr double v11 = double(fFltSix) * 0.000030517578125;
	outp.x = float( static_cast<double>(vec16.x) * v11 );
	outp.y = float( static_cast<double>(vec16.y) * v11 );
	outp.z = float( static_cast<double>(vec16.z) * v11 );
	return outp;
}

const std::vector< std::tuple<CZM_EWT,std::string,std::string> > CzmWeaponNames = {
	{CZM_EWT::CZM_E3_Punisher,"CZM_E3_Punisher","Punisher",},
	{CZM_EWT::CZM_E3_Handgun,"CZM_E3_Handgun","Handgun",},
	{CZM_EWT::CZM_E3_Red9,"CZM_E3_Red9","Red9",},
	{CZM_EWT::CZM_E3_Blacktail,"CZM_E3_Blacktail","Blacktail",},
	{CZM_EWT::CZM_E3_Matilda,"CZM_E3_Matilda","Matilda",},
	{CZM_EWT::CZM_E3_TMP,"CZM_E3_TMP","T.M.P.",},
	{CZM_EWT::CZM_E3_Kick,"CZM_E3_Kick","Kick",},
	{CZM_EWT::CZM_E3_Knife,"CZM_E3_Knife","Knife",},
	{CZM_EWT::CZM_E3_ChicagoTypewriter,"CZM_E3_ChicagoTypewriter","ChicagoTypewriter",},
	{CZM_EWT::CZM_E3_RocketLauncher,"CZM_E3_RocketLauncher","RocketLauncher",},
	{CZM_EWT::CZM_E3_RiffleSemiauto,"CZM_E3_RiffleSemiauto","RiffleSemiauto",},
	{CZM_EWT::CZM_E3_HuntingRiffle,"CZM_E3_HuntingRiffle","HuntingRiffle",},
	{CZM_EWT::CZM_E3_BrokenButterfly,"CZM_E3_BrokenButterfly","BrokenButterfly",},
	{CZM_EWT::CZM_E3_Killer7,"CZM_E3_Killer7","Killer7",},
	{CZM_EWT::CZM_E3_Handcannon,"CZM_E3_Handcannon","Handcannon",},
	{CZM_EWT::CZM_E3_MineThrower,"CZM_E3_MineThrower","MineThrower",},
	{CZM_EWT::CZM_E3_Shotgun,"CZM_E3_Shotgun","Shotgun",},
	{CZM_EWT::CZM_E3_Striker,"CZM_E3_Striker","Striker",},
	{CZM_EWT::CZM_E3_RiotGun,"CZM_E3_RiotGun","RiotGun",},
	{CZM_EWT::CZM_E3_Explosion,"CZM_E3_Explosion","Explosion",},
	{CZM_EWT::CZM_E3_FlashGrenade,"CZM_E3_FlashGrenade","FlashGrenade",},
};
std::string czm_GetWeaponTypeName2( CZM_EWT eWeaponType, bool bGetAsEnum )
{
	for( auto ir2 = CzmWeaponNames.begin(); ir2 != CzmWeaponNames.end(); ++ir2 ){
		if( eWeaponType == std::get<0>( *ir2 ) ){
			return (bGetAsEnum ? std::get<1>( *ir2 ) : std::get<2>( *ir2 ));
		}
	}
	return "<unknown_7GHrlY>";
}
CzmPair<bool,CZM_EWT>
czm_GetWeaponTypeByIndex( size_t index2 )
{
	if( index2 < CzmWeaponNames.size() ){
		CZM_EWT eWeaponType = std::get<0>( CzmWeaponNames[index2] );
		return { 1L, eWeaponType,};
	}
	return { 0L, CZM_EWT::CZM_E3_Punisher,};  // not found, unknown
}
size_t czm_GetWeaponTypeCount()
{
	return CzmWeaponNames.size();
}
std::vector< CzmPair<CZM_EWGR,std::vector<CZM_EWT> > >
CzmWeaponGroups = {
	{ CZM_EWGR::CZM_E5_Pistols, {
		CZM_EWT::CZM_E3_Punisher,
		CZM_EWT::CZM_E3_Handgun,
		CZM_EWT::CZM_E3_Red9,
		CZM_EWT::CZM_E3_Blacktail,
		CZM_EWT::CZM_E3_Matilda,
		},},
	{ CZM_EWGR::CZM_E5_Shotguns, {
		CZM_EWT::CZM_E3_Shotgun,
		CZM_EWT::CZM_E3_Striker,
		CZM_EWT::CZM_E3_RiotGun,
	},},
	{ CZM_EWGR::CZM_E5_Rifles, {
		CZM_EWT::CZM_E3_RiffleSemiauto,
		CZM_EWT::CZM_E3_HuntingRiffle,
	},},
	{ CZM_EWGR::CZM_E5_Magnums, {
		CZM_EWT::CZM_E3_BrokenButterfly,
		CZM_EWT::CZM_E3_Killer7,
		CZM_EWT::CZM_E3_Handcannon,
		CZM_EWT::CZM_E3_MineThrower,
	},},
	{ CZM_EWGR::CZM_E5_Mele, {
		CZM_EWT::CZM_E3_Kick,
		CZM_EWT::CZM_E3_Knife,
		},},
	{ CZM_EWGR::CZM_E5_Explosives, {
		CZM_EWT::CZM_E3_Explosion,
		CZM_EWT::CZM_E3_FlashGrenade,
		CZM_EWT::CZM_E3_RocketLauncher,
		},},
	{ CZM_EWGR::CZM_E5_CheatWeapons, {
		CZM_EWT::CZM_E3_Handcannon,
		CZM_EWT::CZM_E3_ChicagoTypewriter,
		},},
};

std::vector<CZM_EWT>
czm_GetWeaponGroupTypeWeapons( CZM_EWGR eWpnGrTy )
{
	std::vector<CZM_EWT> outp;
	auto ir2 = CzmWeaponGroups.begin();
	for( ; ir2 != CzmWeaponGroups.end(); ++ir2 ){
		if( **ir2 == eWpnGrTy ){
			outp = ir2->second;
			break;
		}
	}
	return outp;
}
std::vector<CZM_EWT>
czm_CnvWeaponTypeIndexesToTypes( const std::vector<int>& aIndexes )
{
	std::vector<CZM_EWT> outp;
	size_t idx = 0;
	for( auto flg : aIndexes ){
		if(flg){
			auto rs2 = czm_GetWeaponTypeByIndex( idx );
			assert( *rs2 );
			outp.push_back( +rs2 );
		}
		idx++;
	}
	return outp;
}

CzmRE4EnemyFactory::CzmRE4EnemyFactory()
{
	{
		// cEm *__thiscall cManager_cEm_::create( cManager_cEm_ *this, uint32_t id );
		// - this-pointer via ECX.
		assert( !fnRE4CManagerCreate );
		void* pAtOpCode = hxdw_GetPtrGivenInSectionOffset( 0, 0, ".text", 0x1B1350 );
		fnRE4CManagerCreate = pAtOpCode;
		assert( fnRE4CManagerCreate );
	}{
		// cManager_cEm_::deleteList(cManager_cEm_ *this, cEm *a2)
		// fnRE4CManagerDeleteList -> .text+0x1AE180
		assert( !fnRE4CManagerDeleteList );
		void* pAtOpCode = hxdw_GetPtrGivenInSectionOffset( 0, 0, ".text", 0x1AE180 );
		fnRE4CManagerDeleteList = pAtOpCode;
		assert( fnRE4CManagerDeleteList );
	}{
		// void __cdecl killEm(int a1)
		// fnRE4KillEm -> .text+0x1AE650
		assert( !fnRE4KillEm );
		void* pAtOpCode = hxdw_GetPtrGivenInSectionOffset( 0, 0, ".text", 0x1AE650 );
		fnRE4KillEm = pAtOpCode;
		assert( fnRE4KillEm );
	}{
		assert( !pEmMgr );
		pEmMgr = (CzmRe4EnmyMgr*)hxdw_GetPtrGivenInSectionOffset( 0, 0, ".data", 0xAB04 );
		assert( pEmMgr );
	}
}
CzmRE4Enemy* CzmRE4EnemyFactory::
callCManagerCreate( void* fnRE4CManagerCreate2, void** ppEmMgr2, uint32_t uTypeId )
{
	CzmRE4Enemy* retval = nullptr;
	retval = (CzmRE4Enemy*)czm_CallMemberFuncViaEcx(
			ppEmMgr2, fnRE4CManagerCreate2, &uTypeId, 1 );
	return retval;
}

/**
	Creates live enemy in the game.
	Should be called from the game main thread.
	Alternativelly, from a game task (no how-to currently).
	Code based on EmSetFromList2().
	Calls cManager_cEm_::create() via fnRE4CManagerCreate ptr.
*/
bool CzmRE4EnemyFactory::createLiveEnemy2( const CzmRE4EmList& sEmList, CzmRE4Enemy* pPlayer )
{
	assert( fnRE4CManagerCreate );
	assert( pEmMgr );
	CzmRE4Enemy* pNewEnm = callCManagerCreate( fnRE4CManagerCreate, (void**)pEmMgr, sEmList.id_1 );
	if( !pNewEnm ){
		return 0L;
	}
	//pLastEnCrtd = pNewEnm;
	mCreatLs.push_back( pNewEnm );
	//CzmRE4Enemy=EM_LIST
	pNewEnm->type_101.v = sEmList.type_2;
	pNewEnm->set_395.v = sEmList.set_3;
	pNewEnm->flag_3D0.v = sEmList.flag_4;
	pNewEnm->characterNum_3D8.v = sEmList.Character_B;
	pNewEnm->Guard_r_3D4.v = float( static_cast<double>(sEmList.Guard_r_1A) * 1000.0 );
	pNewEnm->hp_324.v = sEmList.hp_8;
	pNewEnm->hp_max_326.v = sEmList.hp_8;
	//v8=Back=CzmRE4Enemy=cEm
	pNewEnm->rotation_A0.v = czm_ConvRE4SvecToRotation( sEmList.s_ang_12 );
	pNewEnm->position_94.v = czm_ConvRE4SvecToPos( sEmList.s_pos_C );
	// originally, index in the global ESL list.
	pNewEnm->emListIndex_3A0.v = 0xFF;//0xFF;//0//0xFF//0x51//0x52
	pNewEnm->pos_old_110.v = pNewEnm->position_94.v;
	//
	// sEmList.be_flag_0 |= 2u;
	// sEmList.be_flag_0 |= ?
	//
	//assert( Czm );
	//assert( Czm->ppPlayerGD );
	//assert( *Czm->ppPlayerGD );
	//CzmRE4Enemy* pPlyr = *Czm->ppPlayerGD;
	//CzmRE4Enemy* pPlyr = pPlayer;
	//assert( pPlyr );
	// possibly just distance calculation on 2D, x-z plane.
	float v17 = pPlayer->position_94.v.x - pNewEnm->position_94.v.x;
	float v18 = pPlayer->position_94.v.z - pNewEnm->position_94.v.z;
	pNewEnm->l_pl_378.v = v18 * v18 + v17 * v17;
	pNewEnm->l_sub_37C.v = float( 1.0e16 );

	// Getting the move() virtual member function pointer:
	// (ECX -> this pointer, cEm*)
	//     // esi = cManager(...)
	//     mov     edx, [esi]       ; get vtable, the 1st pointer in the object.
	//     mov     eax, [edx+10h]   ; DWORD PTR [vtable+0x10]
	//     call    eax
	void* fnMoveAt4 = ((void***)pNewEnm)[0][4];
	assert( fnMoveAt4 );
	czm_CallMemberFuncViaEcx( pNewEnm, fnMoveAt4, nullptr, 0 );
	return 1L;
}
bool CzmRE4EnemyFactory::destroyLastLiveEnemy2()
{
	if( mCreatLs.empty() ){
		return 0L;
	}
	CzmRE4Enemy* pLastEnCrtd = *mCreatLs.rbegin();
	assert( pLastEnCrtd );
	mCreatLs.resize( mCreatLs.size() - 1 );
	//
	using fn_t = void (__cdecl*)(void* pEnmy);
	assert( fnRE4KillEm );
	((fn_t)fnRE4KillEm)( pLastEnCrtd );
	//*/
	assert( pEmMgr );
	auto lmbGetEnemyAt = [&]( uint32_t ii3 ) -> CzmRE4Enemy* {
		CzmRE4Enemy* enm4 = (CzmRE4Enemy*) ( ((uint8_t*)pEmMgr->m_Array_4.v) + ii3 * pEmMgr->m_blockSize_C.v );
		return enm4;
	};
	for( uint32_t ii2=0; ii2 < pEmMgr->m_nArray_8.v; ii2++ ){
		CzmRE4Enemy* enm3 = lmbGetEnemyAt( ii2 );
		if( enm3 == pLastEnCrtd ){
			czm_Print2("CZM: removing enemy, idx:[%a]\n", { ii2,} );
			enm3->hp_324.v = 0;
		}
	}
	return 1L;
}


