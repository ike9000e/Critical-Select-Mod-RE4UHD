#pragma once
#include <functional>  //std::function
#include <algorithm>  //std::function
#include <assert.h>
#include <string>

#define WPP_REFLECTION_WITH_FIELD_NAME 1

#define WPP_PP_EVAL_(...) __VA_ARGS__
#define WPP_PP_EAT_(...)
#define WPP_PP_EMPTY_
#define WPP_PP_STR2_(x) #x
#define WPP_PP_STR_(x) WPP_PP_STR2_(x)

// [cdZL0B] //{

#define WPP_PP_MAP_01(f, x) f(x)
#define WPP_PP_MAP_02(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_01(f, __VA_ARGS__))
#define WPP_PP_MAP_03(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_02(f, __VA_ARGS__))
#define WPP_PP_MAP_04(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_03(f, __VA_ARGS__))
#define WPP_PP_MAP_05(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_04(f, __VA_ARGS__))
#define WPP_PP_MAP_06(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_05(f, __VA_ARGS__))
#define WPP_PP_MAP_07(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_06(f, __VA_ARGS__))
#define WPP_PP_MAP_08(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_07(f, __VA_ARGS__))
#define WPP_PP_MAP_09(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_08(f, __VA_ARGS__))
#define WPP_PP_MAP_10(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_09(f, __VA_ARGS__))
#define WPP_PP_MAP_11(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_10(f, __VA_ARGS__))
#define WPP_PP_MAP_12(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_11(f, __VA_ARGS__))
#define WPP_PP_MAP_13(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_12(f, __VA_ARGS__))
#define WPP_PP_MAP_14(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_13(f, __VA_ARGS__))
#define WPP_PP_MAP_15(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_14(f, __VA_ARGS__))
#define WPP_PP_MAP_16(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_15(f, __VA_ARGS__))
#define WPP_PP_MAP_17(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_16(f, __VA_ARGS__))
#define WPP_PP_MAP_18(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_17(f, __VA_ARGS__))
#define WPP_PP_MAP_19(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_18(f, __VA_ARGS__))
#define WPP_PP_MAP_20(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_19(f, __VA_ARGS__))
#define WPP_PP_MAP_21(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_20(f, __VA_ARGS__))
#define WPP_PP_MAP_22(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_21(f, __VA_ARGS__))
#define WPP_PP_MAP_23(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_22(f, __VA_ARGS__))
#define WPP_PP_MAP_24(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_23(f, __VA_ARGS__))
#define WPP_PP_MAP_25(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_24(f, __VA_ARGS__))
#define WPP_PP_MAP_26(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_25(f, __VA_ARGS__))
#define WPP_PP_MAP_27(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_26(f, __VA_ARGS__))
#define WPP_PP_MAP_28(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_27(f, __VA_ARGS__))
#define WPP_PP_MAP_29(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_28(f, __VA_ARGS__))
#define WPP_PP_MAP_30(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_29(f, __VA_ARGS__))
#define WPP_PP_MAP_31(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_30(f, __VA_ARGS__))
#define WPP_PP_MAP_32(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_31(f, __VA_ARGS__))
#define WPP_PP_MAP_33(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_32(f, __VA_ARGS__))
#define WPP_PP_MAP_34(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_33(f, __VA_ARGS__))
#define WPP_PP_MAP_35(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_34(f, __VA_ARGS__))
#define WPP_PP_MAP_36(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_35(f, __VA_ARGS__))
#define WPP_PP_MAP_37(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_36(f, __VA_ARGS__))
#define WPP_PP_MAP_38(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_37(f, __VA_ARGS__))
#define WPP_PP_MAP_39(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_38(f, __VA_ARGS__))
#define WPP_PP_MAP_40(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_39(f, __VA_ARGS__))
#define WPP_PP_MAP_41(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_40(f, __VA_ARGS__))
#define WPP_PP_MAP_42(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_41(f, __VA_ARGS__))
#define WPP_PP_MAP_43(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_42(f, __VA_ARGS__))
#define WPP_PP_MAP_44(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_43(f, __VA_ARGS__))
#define WPP_PP_MAP_45(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_44(f, __VA_ARGS__))
#define WPP_PP_MAP_46(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_45(f, __VA_ARGS__))
#define WPP_PP_MAP_47(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_46(f, __VA_ARGS__))
#define WPP_PP_MAP_48(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_47(f, __VA_ARGS__))
#define WPP_PP_MAP_49(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_48(f, __VA_ARGS__))
#define WPP_PP_MAP_50(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_49(f, __VA_ARGS__))
#define WPP_PP_MAP_51(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_50(f, __VA_ARGS__))
#define WPP_PP_MAP_52(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_51(f, __VA_ARGS__))
#define WPP_PP_MAP_53(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_52(f, __VA_ARGS__))
#define WPP_PP_MAP_54(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_53(f, __VA_ARGS__))
#define WPP_PP_MAP_55(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_54(f, __VA_ARGS__))
#define WPP_PP_MAP_56(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_55(f, __VA_ARGS__))
#define WPP_PP_MAP_57(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_56(f, __VA_ARGS__))
#define WPP_PP_MAP_58(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_57(f, __VA_ARGS__))
#define WPP_PP_MAP_59(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_58(f, __VA_ARGS__))
#define WPP_PP_MAP_60(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_59(f, __VA_ARGS__))
#define WPP_PP_MAP_61(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_60(f, __VA_ARGS__))
#define WPP_PP_MAP_62(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_61(f, __VA_ARGS__))
#define WPP_PP_MAP_63(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_62(f, __VA_ARGS__))
#define WPP_PP_MAP_64(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_63(f, __VA_ARGS__))
#define WPP_PP_MAP_65(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_64(f, __VA_ARGS__))
#define WPP_PP_MAP_66(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_65(f, __VA_ARGS__))
#define WPP_PP_MAP_67(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_66(f, __VA_ARGS__))
#define WPP_PP_MAP_68(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_67(f, __VA_ARGS__))
#define WPP_PP_MAP_69(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_68(f, __VA_ARGS__))
#define WPP_PP_MAP_70(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_69(f, __VA_ARGS__))
#define WPP_PP_MAP_71(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_70(f, __VA_ARGS__))
#define WPP_PP_MAP_72(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_71(f, __VA_ARGS__))
#define WPP_PP_MAP_73(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_72(f, __VA_ARGS__))
#define WPP_PP_MAP_74(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_73(f, __VA_ARGS__))
#define WPP_PP_MAP_75(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_74(f, __VA_ARGS__))
#define WPP_PP_MAP_76(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_75(f, __VA_ARGS__))
#define WPP_PP_MAP_77(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_76(f, __VA_ARGS__))
#define WPP_PP_MAP_78(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_77(f, __VA_ARGS__))
#define WPP_PP_MAP_79(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_78(f, __VA_ARGS__))
#define WPP_PP_MAP_80(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_79(f, __VA_ARGS__))
#define WPP_PP_MAP_81(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_80(f, __VA_ARGS__))
#define WPP_PP_MAP_82(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_81(f, __VA_ARGS__))
#define WPP_PP_MAP_83(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_82(f, __VA_ARGS__))
#define WPP_PP_MAP_84(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_83(f, __VA_ARGS__))
#define WPP_PP_MAP_85(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_84(f, __VA_ARGS__))
#define WPP_PP_MAP_86(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_85(f, __VA_ARGS__))
#define WPP_PP_MAP_87(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_86(f, __VA_ARGS__))
#define WPP_PP_MAP_88(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_87(f, __VA_ARGS__))
#define WPP_PP_MAP_89(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_88(f, __VA_ARGS__))
#define WPP_PP_MAP_90(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_89(f, __VA_ARGS__))
#define WPP_PP_MAP_91(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_90(f, __VA_ARGS__))
#define WPP_PP_MAP_92(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_91(f, __VA_ARGS__))
#define WPP_PP_MAP_93(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_92(f, __VA_ARGS__))
#define WPP_PP_MAP_94(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_93(f, __VA_ARGS__))
#define WPP_PP_MAP_95(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_94(f, __VA_ARGS__))
#define WPP_PP_MAP_96(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_95(f, __VA_ARGS__))
#define WPP_PP_MAP_97(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_96(f, __VA_ARGS__))
#define WPP_PP_MAP_98(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_97(f, __VA_ARGS__))
#define WPP_PP_MAP_99(f, x, ...) f(x) WPP_PP_EVAL_(WPP_PP_MAP_98(f, __VA_ARGS__))

#define WPP_PP_GET_NTH_ARG_( \
	_1, _2, _3, _4, _5, _6, _7, _8, _9, _10, \
	_11, _12, _13, _14, _15, _16, _17, _18, _19, _20, \
	_21, _22, _23, _24, _25, _26, _27, _28, _29, _30, \
	_31, _32, _33, _34, _35, _36, _37, _38, _39, _40, \
	_41, _42, _43, _44, _45, _46, _47, _48, _49, _50, \
	_51, _52, _53, _54, _55, _56, _57, _58, _59, _60, \
	_61, _62, _63, _64, _65, _66, _67, _68, _69, _70, \
	_71, _72, _73, _74, _75, _76, _77, _78, _79, _80, \
	_81, _82, _83, _84, _85, _86, _87, _88, _89, _90, \
	_91, _92, _93, _94, _95, _96, _97, _98, _99, N, ...) N

#define WPP_PP_MAP_(f, ...) WPP_PP_EVAL_(WPP_PP_EVAL_(WPP_PP_GET_NTH_ARG_(__VA_ARGS__, \
	WPP_PP_MAP_99, WPP_PP_MAP_98, WPP_PP_MAP_97, WPP_PP_MAP_96, \
	WPP_PP_MAP_95, WPP_PP_MAP_94, WPP_PP_MAP_93, WPP_PP_MAP_92, WPP_PP_MAP_91, \
	WPP_PP_MAP_90, WPP_PP_MAP_89, WPP_PP_MAP_88, WPP_PP_MAP_87, WPP_PP_MAP_86, \
	WPP_PP_MAP_85, WPP_PP_MAP_84, WPP_PP_MAP_83, WPP_PP_MAP_82, WPP_PP_MAP_81, \
	WPP_PP_MAP_80, WPP_PP_MAP_79, WPP_PP_MAP_78, WPP_PP_MAP_77, WPP_PP_MAP_76, \
	WPP_PP_MAP_75, WPP_PP_MAP_74, WPP_PP_MAP_73, WPP_PP_MAP_72, WPP_PP_MAP_71, \
	WPP_PP_MAP_70, WPP_PP_MAP_69, WPP_PP_MAP_68, WPP_PP_MAP_67, WPP_PP_MAP_66, \
	WPP_PP_MAP_65, WPP_PP_MAP_64, WPP_PP_MAP_63, WPP_PP_MAP_62, WPP_PP_MAP_61, \
	WPP_PP_MAP_60, WPP_PP_MAP_59, WPP_PP_MAP_58, WPP_PP_MAP_57, WPP_PP_MAP_56, \
	WPP_PP_MAP_55, WPP_PP_MAP_54, WPP_PP_MAP_53, WPP_PP_MAP_52, WPP_PP_MAP_51, \
	WPP_PP_MAP_50, WPP_PP_MAP_49, WPP_PP_MAP_48, WPP_PP_MAP_47, WPP_PP_MAP_46, \
	WPP_PP_MAP_45, WPP_PP_MAP_44, WPP_PP_MAP_43, WPP_PP_MAP_42, WPP_PP_MAP_41, \
	WPP_PP_MAP_40, WPP_PP_MAP_39, WPP_PP_MAP_38, WPP_PP_MAP_37, WPP_PP_MAP_36, \
	WPP_PP_MAP_35, WPP_PP_MAP_34, WPP_PP_MAP_33, WPP_PP_MAP_32, WPP_PP_MAP_31, \
	WPP_PP_MAP_30, WPP_PP_MAP_29, WPP_PP_MAP_28, WPP_PP_MAP_27, WPP_PP_MAP_26, \
	WPP_PP_MAP_25, WPP_PP_MAP_24, WPP_PP_MAP_23, WPP_PP_MAP_22, WPP_PP_MAP_21, \
	WPP_PP_MAP_20, WPP_PP_MAP_19, WPP_PP_MAP_18, WPP_PP_MAP_17, WPP_PP_MAP_16, \
	WPP_PP_MAP_15, WPP_PP_MAP_14, WPP_PP_MAP_13, WPP_PP_MAP_12, WPP_PP_MAP_11, \
	WPP_PP_MAP_10, WPP_PP_MAP_09, WPP_PP_MAP_08, WPP_PP_MAP_07, WPP_PP_MAP_06, \
	WPP_PP_MAP_05, WPP_PP_MAP_04, WPP_PP_MAP_03, WPP_PP_MAP_02, WPP_PP_MAP_01 \
	))(f, __VA_ARGS__))

// [cdZL0B] //}

#if WPP_REFLECTION_WITH_FIELD_NAME
	#define WPP_PP_REFLECTION_FIELD_NAME_(x) WPP_PP_STR_(WPP_PP_EVAL_(x))
#else
	#define WPP_PP_REFLECTION_FIELD_NAME_(x) ""
#endif

#define WPP_PP_REFLECTION_ALL_(x) WPP_PP_EVAL_ x
#define WPP_PP_REFLECTION_SECOND_(x) WPP_PP_EAT_ x
#define WPP_PP_REFLECTION_FIELD_(x) WPP_PP_REFLECTION_ALL_(x);
#define WPP_PP_REFLECTION_METHOD2_(x) v(this, WPP_PP_REFLECTION_FIELD_NAME_(x), x);
#define WPP_PP_REFLECTION_METHOD_(x) WPP_PP_REFLECTION_METHOD2_(WPP_PP_REFLECTION_SECOND_(x))

#define WPP_PP_REFLECTION_VISTOR_METHOD_(type, ...) \
	template <class Vistor> \
	void wpp_reflect_method_(Vistor& v) type { \
		WPP_PP_MAP_(WPP_PP_REFLECTION_METHOD_, __VA_ARGS__) \
	}

#define WPP_REFLECT(...) \
	WPP_PP_MAP_(WPP_PP_REFLECTION_FIELD_, __VA_ARGS__) \
	WPP_PP_REFLECTION_VISTOR_METHOD_(WPP_PP_EMPTY_, __VA_ARGS__) \
	WPP_PP_REFLECTION_VISTOR_METHOD_(const, __VA_ARGS__)


// Usage of WPP_REFLECT()

#define WPP_OBJECT_NAME_METHOD(obj) \
	static const char* wpp_object_name_method_() { \
		return #obj; \
	}

template<class Txx>
struct WppAmplifier
{
	WppAmplifier( std::string name_, Txx value2 ) : mValue2(value2), mName2(name_) {}
	template<class Obj>
	void apply2( Obj* obj ){
		obj->wpp_reflect_method_(*this);
	}
	template<class Obj, class TField>
	void operator()( Obj*, const char* name2, TField& field2 ){
		if( mName2 == name2 ){
			//field2 = mValue2; //printf("name2: [%s]\n", name2 );
			field2 = atoi( mValue2.c_str() );
		}
	}
	template<class Obj>
	void operator()( Obj*, const char* name2, float& field4 ){
		if( mName2 == name2 ){
			field4 = float( atof( mValue2.c_str() ) );
		}
	}
	template<class Obj>
	void operator()( Obj*, const char* name2, uint64_t& field5 ){
		if( mName2 == name2 ){
			static_assert( sizeof(unsigned long long) >= 8, "");
			field5 = std::strtoull( mValue2.c_str(), 0, 10 );
		}
	}
	template<class Obj>
	void operator()( Obj*, const char* name2, std::string& field3 ){
		if( mName2 == name2 ){
			field3 = mValue2.c_str();
		}
	}
	Txx mValue2;
	std::string mName2;
};

/// Default variant used to convert all values to string.
/// Can be used as base in derived class to add more types.
struct WppRflDfltVariant
{
	void operator()( char a ) {Outp = std::to_string(a);}
	void operator()( unsigned char a ) {Outp = std::to_string(a);}

	void operator()( int32_t a ) {Outp = std::to_string(a);}
	void operator()( uint32_t a ) {Outp = std::to_string(a)+"_u";}
	void operator()( uint64_t a ) {Outp = std::to_string(a)+"_U";}
	void operator()( float a ) {Outp = std::to_string(a);}
	void operator()( std::string a ) {Outp = a;}
	void operator()( const char* a ) {Outp = std::string(a);}
	//
	std::string to_string()const {return Outp;}
protected:
	std::string Outp;
};

template<class TArg1Printer = WppRflDfltVariant>
struct WppPrinter
{
	using WppPrintCalbTy = std::function<void( std::string name2, std::string field_text )>;

	template<class Obj>
	void print2( const Obj& obj, WppPrintCalbTy calb3 ) {
		Calb2 = calb3;
		obj.wpp_reflect_method_(*this);
	}
	template<class Obj, class TField>
	void operator()( Obj* obj, const char* name2, const TField& field2 )
	{
		//std::cout << obj->wpp_object_name_method_() << "."
		//	<< name2 << ": " << field2 << std::endl;  //<iostream>
		TArg1Printer prntr;
		prntr( field2 );
		assert( Calb2 );
		Calb2( name2, prntr.to_string().c_str() );
	}
private:
	WppPrintCalbTy Calb2 = nullptr;
};

void WppReflectioDemo();
