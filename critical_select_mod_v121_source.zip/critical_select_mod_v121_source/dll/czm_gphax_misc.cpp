#include "czm_gphax_misc.h"
#include <assert.h>
#include <typeinfo>
#include "MinHook.h"
#include "hxdw_utils.h"
#include "hxdw_process.h"
#include "czm_utils.h"
#include "czm_interfaces.h"

CzmGpData* Gpd = nullptr;   //as extern in the .h file.
char bfr2[256], bfr3[256];

uint32_t __cdecl czm_OnRoomLoad( uint32_t arg1, uint32_t arg2 )
{
	//assert( Gpd );
	//assert( Gpd->ppGD );
	//CzmRE4GlobDt* pRoomDt = *Gpd->ppGD;
	assert( Czm );
	assert( Czm->ppGD );
	CzmRE4GlobDt* pRoomDt = *Czm->ppGD;

	{
		//static int cos2 = 3;
		//pRoomDt->plCostume_4FC9.v = (uint8_t)cos2;
		//cos2 = cos2 == 3 ? 0 : 3;

		snprintf( bfr2, sizeof(bfr2), "0x%X", (int)(pRoomDt->pokeRoomIdValue()) );
		czm_Print2(
			"CZM: czm_OnRoomLoad(), room-id: %a, gold: %a, "
			"killcnt: %a/%a\n",{
				std::string(bfr2),
				pRoomDt->goldAmount_4FA8.v,
				(int)pRoomDt->c_kill_cnt_8464.v,
				(int)pRoomDt->g_kill_cnt_8468.v,
				});
	}
	using fn_t = decltype(czm_OnRoomLoad)*;
	assert( czm_OgOnRoomLoad );

	uint32_t retv = ((fn_t)czm_OgOnRoomLoad)( arg1, arg2 );
	return retv;
}
// ESL_on_exit_to_the_main_menu_XC3w9F
void __stdcall czm_OnReturnToMainMenu()
{
	assert( czm_OgOnReturnToMainMenu );
	czm_Print2( "CZM: czm_OnReturnToMainMenu()\n", {} );

	//assert(Czm);
	//Czm->OnReturnToMainMenu();
	//CzmHotPredicateBase* p = 0;
	//p->notifyRoomLoad( CzmRoomLoadDTO{ CZM_ERLT::E2_ToMainMenu,0,} );
	czm_OgOnReturnToMainMenu();
}
void __stdcall CzmHPFloatToIntFeCrit::
czm_OnFloatToIntOnCritical( CZM_EWT uWeaponType, uint32_t* ptrDmgVal )
{
	if( Gpd && Gpd->aHotPreds2 ){
		czm_EachHotPred2( [&]( const CzmEachHPatchDTO& in2 ){
			CzmDmg3DTO ss4;
			ss4.uWeaponType  = uWeaponType;
			ss4.pDamgeValue  = ptrDmgVal;
			ss4.eCritDmgType = CZM_ECDT::CZM_E4_Critical;
			in2.hp3->notifyDamageNormalEnemy( ss4 );
		});
	}
}
uint8_t* CzmHPFloatToIntFeCrit::pAtCritFloatToIntRetAddr = nullptr;
/// Called in multiple places to do misc float to int conversion.
/// ESP aware function (see NOTE_618695).
uint32_t __cdecl
CzmHPFloatToIntFeCrit::czm_OnFloatToIntFeCritESPAware()
{
	static uint8_t* pEipRetAddr3 = nullptr;
	__asm{
		mov eax, dword ptr [esp+4]  // accessing ESP, this must be done at the begin.
		mov pEipRetAddr3, eax
	}
	assert( Gpd );
	static bool bCritModeOpCall = 0L;
	bCritModeOpCall = ( pEipRetAddr3 == CzmHPFloatToIntFeCrit::pAtCritFloatToIntRetAddr );
	if( bCritModeOpCall ){
		czm_Print2( "CZM: bCritModeOpCall [Crit-2]\n", {} );
	}
	using fn_t = decltype(czm_OnFloatToIntFeCritESPAware)*;
	static uint32_t retv;
	retv = ((fn_t)czm_OgOnFloatToIntFeCrit)();
	static CZM_EWT uWeaponType = (CZM_EWT)0x00;   //eg. CZM_E3_Handgun=0x02
	//uWeaponType = (CZM_EWT)0x00;
	if( bCritModeOpCall ){
		__asm{
			mov al, byte ptr [edi+0x32E]
			mov uWeaponType, al
		}
		czm_OnFloatToIntOnCritical( uWeaponType, &retv );
	}
	return retv;
}

uint8_t* CzmHPCutsceneSkips::pAtCutscASkipEipAddr = nullptr;
uint8_t* CzmHPCutsceneSkips::pAtCutscCSkipEipAddr = nullptr;
uint8_t* CzmHPCutsceneSkips::pAtCutscBAlphaTrgrPtr = nullptr;
uint32_t* CzmHPCutsceneSkips::pAtCutscBBetaTrgrPtr = nullptr;

/// Declared as fastcall to cause minimal stack adjust on call.
bool __fastcall CzmHPCutsceneSkips::
czm_KeyTrgCheckZeroOutline( uint8_t* pEipRetAddr )
{
	assert( Gpd );
	std::pair<bool,CZM_CST> bDoSkip2 = { 0L, CZM_CST::CZM_E6_TypeAlpha,};
	if( pEipRetAddr == pAtCutscASkipEipAddr ){
		bDoSkip2.first = 1L;
	}else if( pEipRetAddr == pAtCutscCSkipEipAddr ){
		bDoSkip2.first = 1L;
		bDoSkip2.second = CZM_CST::CZM_E6_TypeGamma;
	}
	bool bSkipThisCutscene2 = 0L;
	if( bDoSkip2.first ){
		if( Gpd->aHotPreds2 ){
			CzmCutscSkipDTO cs2(
				bDoSkip2.second,   //eg. CZM_CST::CZM_E6_TypeAlpha
				&bSkipThisCutscene2 );
			czm_EachHotPred2( [&]( const CzmEachHPatchDTO& in2 ){
				in2.hp3->notifyCutscenePlay( cs2 );
			});
		}
	}
	return bSkipThisCutscene2;
}
/**
	Called on various button checks, eg. cutscene cancel button.
	fmv2_cutscene_a_skip_cond
	fmv2_cutscene_c_skip_cond

	NOTE_618695: this is an ESP aware function that must not
	             do any ESP adjustments in its prologue.

	For ESP-EIP pointer scan work:
	* no local variables. ie. only local-static variables.
	* no functions that create temporary objects on call. such as std::function in parameter list.
	* no capturing lambdas.
*/
uint8_t __cdecl CzmHPCutsceneSkips::
czm_KeyTrgCheckZeroESPAware( uint32_t arg0, uint32_t arg1 )
{
	static uint8_t* pEipRetAddr2 = nullptr;
	__asm{
		mov eax, dword ptr [esp]   // accessing ESP this must be done at the begin.
		mov pEipRetAddr2, eax
	}
	assert( czm_OgKeyTrgCheckZero );
	static bool bSkipThisCutscene;
	bSkipThisCutscene = czm_KeyTrgCheckZeroOutline( pEipRetAddr2 );
	using fn_t = decltype(czm_KeyTrgCheckZeroESPAware)*;
	static uint8_t retv;
	retv = ((fn_t)czm_OgKeyTrgCheckZero)( arg0, arg1 );
	if( bSkipThisCutscene )
		retv = 1;
	return retv;
}
int8_t __cdecl CzmHPCutsceneSkips::czm_ScenarioChkEvCancel()
{
	assert( czm_OgScenarioChkEvCancel );
	assert( Gpd );
	if( pAtCutscBAlphaTrgrPtr[1] == 1 ){
		bool bSkipThisCutscene2 = 0;
		{
			CzmCutscSkipDTO cs2( CZM_CST::CZM_E6_TypeBeta, &bSkipThisCutscene2 );
			czm_EachHotPred2( [&]( const CzmEachHPatchDTO& in2 ){
				in2.hp3->notifyCutscenePlay( cs2 );
			});
		}
		if( bSkipThisCutscene2 ){
			*pAtCutscBBetaTrgrPtr |= 0x20000000;  //20000000h
		}
	}
	using fn_t = decltype(czm_ScenarioChkEvCancel)*;
	int8_t retv = ((fn_t)czm_OgScenarioChkEvCancel)();
	return retv;
}
void __fastcall CzmHPCutsceneSkips::
czm_EventxxRunOutline( uint8_t* thisptr2 )
{
	bool bSkipThisCutscene3 = 0L;
	CzmCutscSkipDTO cs2( CZM_CST::CZM_E6_TypeDelta, &bSkipThisCutscene3 );
	czm_EachHotPred2( [&]( const CzmEachHPatchDTO& in2 ){
		in2.hp3->notifyUnskippableCutscenePlay( cs2 );
	});
	if( bSkipThisCutscene3 ){
		uint32_t* ptr2 = (uint32_t*)( &thisptr2[0x44] );
		*ptr2 &= ~(1 << 0x19);  //0x19=25_d
	}
}
uint32_t __cdecl CzmHPCutsceneSkips::czm_EventxxRun()
{
	// ECX: this ptr (Event*)
	static uint8_t* pEvent2 = 0;
	static uint32_t retval;
	__asm{
		mov pEvent2, ecx
	}
	assert( czm_OgEventxxRun );
	__asm{
		mov ecx, pEvent2
		call czm_OgEventxxRun
		and eax, 0xFF
		mov retval, eax   //actually only AL part
	}
	czm_EventxxRunOutline( pEvent2 );
	return retval;
}

void __fastcall
czm_ShowEnemyInfo( CzmRE4Enemy* pEnemy, const char* szPrfx, const char* szSiff = "")
{
	static int cnt = 0;
	std::string srPrfx = (szPrfx ? szPrfx : "");
	std::string srSuff = (szSiff ? szSiff : "");
	if( !srPrfx.empty() )
		srPrfx = (std::string("\x20") + srPrfx + "\x20");
	if( !srSuff.empty() )
		srSuff = (std::string("\x20") + srSuff);
	czm_Print2("CZM: EnemyInfo:%s,%a [%a,%a] hp:%a/%a, u:%a, w:%a, kc:%a/%a %s\n",
		{ srPrfx, cnt++,
			czm_ToStrFmt("%02X", pEnemy->id_100.v ),
			czm_ToStrFmt("%02X", pEnemy->type_101.v ),
			(int)pEnemy->hp_324.v,
			(int)pEnemy->hp_max_326.v,
			std::to_string(pEnemy->guid_F8.v),
			czm_ToStrFmt("0x%02X", pEnemy->m_DmgInfo_328_Wep_6.v ),
			(**Czm->ppGD).c_kill_cnt_8464.v,
			(**Czm->ppGD).g_kill_cnt_8468.v,
			srSuff,
	});
}

void __cdecl czm_EnemyDeath( CzmRE4Enemy* pEnemy )
{
	static std::vector<uint32_t> uids2;
	bool rs2 = std::any_of( uids2.begin(), uids2.end(),
		[&]( uint32_t a )->bool{
			return (pEnemy->guid_F8.v == a);
		});
	if( !rs2 ){
		uids2.push_back( pEnemy->guid_F8.v );
	}
	//czm_ShowEnemyInfo( pEnemy, czm_ToStrFmt("DTH:%d", !rs2 ).c_str() );
	assert( czm_OgEnemyDeath );
	using fn_t = decltype(czm_EnemyDeath)*;
	((fn_t)czm_OgEnemyDeath)( pEnemy );
	czm_ShowEnemyInfo( pEnemy, czm_ToStrFmt("DTH:%d", !rs2 ).c_str() );
}
// dmg2_on_damage_enemy_or_leon_fqYhLH
int __cdecl CzmHPDmgEnemyOrPlayer::
czm_DamageEnemyOrPlayer( CzmRE4Enemy* pEnm2, int arg2, int arg3, char arg4 )
{
	assert( czm_OgDamageEnemyOrPlayer );
	const int16_t nOldHp = pEnm2->hp_324.v;

	using fn_t = decltype(czm_DamageEnemyOrPlayer)*;
	int retv = ((fn_t)czm_OgDamageEnemyOrPlayer)( pEnm2, arg2, arg3, arg4 );

	int16_t nHpLost = nOldHp - pEnm2->hp_324.v;
	nHpLost *= -1;
	czm_ShowEnemyInfo( pEnm2, "DMG  ", std::to_string(nHpLost).c_str() );

	czm_EachHotPred2( [&]( const CzmEachHPatchDTO& in2 ){
		CzmDmg2DTO ss2;
		ss2.pEnmyDtaPtr5 = pEnm2;
		in2.hp3->notifyDamageAnyEnemy2( ss2 );
	});
	return retv;
}
// BOOL __usercall em10ChgParasiteCk@<eax>(cEm10 *a1@<esi>)
uint32_t __cdecl CzmHPHeadPlagasCtrl::czm_SpwParasiteChgChk()
{
	static CzmRE4Enemy* pEnm3 = 0;
	__asm{
		mov pEnm3, esi
	}
	//czm_Print2("CZM: czm_SpwParasiteChgChk\n", {} );
	assert( pEnm3 );
	static bool bPrsOverride3, bPrsSpawnNow3;
	bPrsOverride3 = bPrsSpawnNow3 = 0L;
	//if( czm_IsNormalHumanoidEnemyType2( std::array<uint8_t,2>{ pEnm3->id_100.v, pEnm3->type_101.v,} ) ){}
	if( CzmEnemyTypeAdp(std::array<uint8_t,2>{ pEnm3->id_100.v, pEnm3->type_101.v,}).isNormalHumanoidEnemyType() ){
		czm_EachHotPred2( []( const CzmEachHPatchDTO& in2 ){
			CzmPrsDiceDTO pd2;
			pd2.bPrsOverride2 = &bPrsOverride3;
			pd2.bPrsSpawnNow2 = &bPrsSpawnNow3;
			in2.hp3->notifyDiceForParasiteSpawn( pd2 );
		});
		if( bPrsOverride3 ){
			if( bPrsSpawnNow3 ){
				pEnm3->flag_3D0.v |= 0x100000;
			}else{
				pEnm3->flag_3D0.v &= ~0x100000;
			}
			pEnm3->type_101.v = 8;   // bypasses Rnd check call.
		}
	}
	static uint32_t retv;
	__asm{
		mov esi, pEnm3
		call czm_OgSpwParasiteChgChk
		mov retv, eax
	}
	return retv;
}

//BOOL __cdecl Ctrl12CntCk(cCtrl12 *a1, int a2, unsigned int a3)
uint32_t __cdecl CzmHPHeadPlagasCtrl::
czm_CheckParasiteCnt( void* pCtrl12, int32_t nCntrIndex, uint32_t nMaxParasites )
{
	assert( czm_OgCheckParasiteCnt );
	//czm_Print2("CZM: nCntrIndex:%d\n", { nCntrIndex,} );
	using fn_t = decltype(czm_CheckParasiteCnt)*;
	uint32_t retv;
	retv = ((fn_t)czm_OgCheckParasiteCnt)( pCtrl12, nCntrIndex, nMaxParasites );
	// 4 - the parasite counter index.
	if( nCntrIndex == 4 ){
		bool bAllowNewParasite3 = 0L;
		{
			//GLOBAL_WK
			CzmPrsSpwChkDTO psc2;
			psc2.bAllowNewParasite2 = &bAllowNewParasite3;
			czm_EachHotPred2( [&]( const CzmEachHPatchDTO& in2 ){
				in2.hp3->notifyCheckAllowNewLiveParasite( psc2 );
			});
		}
		if( bAllowNewParasite3 ){
			retv = 0u;
		}
	}
	// retval - 0: allow infinite in-game parasite count. otherwise it's 2,
	return retv;
}
// void __thiscall cEmMgr::move(cEmMgr *this)
void __cdecl CzmHPEnemyMgrMove::czm_EnemyMgrxxmove()
{
	static CzmRe4EnmyMgr* thisp;
	__asm{
		mov thisp, ecx
	}
	assert( thisp );
	assert( czm_OgEnemyMgrxxmove );
	assert( Czm );
	__asm{
		mov ecx, thisp
		call czm_OgEnemyMgrxxmove
	}{
		if( Czm->bStatsEnabled ){
			Czm->aCurEnmList.clear();
			for( uint32_t ii2=0; ii2 < thisp->m_nArray_8.v; ii2++ ){
				// cEm* v3 = (cEm*)( (char*) this->m_Array_4 + i * this->m_blockSize_C );
				CzmRE4Enemy* enm2 = (CzmRE4Enemy*) ( (char*) thisp->m_Array_4.v + ii2 * thisp->m_blockSize_C.v );
				if( CzmEnemyTypeAdp(enm2).isLethalEnemyType() ){
					Czm->aCurEnmList.push_back(*enm2); //<CzmRE4Enemy>
				}
			}
		}//*/
	}{
		//czm_Print2("CZM: czm_EnemyMgrxxmove_() %a\n", { Czm->nCountAlive,});
		CzmEnmMgrMvDTO semm2;
		semm2.pEnMgr2 = thisp;
		czm_EachHotPred2( [&]( const CzmEachHPatchDTO& in2 ){
			in2.hp3->notifyEnemyMgrEnmsMove( semm2 );
		});
	}
}

int CzmDelLagoInstaKO::
notifyDamageAnyEnemy2( const CzmDmg2DTO& inp )
{
	if( inp.bTestRun4 )
		return inp.bTestRun4;

	if( mEnableInstaKO ){
		// [0x2F,0x00] : Del Lago (DelLago)
		if( inp.pEnmyDtaPtr5->testEnemyType2( {CZM_EEIT::CZM_E7_DelLago,0x00,} ) ){
			inp.pEnmyDtaPtr5->hp_324.v = 0;
		}
	}
	return 0;
}
void CzmDelLagoInstaKO::setDelLagoInstaKO( bool bSet )
{
	if( mEnableInstaKO != bSet ){
		if( bSet ){
			Czm->cHpMgr->addHotPatchDependency( { typeid(CzmHPDmgEnemyOrPlayer).hash_code(),}, "kieVSb" );
		}else{
			Czm->cHpMgr->removeHotPatchDependency( { typeid(CzmHPDmgEnemyOrPlayer).hash_code(),}, "kieVSb" );
		}
	}
	mEnableInstaKO = bSet;
}
int CzmCritManip::notifyDamageNormalEnemy( const CzmDmg3DTO& inp )
{
	if( inp.bTestRun4 )
		return inp.bTestRun4;

	if( inp.eCritDmgType == CZM_ECDT::CZM_E4_Critical ){
		if( mCritDmgScale != 1.f ){
			bool rs2 = std::any_of( aAlterableDmgTy.begin(), aAlterableDmgTy.end(),
					[&]( CZM_EWT e )->bool{ return e == inp.uWeaponType;});
			if( rs2 ){
				double val2 = double(*inp.pDamgeValue) * double(mCritDmgScale);
				*inp.pDamgeValue = CzmClamp<uint32_t,double>( val2, 0.f, 65535.f );
			}
		}
	}
	return 0;
}
void CzmCritManip::setAlterableDamageTypes( const std::vector<CZM_EWT>& inp )
{
	aAlterableDmgTy = inp;
}
void CzmCritManip::setCriticalDamageScale( float fCritDmgScale_ )
{
	if( (mCritDmgScale == 1.f) != (fCritDmgScale_ == 1.f) ){
		if( fCritDmgScale_ != 1.f ){
			Czm->cHpMgr->addHotPatchDependency( { typeid(CzmHPFloatToIntFeCrit).hash_code(),}, "CRZBNC" );
		}else{
			Czm->cHpMgr->removeHotPatchDependency( { typeid(CzmHPFloatToIntFeCrit).hash_code(),}, "CRZBNC" );
		}
	}
	mCritDmgScale = fCritDmgScale_;
}
uint32_t czm_GpHaxInit()
{
	assert( !Gpd );
	Gpd = new CzmGpData;
	{
		// HFD_RNESL_ROOM_LOAD_FUNCTION_OFFSET=0x1B14C0
		void* pAtOpCode = hxdw_GetPtrGivenInSectionOffset( 0, nullptr, ".text", 0x1B14C0 );
		assert( pAtOpCode );
		if( MH_CreateHook( pAtOpCode, czm_OnRoomLoad, (void**)(&czm_OgOnRoomLoad)) ) { return 105; }
		if( MH_EnableHook( pAtOpCode) ) { return 106;}
	}{
		void* pAtOpCode = hxdw_GetPtrGivenInSectionOffset( 0, nullptr, ".text", 0x251D30 );
		assert( pAtOpCode );
		if( MH_CreateHook( pAtOpCode, czm_OnReturnToMainMenu, (void**)(&czm_OgOnReturnToMainMenu)) ) { return 105; }
		if( MH_EnableHook( pAtOpCode) ) { return 106;}
	}{
	}{
	/*	// fmv2_cutscene_a_skip_cond -> ".text"+0x188F70
		// Ret addr for ESP-EIP scan: ".text"+0x22745A
		void* pAtOpCode = hxdw_GetPtrGivenInSectionOffset( 0, nullptr, ".text", 0x188F70 );
		assert( pAtOpCode );
		if( MH_CreateHook( pAtOpCode, czm_KeyTrgCheckZeroESPAware, (void**)(&czm_OgKeyTrgCheckZero)) ) { return 2; }
		if( MH_EnableHook( pAtOpCode) ) { return 3;}
		//
		void* p = hxdw_GetPtrGivenInSectionOffset( 0, nullptr, ".text", 0x22745A );
		Gpd->pAtCutscASkipEipAddr = (uint8_t*) p;
		assert( Gpd->pAtCutscASkipEipAddr );

		// fmv2_cutscene_c_skip_cond
		p = hxdw_GetPtrGivenInSectionOffset( 0, nullptr, ".text", 0x368D0C );
		Gpd->pAtCutscCSkipEipAddr = (uint8_t*) p;
		assert( Gpd->pAtCutscCSkipEipAddr );
		//*/
	}{
	/*	// fmv2_cutscene_b_skip_cond -> ".text"+0x2C40A0
		void* pAtOpCode = hxdw_GetPtrGivenInSectionOffset( 0, nullptr, ".text", 0x2C40A0 );
		assert( pAtOpCode );
		if( MH_CreateHook( pAtOpCode, czm_ScenarioChkEvCancel, (void**)(&czm_OgScenarioChkEvCancel)) ) { return 2; }
		if( MH_EnableHook( pAtOpCode) ) { return 3;}

		void* p = hxdw_GetPtrGivenInSectionOffset( 0, nullptr, ".data", 0x74C0C );
		Gpd->pAtCutscBAlphaTrgrPtr = (uint8_t*) p;
		assert( Gpd->pAtCutscBAlphaTrgrPtr );

		p = hxdw_GetPtrGivenInSectionOffset( 0, nullptr, ".data", 0x6FF10 );
		Gpd->pAtCutscBBetaTrgrPtr = (uint32_t*) p;
		assert( Gpd->pAtCutscBBetaTrgrPtr );//*/
	}{
	/*	// fmv2_cutscene_d_skip_cond
		void* pAtOpCode = hxdw_GetPtrGivenInSectionOffset( 0, nullptr, ".text", 0x226900 );
		assert( pAtOpCode );
		if( MH_CreateHook( pAtOpCode, czm_EventxxRun, (void**)(&czm_OgEventxxRun)) ) { return 2; }
		if( MH_EnableHook( pAtOpCode) ) { return 3;}//*/
	}{
		// ".text"+0x1B1010
		void* pAtOpCode = hxdw_GetPtrGivenInSectionOffset( 0, nullptr, ".text", 0x1B1010 );
		assert( pAtOpCode );
		if( MH_CreateHook( pAtOpCode, czm_EnemyDeath, (void**)(&czm_OgEnemyDeath)) ) {return 2;}
		if( MH_EnableHook( pAtOpCode) ) {return 3;}
	}{
	/*	// cEmMgr::move     -> .text+0x1AF1B0
		void* pAtOpCode = hxdw_GetPtrGivenInSectionOffset( 0, nullptr, ".text", 0x1AF1B0 );
		assert( pAtOpCode );
		if( MH_CreateHook( pAtOpCode, CzmHPEnemyMgrMove::czm_EnemyMgrxxmove, (void**)(&czm_OgEnemyMgrxxmove)) ) {return 2;}
		if( MH_EnableHook( pAtOpCode) ) {return 3;}//*/
	}{
		size_t ii3 = 0;
		Gpd->aHotPreds2 = new CzmHotPatchDTO[32];
		Gpd->aHotPreds2[ii3++] = CzmHotPatchDTO{ new CzmDelLagoInstaKO,};
		Gpd->aHotPreds2[ii3++] = CzmHotPatchDTO{ new CzmCritManip,};
		Gpd->aHotPreds2[ii3++] = CzmHotPatchDTO{ new CzmCutscSkip,};
		Gpd->aHotPreds2[ii3++] = CzmHotPatchDTO{ new CzmHeadParasiteDiceManip,};
		Gpd->aHotPreds2[ii3++] = CzmHotPatchDTO{ new CzmHeadParasiteLiveLimitRemove,};
		Gpd->aHotPreds2[ii3++] = CzmHotPatchDTO{ new CzmDisableTypeCParasite,};
		Gpd->aHotPreds2[ii3++] = CzmHotPatchDTO{ new CzmStatsListLiveEnmy,};
		Gpd->aHotPreds2[ii3++] = CzmHotPatchDTO{ nullptr,};
		//czm_EachHotPred2() //CzmHotPredicateBase
	}{
		//assert( Czm );
		//assert( Czm->cHpMgr );
		//Czm->cHpMgr->addHotPatchDependency( { typeid(CzmHPDmgEnemyOrPlayer).hash_code(),} );
		//Czm->cHpMgr->addHotPatchDependency( { typeid(CzmHPCutsceneSkips).hash_code(),} );
		//Czm->cHpMgr->addHotPatchDependency( { typeid(CzmHPFloatToIntFeCrit).hash_code(),} );
		//Czm->cHpMgr->addHotPatchDependency( { typeid(CzmHPHeadPlagasCtrl).hash_code(),}, "VlaPFN" );
	}
	Gpd->bMdxInitedOneTime = 1;
	return 0;  //0==ok
}

/// Returns 0 on success.
/// See czm_GpHaxInit().
uint32_t czm_GpHaxDeinit()
{
	assert( Gpd );
	if( !Gpd->bMdxInitedOneTime ){
		return 591502354;
	}
	if( Gpd->bMdxDeinited ){
		return 952045340;
	}
	Gpd->bMdxDeinited = 1;

	delete Gpd;
	Gpd = nullptr;
	return 0;
}
void czm_EachHotPred2( std::function<void(const CzmEachHPatchDTO&)> calb2 )
{
	assert( Gpd );
	if( Gpd->aHotPreds2 ){
		CzmHotPredicateBase* ptr;
		for( size_t ii2=0; (ptr = Gpd->aHotPreds2[ii2].pHotPatch); ii2++ ){
			//if( ptr->pokeIsEnabled() ){
				calb2( CzmEachHPatchDTO{ ptr,} );
			//}
		}
	}
}
void CzmCutscSkip::setCutsceneSkipEnabled( bool bSet )
{
	mSkipEnable = bSet;

	if( mDtSkipEnable || mSkipEnable ){
		Czm->cHpMgr->addHotPatchDependency( { typeid(CzmHPCutsceneSkips).hash_code(),}, "EaRqnO" );
	}else{
		Czm->cHpMgr->removeHotPatchDependency( { typeid(CzmHPCutsceneSkips).hash_code(),}, "EaRqnO" );
	}
}
void CzmCutscSkip::setCutsceneDeltaSkipable( bool bSet )
{
	mDtSkipEnable = bSet;

	if( mDtSkipEnable || mSkipEnable ){
		Czm->cHpMgr->addHotPatchDependency( { typeid(CzmHPCutsceneSkips).hash_code(),}, "EaRqnO" );
	}else{
		Czm->cHpMgr->removeHotPatchDependency( { typeid(CzmHPCutsceneSkips).hash_code(),}, "EaRqnO" );
	}
}
int CzmCutscSkip::notifyCutscenePlay( const CzmCutscSkipDTO& inp )
{
	if( inp.bTestRun4 )
		return inp.bTestRun4;
	assert( inp.bSkipCutscene );
//	if( inp.eCtsType == CZM_CST::CZM_E6_TypeDelta ){
//		if( mDtSkipEnable )
//			*inp.bSkipCutscene = 1L;
//		return 0;
//	}
	if( mSkipEnable )
		*inp.bSkipCutscene = 1L;
	return 0;
}
int CzmCutscSkip::notifyUnskippableCutscenePlay( const CzmCutscSkipDTO& inp )
{
	if( inp.bTestRun4 )
		return inp.bTestRun4;
	if( inp.eCtsType == CZM_CST::CZM_E6_TypeDelta && mDtSkipEnable ){
		*inp.bSkipCutscene = 1L;
	}
	return 0;
}

int CzmHPDmgEnemyOrPlayer::install2()
{
	czm_Print2("CzmHPDmgEnemyOrPlayer::install2()\n", {});

	assert( !mIsInstalled );
	// dmg2_on_damage_enemy_or_leon_fqYhLH
	pAtOpCode2 = hxdw_GetPtrGivenInSectionOffset( 0, nullptr, ".text", 0x1B4AF0 );
	assert( pAtOpCode2 );
	if( MH_CreateHook( pAtOpCode2, this->czm_DamageEnemyOrPlayer, (void**)(&czm_OgDamageEnemyOrPlayer)) ) {return 2;}
	if( MH_EnableHook( pAtOpCode2) ) {return 3;}
	mIsInstalled = 1L;
	return 0;  // retval 0: success
}
int CzmHPDmgEnemyOrPlayer::uninstall2()
{
	czm_Print2("CzmHPDmgEnemyOrPlayer::uninstall2()\n", {});
	assert( pAtOpCode2 );
	MH_DisableHook( pAtOpCode2 );
	MH_RemoveHook( pAtOpCode2 );

	pAtOpCode2 = nullptr;
	mIsInstalled = 0L;
	return 0;  // retval 0: success
}

int CzmHPFloatToIntFeCrit::install2()
{
	czm_Print2("CzmHPFloatToIntFeCrit::install2()\n", {});

	// crit. calc. call point: ".text"+0x49F8E
	// crit. calc. ret addr:   ".text"+0x49F8E+5
	void* p = hxdw_GetPtrGivenInSectionOffset( 0, nullptr, ".text", 0x49F8E+5 );
	this->pAtCritFloatToIntRetAddr = (uint8_t*) p;
	assert( this->pAtCritFloatToIntRetAddr );

	// dmg2_float_to_int_fe_on_crit_qaXKLvy : .text+0x66DCF0
	assert( !pAtOpCode4 );
	pAtOpCode4 = hxdw_GetPtrGivenInSectionOffset( 0, nullptr, ".text", 0x66DCF0 );
	assert( pAtOpCode4 );
	if( MH_CreateHook( pAtOpCode4, this->czm_OnFloatToIntFeCritESPAware, (void**)(&czm_OgOnFloatToIntFeCrit)) ) {return 628144137;}
	if( MH_EnableHook( pAtOpCode4) ) {return 53047405;}

	return 0;
}
int CzmHPFloatToIntFeCrit::uninstall2()
{
	czm_Print2("CzmHPFloatToIntFeCrit::uninstall2()\n", {});
	assert( pAtOpCode4 );
	MH_DisableHook( pAtOpCode4 );
	MH_RemoveHook( pAtOpCode4 );
	this->pAtOpCode4 = nullptr;
	this->pAtCritFloatToIntRetAddr = nullptr;
	return 0;
}

CzmHotPatch2Base* czm_CreateHotPatchByType( CZM_EHPT eHpTy )
{
	if(0){
	}else if( eHpTy == typeid(CzmHPDmgEnemyOrPlayer).hash_code() ){
		return new CzmHPDmgEnemyOrPlayer;
	}else if( eHpTy == typeid(CzmHPFloatToIntFeCrit).hash_code() ){
		return new CzmHPFloatToIntFeCrit;
	}else if( eHpTy == typeid(CzmHPCutsceneSkips).hash_code() ){
		return new CzmHPCutsceneSkips;
	}else if( eHpTy == typeid(CzmHPHeadPlagasCtrl).hash_code() ){
		return new CzmHPHeadPlagasCtrl;
	}else if( eHpTy == typeid(CzmHPEnemyMgrMove).hash_code() ){
		return new CzmHPEnemyMgrMove;
	}
	assert( 0 && "No type match. Could not create any hot-patch object.");
	return nullptr;
}
void czm_DeleteHotPatch( CzmHotPatch2Base* ptr )
{
	delete ptr;
}

int CzmHPCutsceneSkips::install2()
{
	czm_Print2("CzmHPCutsceneSkips::install2()\n", {});
	{
		// fmv2_cutscene_a_skip_cond -> ".text"+0x188F70
		// Ret addr for ESP-EIP scan: ".text"+0x22745A
		void* pAtOpCode = hxdw_GetPtrGivenInSectionOffset( 0, nullptr, ".text", 0x188F70 );
		assert( pAtOpCode );
		if( MH_CreateHook( pAtOpCode, czm_KeyTrgCheckZeroESPAware, (void**)(&czm_OgKeyTrgCheckZero)) ) { return 2; }
		if( MH_EnableHook( pAtOpCode) ) { return 3;}
		aOpAddrs.push_back( pAtOpCode );
		//
		void* p = hxdw_GetPtrGivenInSectionOffset( 0, nullptr, ".text", 0x22745A );
		pAtCutscASkipEipAddr = (uint8_t*) p;
		assert( pAtCutscASkipEipAddr );

		// fmv2_cutscene_c_skip_cond
		p = hxdw_GetPtrGivenInSectionOffset( 0, nullptr, ".text", 0x368D0C );
		pAtCutscCSkipEipAddr = (uint8_t*) p;
		assert( pAtCutscCSkipEipAddr );
	}{
		// fmv2_cutscene_b_skip_cond -> ".text"+0x2C40A0
		void* pAtOpCode = hxdw_GetPtrGivenInSectionOffset( 0, nullptr, ".text", 0x2C40A0 );
		assert( pAtOpCode );
		if( MH_CreateHook( pAtOpCode, czm_ScenarioChkEvCancel, (void**)(&czm_OgScenarioChkEvCancel)) ) { return 2; }
		if( MH_EnableHook( pAtOpCode) ) { return 3;}
		aOpAddrs.push_back( pAtOpCode );

		void* p = hxdw_GetPtrGivenInSectionOffset( 0, nullptr, ".data", 0x74C0C );
		pAtCutscBAlphaTrgrPtr = (uint8_t*) p;
		assert( pAtCutscBAlphaTrgrPtr );

		p = hxdw_GetPtrGivenInSectionOffset( 0, nullptr, ".data", 0x6FF10 );
		pAtCutscBBetaTrgrPtr = (uint32_t*) p;
		assert( pAtCutscBBetaTrgrPtr );
	}{
		// fmv2_cutscene_d_skip_cond
		void* pAtOpCode = hxdw_GetPtrGivenInSectionOffset( 0, nullptr, ".text", 0x226900 );
		assert( pAtOpCode );
		if( MH_CreateHook( pAtOpCode, czm_EventxxRun, (void**)(&czm_OgEventxxRun)) ) { return 2; }
		if( MH_EnableHook( pAtOpCode) ) { return 3;}
		aOpAddrs.push_back( pAtOpCode );
	}
	return 0;
}
int CzmHPCutsceneSkips::uninstall2()
{
	czm_Print2("CzmHPCutsceneSkips::uninstall2()\n", {});
	for( auto ir2 = aOpAddrs.begin(); ir2 != aOpAddrs.end(); ++ir2 ){
		MH_DisableHook( *ir2 );
		MH_RemoveHook( *ir2 );
	}
	aOpAddrs.clear();
	return 0;
}

int CzmHPHeadPlagasCtrl::install2()
{
	czm_Print2("CzmHPHeadPlagasCtrl::install2()\n", {});
	{
		// prs2_spw_parasite_call
		void* pAtOpCode = hxdw_GetPtrGivenInSectionOffset( 0, nullptr, ".text", 0x56C80 );
		assert( pAtOpCode );
		if( MH_CreateHook( pAtOpCode, this->czm_SpwParasiteChgChk, (void**)(&czm_OgSpwParasiteChgChk)) ) {return 2;}
		if( MH_EnableHook( pAtOpCode) ) {return 3;}
		aOpAddrs2.push_back( pAtOpCode );
	}{
		// prs2_check_allow_new_parasite
		void* pAtOpCode = hxdw_GetPtrGivenInSectionOffset( 0, nullptr, ".text", 0x2F6CC0 );
		assert( pAtOpCode );
		if( MH_CreateHook( pAtOpCode, this->czm_CheckParasiteCnt, (void**)(&czm_OgCheckParasiteCnt)) ) {return 2;}
		if( MH_EnableHook( pAtOpCode) ) {return 3;}
		aOpAddrs2.push_back( pAtOpCode );
	}
	return 0;
}
int CzmHPHeadPlagasCtrl::uninstall2()
{
	czm_Print2("CzmHPHeadPlagasCtrl::uninstall2()\n", {});
	for( auto ir2 = aOpAddrs2.begin(); ir2 != aOpAddrs2.end(); ++ir2 ){
		MH_DisableHook( *ir2 );
		MH_RemoveHook( *ir2 );
	}
	aOpAddrs2.clear();
	return 0;
}
int CzmHPEnemyMgrMove::install2()
{
	czm_Print2("CzmHPEnemyMgrMove::install2()\n", {});
	// cEmMgr::move     -> .text+0x1AF1B0
	void* pAtOpCode = hxdw_GetPtrGivenInSectionOffset( 0, nullptr, ".text", 0x1AF1B0 );
	assert( pAtOpCode );
	if( MH_CreateHook( pAtOpCode, this->czm_EnemyMgrxxmove, (void**)(&czm_OgEnemyMgrxxmove)) ) {return 2;}
	if( MH_EnableHook( pAtOpCode) ) {return 3;}
	aOpAddrs3.push_back( pAtOpCode );
	return 0;
}
int CzmHPEnemyMgrMove::uninstall2()
{
	czm_Print2("CzmHPEnemyMgrMove::uninstall2()\n", {});
	for( auto ir2 = aOpAddrs3.begin(); ir2 != aOpAddrs3.end(); ++ir2 ){
		MH_DisableHook( *ir2 );
		MH_RemoveHook( *ir2 );
	}
	aOpAddrs3.clear();
	return 0;
}
void CzmHeadParasiteDiceManip::setParasiteSpawnManipEnabled( bool bEnable )
{
	mEnabled = bEnable;
	if( mEnabled ){
		Czm->cHpMgr->addHotPatchDependency( { typeid(CzmHPHeadPlagasCtrl).hash_code(),}, "EaRqnO" );
	}else{
		Czm->cHpMgr->removeHotPatchDependency( { typeid(CzmHPHeadPlagasCtrl).hash_code(),}, "EaRqnO" );
	}
}
/// Sets parasite spawn chance. Value in range from 0.0f to 1.0f.
/// 1.0f being 100% chance for parasite to spawn.
void CzmHeadParasiteDiceManip::setParasiteSpawnChance( float fChancePerc )
{
	mPrsChance = fChancePerc;
	mPrsChance = CzmClamp<float,float>( mPrsChance, 0.f, 1.f );
}

void CzmHeadParasiteDiceManip::
setNoParasiteInIntialChapters( bool bSet )
{
	mNotInInitialChp = bSet;
}

int CzmHeadParasiteDiceManip::
notifyDiceForParasiteSpawn( const CzmPrsDiceDTO& inp )
{
	assert( inp.bPrsOverride2 );
	assert( inp.bPrsSpawnNow2 );
	if( mEnabled ){
		if( mNotInInitialChp ){
			assert( Czm->ppGD );
			assert( *Czm->ppGD );
			const uint8_t nGameChapter = (**Czm->ppGD).chapter_4F9A.v;
			if( nGameChapter <= 2 ){
				return 0L;
			}
		}
		*inp.bPrsOverride2 = 1L;
		// *inp.bPrsSpawnNow2 = 1L;//TMP.
		if( mPrsChance == 1.f ){
			*inp.bPrsSpawnNow2 = 1L;
		}else if( mPrsChance == 0.f ){
			*inp.bPrsSpawnNow2 = 0L;
		}else{
			int dice2 = int( hxdw_GetTimeTicksMs() % 1001 );
			double dice3 = double(dice2) / 1000.0;
			*inp.bPrsSpawnNow2 = ( dice3 < mPrsChance );
			//czm_Print2("CZM: mPrsChance: %a, die3: %a\n", {
			//		std::to_string(mPrsChance),
			//		std::to_string(dice3),});
		}
	}
	return 0;
}
void CzmHeadParasiteLiveLimitRemove::
setParasiteSpawnNoLimit( bool bEnable )
{
	mEnabled = bEnable;
	//czm_Print2("CZM: xxx::setParasiteSpawnNoLimit(%a)\n", {
	//		(int)bEnable,});
	if(mEnabled){
		Czm->cHpMgr->addHotPatchDependency( { typeid(CzmHPHeadPlagasCtrl).hash_code(),}, "wHztGp" );
	}else{
		Czm->cHpMgr->removeHotPatchDependency( { typeid(CzmHPHeadPlagasCtrl).hash_code(),}, "wHztGp" );
	}
}
int CzmHeadParasiteLiveLimitRemove::
notifyCheckAllowNewLiveParasite( const CzmPrsSpwChkDTO& inp )
{
	if( mEnabled ){
		assert( inp.bAllowNewParasite2 );
		*inp.bAllowNewParasite2 = 1L;
	}
	return 0;
}

int CzmDisableTypeCParasite::
notifyEnemyMgrEnmsMove( const CzmEnmMgrMvDTO& inp )
{
	if( mEnabled ){
		CzmRE4Enemy* enm3;
		for( size_t idx=0; (enm3 = inp.getNextEnemy2(idx)); idx++ ){
			if( enm3->id_100.v == CZM_EEIT::CZM_E7_Plagas_C_r20F ){
				enm3->be_flag_4.v |= 0x601;
				enm3->be_flag_4.v |= 0x400; //|0x200
			}
		}
	}
	return 0;
}
void CzmDisableTypeCParasite::
setDisableTypeCParasite( bool bDisable )
{
	mEnabled = bDisable;
	if( mEnabled ){
		Czm->cHpMgr->addHotPatchDependency( { typeid(CzmHPEnemyMgrMove).hash_code(),}, "tLyySbv");
	}else{
		Czm->cHpMgr->removeHotPatchDependency( { typeid(CzmHPEnemyMgrMove).hash_code(),}, "tLyySbv");
	}
}
void CzmStatsListLiveEnmy::setEnemyStatsEnabled( bool bSet )
{
	mEnabled = bSet;
	if(mEnabled){
		Czm->cHpMgr->addHotPatchDependency( { typeid(CzmHPEnemyMgrMove).hash_code(),}, "EVnyNL6");
	}else{
		Czm->cHpMgr->removeHotPatchDependency( { typeid(CzmHPEnemyMgrMove).hash_code(),}, "EVnyNL6");
	}
}
int CzmStatsListLiveEnmy::
notifyEnemyMgrEnmsMove( const CzmEnmMgrMvDTO& inp )
{
	//Czm->aCurEnmList.clear();
	if( mEnabled ){
		CzmRE4Enemy* enm4;
		for( size_t idx=0; (enm4 = inp.getNextEnemy2(idx)); idx++ ){
			//if( enm4->id_100.v == CZM_EEIT::CZM_E7_Plagas_C_r20F ){
			//}
		}
	}
	return 0;
}
