#include "czm_d3d9detour.h"
#include <memory>   //std::shared_ptr
#include <stdio.h>
#include "imgui_impl_dx9.h"
#include "MinHook.h"
#include "hxdw_utils.h"

ULONG _InterlockedDecrement2( LONG* pRefcount )
{
	assert( pRefcount && "FWBzMoEzt9" );
	assert( *pRefcount > 0 && "IjqtmJzsn" );
	return (*pRefcount -= 1);
}

HRESULT CzmDirect3D9Detour::QueryInterface(REFIID riid, void** ppvObj)
{
	if (ppvObj == nullptr) return E_POINTER;

	if (riid == __uuidof(IUnknown) ||
		riid == __uuidof(IDirect3D9))
	{
		*ppvObj = static_cast<IDirect3D9*>(this);
		AddRef();
		return S_OK;
	}

	*ppvObj = nullptr;
	return E_NOINTERFACE;
}

ULONG CzmDirect3D9Detour::AddRef(void)
{
	return ++mRefCount2;
}

ULONG CzmDirect3D9Detour::Release(void)
{
	//const LONG ref = _InterlockedDecrement2(&m_refCount);
	const LONG ref = --mRefCount2;
	if (ref == 0)
	{
		delete this;
	}
	return ref;
}

HRESULT CzmDirect3D9Detour::RegisterSoftwareDevice(void* pInitializeFunction)
{
	return m_direct3D9->RegisterSoftwareDevice(pInitializeFunction);
}

UINT CzmDirect3D9Detour::GetAdapterCount(void)
{
	return m_direct3D9->GetAdapterCount();
}

HRESULT CzmDirect3D9Detour::GetAdapterIdentifier(UINT Adapter, DWORD Flags, D3DADAPTER_IDENTIFIER9* pIdentifier)
{
	return m_direct3D9->GetAdapterIdentifier(Adapter, Flags, pIdentifier);
}

UINT CzmDirect3D9Detour::GetAdapterModeCount(UINT Adapter, D3DFORMAT Format)
{
	return m_direct3D9->GetAdapterModeCount(Adapter, Format);
}

HRESULT CzmDirect3D9Detour::EnumAdapterModes(UINT Adapter, D3DFORMAT Format, UINT Mode, D3DDISPLAYMODE* pMode)
{
	//hxdw_StdPrint2("CZM: CzmDirect3D9Detour::EnumAdapterModes()\n");

	return m_direct3D9->EnumAdapterModes(Adapter, Format, Mode, pMode);
}

HRESULT CzmDirect3D9Detour::GetAdapterDisplayMode(UINT Adapter, D3DDISPLAYMODE* pMode)
{
	return m_direct3D9->GetAdapterDisplayMode(Adapter, pMode);
}

HRESULT CzmDirect3D9Detour::CheckDeviceType(UINT Adapter, D3DDEVTYPE DevType, D3DFORMAT AdapterFormat, D3DFORMAT BackBufferFormat, BOOL bWindowed)
{
	return m_direct3D9->CheckDeviceType(Adapter, DevType, AdapterFormat, BackBufferFormat, bWindowed);
}

HRESULT CzmDirect3D9Detour::CheckDeviceFormat(UINT Adapter, D3DDEVTYPE DeviceType, D3DFORMAT AdapterFormat, DWORD Usage, D3DRESOURCETYPE RType, D3DFORMAT CheckFormat)
{
	return m_direct3D9->CheckDeviceFormat(Adapter, DeviceType, AdapterFormat, Usage, RType, CheckFormat);
}

HRESULT CzmDirect3D9Detour::CheckDeviceMultiSampleType(UINT Adapter, D3DDEVTYPE DeviceType, D3DFORMAT SurfaceFormat, BOOL Windowed, D3DMULTISAMPLE_TYPE MultiSampleType, DWORD* pQualityLevels)
{
	return m_direct3D9->CheckDeviceMultiSampleType(Adapter, DeviceType, SurfaceFormat, Windowed, MultiSampleType, pQualityLevels);
}

HRESULT CzmDirect3D9Detour::CheckDepthStencilMatch(UINT Adapter, D3DDEVTYPE DeviceType, D3DFORMAT AdapterFormat, D3DFORMAT RenderTargetFormat, D3DFORMAT DepthStencilFormat)
{
	return m_direct3D9->CheckDepthStencilMatch(Adapter, DeviceType, AdapterFormat, RenderTargetFormat, DepthStencilFormat);
}

HRESULT CzmDirect3D9Detour::CheckDeviceFormatConversion(UINT Adapter, D3DDEVTYPE DeviceType, D3DFORMAT SourceFormat, D3DFORMAT TargetFormat)
{
	return m_direct3D9->CheckDeviceFormatConversion(Adapter, DeviceType, SourceFormat, TargetFormat);
}

HRESULT CzmDirect3D9Detour::GetDeviceCaps(UINT Adapter, D3DDEVTYPE DeviceType, D3DCAPS9* pCaps)
{
	return m_direct3D9->GetDeviceCaps(Adapter, DeviceType, pCaps);
}

HMONITOR CzmDirect3D9Detour::GetAdapterMonitor(UINT Adapter)
{
	return m_direct3D9->GetAdapterMonitor(Adapter);
}

HRESULT CzmDirect3DDevice9Detour::QueryInterface(REFIID riid, void** ppvObj)
{
	if (ppvObj == nullptr) return E_POINTER;

	if (riid == __uuidof(IUnknown) ||
		riid == __uuidof(IDirect3DDevice9))
	{
		//_ *ppvObj = static_cast<IDirect3DDevice9*>(this);
		*ppvObj = this;
		AddRef();
		return S_OK;
	}

	*ppvObj = nullptr;
	return E_NOINTERFACE;
}

ULONG CzmDirect3DDevice9Detour::AddRef(void)
{
	return ++mRefCount3;
}

ULONG CzmDirect3DDevice9Detour::Release(void)
{
	//const LONG ref = _InterlockedDecrement2(&m_refCount3);
	const LONG ref = --mRefCount3;
	if( ref == 0 ){
		delete this;
	}
	return ref;
}

HRESULT CzmDirect3DDevice9Detour::TestCooperativeLevel(void)
{
	return m_direct3DDevice9->TestCooperativeLevel();
}

UINT CzmDirect3DDevice9Detour::GetAvailableTextureMem(void)
{
	return m_direct3DDevice9->GetAvailableTextureMem();
}

HRESULT CzmDirect3DDevice9Detour::EvictManagedResources(void)
{
	return m_direct3DDevice9->EvictManagedResources();;
}

HRESULT CzmDirect3DDevice9Detour::GetDirect3D(IDirect3D9** ppD3D9)
{
	return m_direct3DDevice9->GetDirect3D(ppD3D9);
}

HRESULT CzmDirect3DDevice9Detour::GetDeviceCaps(D3DCAPS9* pCaps)
{
	return m_direct3DDevice9->GetDeviceCaps(pCaps);
}

HRESULT CzmDirect3DDevice9Detour::GetDisplayMode(UINT iSwapChain, D3DDISPLAYMODE* pMode)
{
	return m_direct3DDevice9->GetDisplayMode(iSwapChain, pMode);
}

HRESULT CzmDirect3DDevice9Detour::GetCreationParameters(D3DDEVICE_CREATION_PARAMETERS* pParameters)
{
	return m_direct3DDevice9->GetCreationParameters(pParameters);
}

HRESULT CzmDirect3DDevice9Detour::SetCursorProperties(UINT XHotSpot, UINT YHotSpot, IDirect3DSurface9* pCursorBitmap)
{
	return m_direct3DDevice9->SetCursorProperties(XHotSpot, YHotSpot, pCursorBitmap);
}

void CzmDirect3DDevice9Detour::SetCursorPosition(int X, int Y, DWORD Flags)
{
	m_direct3DDevice9->SetCursorPosition(X, Y, Flags);
}

BOOL CzmDirect3DDevice9Detour::ShowCursor(BOOL bShow)
{
	return m_direct3DDevice9->ShowCursor(bShow);
}

HRESULT CzmDirect3DDevice9Detour::CreateAdditionalSwapChain(D3DPRESENT_PARAMETERS* pPresentationParameters, IDirect3DSwapChain9** pSwapChain)
{
	return m_direct3DDevice9->CreateAdditionalSwapChain(pPresentationParameters, pSwapChain);
}

HRESULT CzmDirect3DDevice9Detour::GetSwapChain(UINT iSwapChain, IDirect3DSwapChain9** pSwapChain)
{
	return m_direct3DDevice9->GetSwapChain(iSwapChain, pSwapChain);
}

UINT CzmDirect3DDevice9Detour::GetNumberOfSwapChains(void)
{
	return m_direct3DDevice9->GetNumberOfSwapChains();
}

HRESULT CzmDirect3DDevice9Detour::Reset(D3DPRESENT_PARAMETERS* pPresentationParameters)
{
	// Force v-sync off
	//if (pConfig->bDisableVsync)
	//	pPresentationParameters->PresentationInterval = D3DPRESENT_INTERVAL_IMMEDIATE;

	ImGui_ImplDX9_InvalidateDeviceObjects(); // Reset ImGui objects to prevent freezing

	HRESULT hr = m_direct3DDevice9->Reset(pPresentationParameters);

	ImGui_ImplDX9_CreateDeviceObjects();

	return hr;
}

HRESULT CzmDirect3DDevice9Detour::Present(const RECT* pSourceRect, const RECT* pDestRect, HWND hDestWindowOverride, const RGNDATA* pDirtyRegion)
{
	return m_direct3DDevice9->Present(pSourceRect, pDestRect, hDestWindowOverride, pDirtyRegion);
}

HRESULT CzmDirect3DDevice9Detour::GetBackBuffer(UINT iSwapChain, UINT iBackBuffer, D3DBACKBUFFER_TYPE Type, IDirect3DSurface9** ppBackBuffer)
{
	return m_direct3DDevice9->GetBackBuffer(iSwapChain, iBackBuffer, Type, ppBackBuffer);
}

HRESULT CzmDirect3DDevice9Detour::GetRasterStatus(UINT iSwapChain, D3DRASTER_STATUS* pRasterStatus)
{
	return m_direct3DDevice9->GetRasterStatus(iSwapChain, pRasterStatus);
}

HRESULT CzmDirect3DDevice9Detour::SetDialogBoxMode(BOOL bEnableDialogs)
{
	return m_direct3DDevice9->SetDialogBoxMode(bEnableDialogs);
}

void CzmDirect3DDevice9Detour::SetGammaRamp(UINT iSwapChain, DWORD Flags, const D3DGAMMARAMP* pRamp)
{
	m_direct3DDevice9->SetGammaRamp(iSwapChain, Flags, pRamp);
}

void CzmDirect3DDevice9Detour::GetGammaRamp(UINT iSwapChain, D3DGAMMARAMP* pRamp)
{
	m_direct3DDevice9->GetGammaRamp(iSwapChain, pRamp);
}

HRESULT CzmDirect3DDevice9Detour::CreateTexture(UINT Width, UINT Height, UINT Levels, DWORD Usage, D3DFORMAT Format, D3DPOOL Pool, IDirect3DTexture9** ppTexture, HANDLE* pSharedHandle)
{
	return m_direct3DDevice9->CreateTexture(Width, Height, Levels, Usage, Format, Pool, ppTexture, pSharedHandle);
}

HRESULT CzmDirect3DDevice9Detour::CreateVolumeTexture(UINT Width, UINT Height, UINT Depth, UINT Levels, DWORD Usage, D3DFORMAT Format, D3DPOOL Pool, IDirect3DVolumeTexture9** ppVolumeTexture, HANDLE* pSharedHandle)
{
	return m_direct3DDevice9->CreateVolumeTexture(Width, Height, Depth, Levels, Usage, Format, Pool, ppVolumeTexture, pSharedHandle);
}

HRESULT CzmDirect3DDevice9Detour::CreateCubeTexture(UINT EdgeLength, UINT Levels, DWORD Usage, D3DFORMAT Format, D3DPOOL Pool, IDirect3DCubeTexture9** ppCubeTexture, HANDLE* pSharedHandle)
{
	return m_direct3DDevice9->CreateCubeTexture(EdgeLength, Levels, Usage, Format, Pool, ppCubeTexture, pSharedHandle);
}

HRESULT CzmDirect3DDevice9Detour::CreateDepthStencilSurface(UINT Width, UINT Height, D3DFORMAT Format, D3DMULTISAMPLE_TYPE MultiSample, DWORD MultisampleQuality, BOOL Discard, IDirect3DSurface9** ppSurface, HANDLE* pSharedHandle)
{
	return m_direct3DDevice9->CreateDepthStencilSurface(Width, Height, Format, MultiSample, MultisampleQuality, Discard, ppSurface, pSharedHandle);
}

HRESULT CzmDirect3DDevice9Detour::CreateIndexBuffer(UINT Length, DWORD Usage, D3DFORMAT Format, D3DPOOL Pool, IDirect3DIndexBuffer9** ppIndexBuffer, HANDLE* pSharedHandle)
{
	return m_direct3DDevice9->CreateIndexBuffer(Length, Usage, Format, Pool, ppIndexBuffer, pSharedHandle);
}

HRESULT CzmDirect3DDevice9Detour::CreateRenderTarget(UINT Width, UINT Height, D3DFORMAT Format, D3DMULTISAMPLE_TYPE MultiSample, DWORD MultisampleQuality, BOOL Lockable, IDirect3DSurface9** ppSurface, HANDLE* pSharedHandle)
{
	return m_direct3DDevice9->CreateRenderTarget(Width, Height, Format, MultiSample, MultisampleQuality, Lockable, ppSurface, pSharedHandle);
}

HRESULT CzmDirect3DDevice9Detour::CreateVertexBuffer(UINT Length, DWORD Usage, DWORD FVF, D3DPOOL Pool, IDirect3DVertexBuffer9** ppVertexBuffer, HANDLE* pSharedHandle)
{
	return m_direct3DDevice9->CreateVertexBuffer(Length, Usage, FVF, Pool, ppVertexBuffer, pSharedHandle);
}

HRESULT CzmDirect3DDevice9Detour::BeginStateBlock()
{
	return m_direct3DDevice9->BeginStateBlock();
}

HRESULT CzmDirect3DDevice9Detour::CreateStateBlock(D3DSTATEBLOCKTYPE Type, IDirect3DStateBlock9** ppSB)
{
	return m_direct3DDevice9->CreateStateBlock(Type, ppSB);
}

HRESULT CzmDirect3DDevice9Detour::EndStateBlock(IDirect3DStateBlock9** ppSB)
{
	return m_direct3DDevice9->EndStateBlock(ppSB);
}

HRESULT CzmDirect3DDevice9Detour::GetClipStatus(D3DCLIPSTATUS9* pClipStatus)
{
	return m_direct3DDevice9->GetClipStatus(pClipStatus);
}

HRESULT CzmDirect3DDevice9Detour::GetRenderState(D3DRENDERSTATETYPE State, DWORD* pValue)
{
	return m_direct3DDevice9->GetRenderState(State, pValue);
}

HRESULT CzmDirect3DDevice9Detour::GetRenderTarget(DWORD RenderTargetIndex, IDirect3DSurface9** ppRenderTarget)
{
	return m_direct3DDevice9->GetRenderTarget(RenderTargetIndex, ppRenderTarget);
}

HRESULT CzmDirect3DDevice9Detour::GetTransform(D3DTRANSFORMSTATETYPE State, D3DMATRIX* pMatrix)
{
	return m_direct3DDevice9->GetTransform(State, pMatrix);
}

HRESULT CzmDirect3DDevice9Detour::SetClipStatus(CONST D3DCLIPSTATUS9* pClipStatus)
{
	return m_direct3DDevice9->SetClipStatus(pClipStatus);
}

HRESULT CzmDirect3DDevice9Detour::SetRenderState(D3DRENDERSTATETYPE State, DWORD Value)
{
	return m_direct3DDevice9->SetRenderState(State, Value);;
}

HRESULT CzmDirect3DDevice9Detour::SetRenderTarget(DWORD RenderTargetIndex, IDirect3DSurface9* pRenderTarget)
{
	return m_direct3DDevice9->SetRenderTarget(RenderTargetIndex, pRenderTarget);
}

HRESULT CzmDirect3DDevice9Detour::SetTransform(D3DTRANSFORMSTATETYPE State, CONST D3DMATRIX* pMatrix)
{
	return m_direct3DDevice9->SetTransform(State, pMatrix);
}

HRESULT CzmDirect3DDevice9Detour::DeletePatch(UINT Handle)
{
	return m_direct3DDevice9->DeletePatch(Handle);
}

HRESULT CzmDirect3DDevice9Detour::DrawRectPatch(UINT Handle, CONST float* pNumSegs, CONST D3DRECTPATCH_INFO* pRectPatchInfo)
{
	return m_direct3DDevice9->DrawRectPatch(Handle, pNumSegs, pRectPatchInfo);
}

HRESULT CzmDirect3DDevice9Detour::DrawTriPatch(UINT Handle, CONST float* pNumSegs, CONST D3DTRIPATCH_INFO* pTriPatchInfo)
{
	return m_direct3DDevice9->DrawTriPatch(Handle, pNumSegs, pTriPatchInfo);
}

HRESULT CzmDirect3DDevice9Detour::GetIndices(IDirect3DIndexBuffer9** ppIndexData)
{
	return m_direct3DDevice9->GetIndices(ppIndexData);
}

HRESULT CzmDirect3DDevice9Detour::SetIndices(IDirect3DIndexBuffer9* pIndexData)
{
	return m_direct3DDevice9->SetIndices(pIndexData);
}

HRESULT CzmDirect3DDevice9Detour::GetLight(DWORD Index, D3DLIGHT9* pLight)
{
	return m_direct3DDevice9->GetLight(Index, pLight);
}

HRESULT CzmDirect3DDevice9Detour::GetLightEnable(DWORD Index, BOOL* pEnable)
{
	return m_direct3DDevice9->GetLightEnable(Index, pEnable);
}

HRESULT CzmDirect3DDevice9Detour::GetMaterial(D3DMATERIAL9* pMaterial)
{
	return m_direct3DDevice9->GetMaterial(pMaterial);
}

HRESULT CzmDirect3DDevice9Detour::LightEnable(DWORD LightIndex, BOOL bEnable)
{
	return m_direct3DDevice9->LightEnable(LightIndex, bEnable);
}

HRESULT CzmDirect3DDevice9Detour::SetLight(DWORD Index, CONST D3DLIGHT9* pLight)
{

	return m_direct3DDevice9->SetLight(Index, pLight);
}

HRESULT CzmDirect3DDevice9Detour::SetMaterial(CONST D3DMATERIAL9* pMaterial)
{
	return m_direct3DDevice9->SetMaterial(pMaterial);
}

HRESULT CzmDirect3DDevice9Detour::MultiplyTransform(D3DTRANSFORMSTATETYPE State, CONST D3DMATRIX* pMatrix)
{
	return m_direct3DDevice9->MultiplyTransform(State, pMatrix);
}

HRESULT CzmDirect3DDevice9Detour::ProcessVertices(UINT SrcStartIndex, UINT DestIndex, UINT VertexCount, IDirect3DVertexBuffer9* pDestBuffer, IDirect3DVertexDeclaration9* pVertexDecl, DWORD Flags)
{
	return m_direct3DDevice9->ProcessVertices(SrcStartIndex, DestIndex, VertexCount, pDestBuffer, pVertexDecl, Flags);
}

HRESULT CzmDirect3DDevice9Detour::GetCurrentTexturePalette(UINT* pPaletteNumber)
{
	return m_direct3DDevice9->GetCurrentTexturePalette(pPaletteNumber);
}

HRESULT CzmDirect3DDevice9Detour::GetPaletteEntries(UINT PaletteNumber, PALETTEENTRY* pEntries)
{
	return m_direct3DDevice9->GetPaletteEntries(PaletteNumber, pEntries);
}

HRESULT CzmDirect3DDevice9Detour::SetCurrentTexturePalette(UINT PaletteNumber)
{
	return m_direct3DDevice9->SetCurrentTexturePalette(PaletteNumber);
}

HRESULT CzmDirect3DDevice9Detour::SetPaletteEntries(UINT PaletteNumber, CONST PALETTEENTRY* pEntries)
{
	return m_direct3DDevice9->SetPaletteEntries(PaletteNumber, pEntries);
}

HRESULT CzmDirect3DDevice9Detour::CreatePixelShader(CONST DWORD* pFunction, IDirect3DPixelShader9** ppShader)
{
	return m_direct3DDevice9->CreatePixelShader(pFunction, ppShader);
}

HRESULT CzmDirect3DDevice9Detour::GetPixelShader(IDirect3DPixelShader9** ppShader)
{
	return m_direct3DDevice9->GetPixelShader(ppShader);
}

HRESULT CzmDirect3DDevice9Detour::SetPixelShader(IDirect3DPixelShader9* pShader)
{
	return m_direct3DDevice9->SetPixelShader(pShader);
}

HRESULT CzmDirect3DDevice9Detour::DrawIndexedPrimitive(D3DPRIMITIVETYPE Type, INT BaseVertexIndex, UINT MinVertexIndex, UINT NumVertices, UINT startIndex, UINT primCount)
{
	return m_direct3DDevice9->DrawIndexedPrimitive(Type, BaseVertexIndex, MinVertexIndex, NumVertices, startIndex, primCount);
}

HRESULT CzmDirect3DDevice9Detour::DrawIndexedPrimitiveUP(D3DPRIMITIVETYPE PrimitiveType, UINT MinIndex, UINT NumVertices, UINT PrimitiveCount, CONST void* pIndexData, D3DFORMAT IndexDataFormat, CONST void* pVertexStreamZeroData, UINT VertexStreamZeroStride)
{
	return m_direct3DDevice9->DrawIndexedPrimitiveUP(PrimitiveType, MinIndex, NumVertices, PrimitiveCount, pIndexData, IndexDataFormat, pVertexStreamZeroData, VertexStreamZeroStride);
}

HRESULT CzmDirect3DDevice9Detour::DrawPrimitive(D3DPRIMITIVETYPE PrimitiveType, UINT StartVertex, UINT PrimitiveCount)
{
	return m_direct3DDevice9->DrawPrimitive(PrimitiveType, StartVertex, PrimitiveCount);
}

HRESULT CzmDirect3DDevice9Detour::DrawPrimitiveUP(D3DPRIMITIVETYPE PrimitiveType, UINT PrimitiveCount, CONST void* pVertexStreamZeroData, UINT VertexStreamZeroStride)
{
	return m_direct3DDevice9->DrawPrimitiveUP(PrimitiveType, PrimitiveCount, pVertexStreamZeroData, VertexStreamZeroStride);
}

HRESULT CzmDirect3DDevice9Detour::BeginScene() //EndScene
{
	czm_BeginSceneA( CzmCrNewDevDTO{this,} );
	HRESULT hr2 = m_direct3DDevice9->BeginScene();
	if( !FAILED(hr2) ){
		czm_BeginSceneB( CzmCrNewDevDTO{this,} );
	}
	return hr2;
}

HRESULT CzmDirect3DDevice9Detour::GetStreamSource(UINT StreamNumber, IDirect3DVertexBuffer9** ppStreamData, UINT* OffsetInBytes, UINT* pStride)
{
	return m_direct3DDevice9->GetStreamSource(StreamNumber, ppStreamData, OffsetInBytes, pStride);
}

HRESULT CzmDirect3DDevice9Detour::SetStreamSource(UINT StreamNumber, IDirect3DVertexBuffer9* pStreamData, UINT OffsetInBytes, UINT Stride)
{
	return m_direct3DDevice9->SetStreamSource(StreamNumber, pStreamData, OffsetInBytes, Stride);
}

HRESULT CzmDirect3DDevice9Detour::GetDepthStencilSurface(IDirect3DSurface9** ppZStencilSurface)
{
	return m_direct3DDevice9->GetDepthStencilSurface(ppZStencilSurface);
}

HRESULT CzmDirect3DDevice9Detour::GetTexture(DWORD Stage, IDirect3DBaseTexture9** ppTexture)
{
	return m_direct3DDevice9->GetTexture(Stage, ppTexture);
}

HRESULT CzmDirect3DDevice9Detour::GetTextureStageState(DWORD Stage, D3DTEXTURESTAGESTATETYPE Type, DWORD* pValue)
{
	return m_direct3DDevice9->GetTextureStageState(Stage, Type, pValue);
}

HRESULT CzmDirect3DDevice9Detour::SetTexture(DWORD Stage, IDirect3DBaseTexture9* pTexture)
{
	return m_direct3DDevice9->SetTexture(Stage, pTexture);
}

HRESULT CzmDirect3DDevice9Detour::SetTextureStageState(DWORD Stage, D3DTEXTURESTAGESTATETYPE Type, DWORD Value)
{
	return m_direct3DDevice9->SetTextureStageState(Stage, Type, Value);
}

HRESULT CzmDirect3DDevice9Detour::UpdateTexture(IDirect3DBaseTexture9* pSourceTexture, IDirect3DBaseTexture9* pDestinationTexture)
{
	return m_direct3DDevice9->UpdateTexture(pSourceTexture, pDestinationTexture);
}

HRESULT CzmDirect3DDevice9Detour::ValidateDevice(DWORD* pNumPasses)
{
	return m_direct3DDevice9->ValidateDevice(pNumPasses);
}

HRESULT CzmDirect3DDevice9Detour::GetClipPlane(DWORD Index, float* pPlane)
{
	return m_direct3DDevice9->GetClipPlane(Index, pPlane);
}

HRESULT CzmDirect3DDevice9Detour::SetClipPlane(DWORD Index, CONST float* pPlane)
{
	return m_direct3DDevice9->SetClipPlane(Index, pPlane);
}

HRESULT CzmDirect3DDevice9Detour::Clear(DWORD Count, CONST D3DRECT* pRects, DWORD Flags, D3DCOLOR Color, float Z, DWORD Stencil)
{
	return m_direct3DDevice9->Clear(Count, pRects, Flags, Color, Z, Stencil);
}

HRESULT CzmDirect3DDevice9Detour::GetViewport(D3DVIEWPORT9* pViewport)
{
	return m_direct3DDevice9->GetViewport(pViewport);
}

HRESULT CzmDirect3DDevice9Detour::SetViewport(CONST D3DVIEWPORT9* pViewport)
{
	return m_direct3DDevice9->SetViewport(pViewport);
}

HRESULT CzmDirect3DDevice9Detour::CreateVertexShader(CONST DWORD* pFunction, IDirect3DVertexShader9** ppShader)
{
	return m_direct3DDevice9->CreateVertexShader(pFunction, ppShader);
}

HRESULT CzmDirect3DDevice9Detour::GetVertexShader(IDirect3DVertexShader9** ppShader)
{
	return m_direct3DDevice9->GetVertexShader(ppShader);
}

HRESULT CzmDirect3DDevice9Detour::SetVertexShader(IDirect3DVertexShader9* pShader)
{
	return m_direct3DDevice9->SetVertexShader(pShader);
}

HRESULT CzmDirect3DDevice9Detour::CreateQuery(D3DQUERYTYPE Type, IDirect3DQuery9** ppQuery)
{
	return m_direct3DDevice9->CreateQuery(Type, ppQuery);
}

HRESULT CzmDirect3DDevice9Detour::SetPixelShaderConstantB(UINT StartRegister, CONST BOOL* pConstantData, UINT  BoolCount)
{
	return m_direct3DDevice9->SetPixelShaderConstantB(StartRegister, pConstantData, BoolCount);
}

HRESULT CzmDirect3DDevice9Detour::GetPixelShaderConstantB(UINT StartRegister, BOOL* pConstantData, UINT BoolCount)
{
	return m_direct3DDevice9->GetPixelShaderConstantB(StartRegister, pConstantData, BoolCount);
}

HRESULT CzmDirect3DDevice9Detour::SetPixelShaderConstantI(UINT StartRegister, CONST int* pConstantData, UINT Vector4iCount)
{
	return m_direct3DDevice9->SetPixelShaderConstantI(StartRegister, pConstantData, Vector4iCount);
}

HRESULT CzmDirect3DDevice9Detour::GetPixelShaderConstantI(UINT StartRegister, int* pConstantData, UINT Vector4iCount)
{
	return m_direct3DDevice9->GetPixelShaderConstantI(StartRegister, pConstantData, Vector4iCount);
}

HRESULT CzmDirect3DDevice9Detour::SetPixelShaderConstantF(UINT StartRegister, CONST float* pConstantData, UINT Vector4fCount)
{
	return m_direct3DDevice9->SetPixelShaderConstantF(StartRegister, pConstantData, Vector4fCount);
}

HRESULT CzmDirect3DDevice9Detour::GetPixelShaderConstantF(UINT StartRegister, float* pConstantData, UINT Vector4fCount)
{
	return m_direct3DDevice9->GetPixelShaderConstantF(StartRegister, pConstantData, Vector4fCount);
}

HRESULT CzmDirect3DDevice9Detour::SetStreamSourceFreq(UINT StreamNumber, UINT Divider)
{
	return m_direct3DDevice9->SetStreamSourceFreq(StreamNumber, Divider);
}

HRESULT CzmDirect3DDevice9Detour::GetStreamSourceFreq(UINT StreamNumber, UINT* Divider)
{
	return m_direct3DDevice9->GetStreamSourceFreq(StreamNumber, Divider);
}

HRESULT CzmDirect3DDevice9Detour::SetVertexShaderConstantB(UINT StartRegister, CONST BOOL* pConstantData, UINT  BoolCount)
{
	return m_direct3DDevice9->SetVertexShaderConstantB(StartRegister, pConstantData, BoolCount);
}

HRESULT CzmDirect3DDevice9Detour::GetVertexShaderConstantB(UINT StartRegister, BOOL* pConstantData, UINT BoolCount)
{
	return m_direct3DDevice9->GetVertexShaderConstantB(StartRegister, pConstantData, BoolCount);
}

HRESULT CzmDirect3DDevice9Detour::SetVertexShaderConstantF(UINT StartRegister, CONST float* pConstantData, UINT Vector4fCount)
{
	return m_direct3DDevice9->SetVertexShaderConstantF(StartRegister, pConstantData, Vector4fCount);
}

HRESULT CzmDirect3DDevice9Detour::GetVertexShaderConstantF(UINT StartRegister, float* pConstantData, UINT Vector4fCount)
{
	return m_direct3DDevice9->GetVertexShaderConstantF(StartRegister, pConstantData, Vector4fCount);
}

HRESULT CzmDirect3DDevice9Detour::SetVertexShaderConstantI(UINT StartRegister, CONST int* pConstantData, UINT Vector4iCount)
{
	return m_direct3DDevice9->SetVertexShaderConstantI(StartRegister, pConstantData, Vector4iCount);
}

HRESULT CzmDirect3DDevice9Detour::GetVertexShaderConstantI(UINT StartRegister, int* pConstantData, UINT Vector4iCount)
{
	return m_direct3DDevice9->GetVertexShaderConstantI(StartRegister, pConstantData, Vector4iCount);
}

HRESULT CzmDirect3DDevice9Detour::SetFVF(DWORD FVF)
{
	return m_direct3DDevice9->SetFVF(FVF);
}

HRESULT CzmDirect3DDevice9Detour::GetFVF(DWORD* pFVF)
{
	return m_direct3DDevice9->GetFVF(pFVF);
}

HRESULT CzmDirect3DDevice9Detour::CreateVertexDeclaration(CONST D3DVERTEXELEMENT9* pVertexElements, IDirect3DVertexDeclaration9** ppDecl)
{
	return m_direct3DDevice9->CreateVertexDeclaration(pVertexElements, ppDecl);
}

HRESULT CzmDirect3DDevice9Detour::SetVertexDeclaration(IDirect3DVertexDeclaration9* pDecl)
{
	return m_direct3DDevice9->SetVertexDeclaration(pDecl);
}

HRESULT CzmDirect3DDevice9Detour::GetVertexDeclaration(IDirect3DVertexDeclaration9** ppDecl)
{
	return m_direct3DDevice9->GetVertexDeclaration(ppDecl);
}

HRESULT CzmDirect3DDevice9Detour::SetNPatchMode(float nSegments)
{
	return m_direct3DDevice9->SetNPatchMode(nSegments);
}

float CzmDirect3DDevice9Detour::GetNPatchMode(THIS)
{
	return m_direct3DDevice9->GetNPatchMode();
}

int CzmDirect3DDevice9Detour::GetSoftwareVertexProcessing(THIS)
{
	return m_direct3DDevice9->GetSoftwareVertexProcessing();
}

HRESULT CzmDirect3DDevice9Detour::SetSoftwareVertexProcessing(BOOL bSoftware)
{
	return m_direct3DDevice9->SetSoftwareVertexProcessing(bSoftware);
}

HRESULT CzmDirect3DDevice9Detour::SetScissorRect(CONST RECT* pRect)
{
	return m_direct3DDevice9->SetScissorRect(pRect);
}

HRESULT CzmDirect3DDevice9Detour::GetScissorRect(RECT* pRect)
{
	return m_direct3DDevice9->GetScissorRect(pRect);
}

HRESULT CzmDirect3DDevice9Detour::GetSamplerState(DWORD Sampler, D3DSAMPLERSTATETYPE Type, DWORD* pValue)
{
	return m_direct3DDevice9->GetSamplerState(Sampler, Type, pValue);
}

HRESULT CzmDirect3DDevice9Detour::SetSamplerState(DWORD Sampler, D3DSAMPLERSTATETYPE Type, DWORD Value)
{
	return m_direct3DDevice9->SetSamplerState(Sampler, Type, Value);
}

HRESULT CzmDirect3DDevice9Detour::SetDepthStencilSurface(IDirect3DSurface9* pNewZStencil)
{
	return m_direct3DDevice9->SetDepthStencilSurface(pNewZStencil);
}

HRESULT CzmDirect3DDevice9Detour::CreateOffscreenPlainSurface(UINT Width, UINT Height, D3DFORMAT Format, D3DPOOL Pool, IDirect3DSurface9** ppSurface, HANDLE* pSharedHandle)
{
	return m_direct3DDevice9->CreateOffscreenPlainSurface(Width, Height, Format, Pool, ppSurface, pSharedHandle);
}

HRESULT CzmDirect3DDevice9Detour::ColorFill(IDirect3DSurface9* pSurface, CONST RECT* pRect, D3DCOLOR color)
{
	return m_direct3DDevice9->ColorFill(pSurface, pRect, color);
}

HRESULT CzmDirect3DDevice9Detour::StretchRect(IDirect3DSurface9* pSourceSurface, CONST RECT* pSourceRect, IDirect3DSurface9* pDestSurface, CONST RECT* pDestRect, D3DTEXTUREFILTERTYPE Filter)
{
	return m_direct3DDevice9->StretchRect(pSourceSurface, pSourceRect, pDestSurface, pDestRect, Filter);
}

HRESULT CzmDirect3DDevice9Detour::GetFrontBufferData(UINT iSwapChain, IDirect3DSurface9* pDestSurface)
{
	return m_direct3DDevice9->GetFrontBufferData(iSwapChain, pDestSurface);
}

HRESULT CzmDirect3DDevice9Detour::GetRenderTargetData(IDirect3DSurface9* pRenderTarget, IDirect3DSurface9* pDestSurface)
{
	return m_direct3DDevice9->GetRenderTargetData(pRenderTarget, pDestSurface);
}

HRESULT CzmDirect3DDevice9Detour::UpdateSurface(IDirect3DSurface9* pSourceSurface, CONST RECT* pSourceRect, IDirect3DSurface9* pDestinationSurface, CONST POINT* pDestPoint)
{
	return m_direct3DDevice9->UpdateSurface(pSourceSurface, pSourceRect, pDestinationSurface, pDestPoint);
}

HRESULT CzmDirect3DDevice9Detour::EndScene()
{
	// Used to render our ImGui interface
	//esHook.EndScene_hook(m_direct3DDevice9);

	czm_EndSceneA( CzmCrNewDevDTO{ this,} );

	return m_direct3DDevice9->EndScene();
}
IDirect3D9* __stdcall czm_Direct3DCreate9( UINT SDKVersion )
{
	//spd::log()->info("{} -> Creating IDirect3D9 object", __FUNCTION__);
	hxdw_StdPrint2("CZM: czm_Direct3DCreate9()\n");

	assert( Czm );
	assert( Czm->fnOgDirect3DCreate9 );
	using fn_t = decltype(Direct3DCreate9)*;

	IDirect3D9* d3dInterface = ((fn_t)Czm->fnOgDirect3DCreate9)( SDKVersion );
	return new CzmDirect3D9Detour( d3dInterface );
}
HRESULT CzmDirect3D9Detour::CreateDevice( UINT Adapter, D3DDEVTYPE DeviceType, HWND hFocusWindow, DWORD BehaviorFlags, D3DPRESENT_PARAMETERS* pPresentationParameters, IDirect3DDevice9** ppReturnedDeviceInterface)
{
	// Force v-sync off
	//if (pConfig->bDisableVsync)
	//	pPresentationParameters->PresentationInterval = D3DPRESENT_INTERVAL_IMMEDIATE;
	hxdw_StdPrint2("CZM: CzmDirect3D9Detour::CreateDevice()\n");

	IDirect3DDevice9* device2 = nullptr;

	HRESULT result = m_direct3D9->CreateDevice(Adapter, DeviceType, hFocusWindow, BehaviorFlags, pPresentationParameters, &device2);
	if( FAILED(result) ){
		*ppReturnedDeviceInterface = nullptr;
		return result;
	}
	*ppReturnedDeviceInterface = new CzmDirect3DDevice9Detour(device2);

	//assert( Czm );
	//assert( Czm->calbCreatedNewD3d9Device );
	//if( Czm->calbCreatedNewD3d9Device ){
	//Czm->calbCreatedNewD3d9Device( CzmCrNewDevDTO{ *ppReturnedDeviceInterface,} );
	//}
	return result;
}
CzmDirect3D9Detour::CzmDirect3D9Detour( IDirect3D9* direct3D9 )
	: m_direct3D9(direct3D9)
{
	//hxdw_StdPrint2("CZM: CzmDirect3D9Detour::_contructor_()\n");
}
CzmDirect3D9Detour::~CzmDirect3D9Detour()
{
	m_direct3D9->Release();
}
int czm_Init_D3d9Detour()
{
	HMODULE hD3d9Dll = LoadLibrary("D3d9.dll");
	assert( hD3d9Dll );
	std::shared_ptr<void*> raii2( nullptr, [&]( void* ){
		if(hD3d9Dll){
			FreeLibrary( hD3d9Dll );
			hD3d9Dll = 0;
		}
	});
	{
		void* pD3dCrFunc = GetProcAddress( hD3d9Dll, "Direct3DCreate9");
		assert( pD3dCrFunc );

		//DWORD dwOldProt = 0;
		//bool rs2 = !!VirtualProtect( pD3dCrFunc, 16, PAGE_EXECUTE_READWRITE, &dwOldProt );
		//assert(rs2);

		if( MH_CreateHook( pD3dCrFunc, czm_Direct3DCreate9, (void**)(&Czm->fnOgDirect3DCreate9)) ) {
			//assert(00);
			//MessageBox(0,"","",0);
			return 103;
		}
		if( MH_EnableHook( pD3dCrFunc) ) {
			//MH_StatusToString();
			//assert(000);
			//MessageBox(0,"","",0);
			return 104;
		}
	}
	return 0;
}
CzmDirect3DDevice9Detour::
CzmDirect3DDevice9Detour( IDirect3DDevice9* direct3DDevice9 )
	: m_direct3DDevice9( direct3DDevice9 )
{
	assert( direct3DDevice9 );
	czm_CreatedNewD3d9Device( CzmCrNewDevDTO{ this,} );
}
CzmDirect3DDevice9Detour::~CzmDirect3DDevice9Detour()
{
	assert( m_direct3DDevice9 );
	m_direct3DDevice9->Release();
	//m_direct3DDevice9 : IDirect3DDevice9*
	czm_DeleteD3d9Device( CzmCrNewDevDTO{ this,} );
}


