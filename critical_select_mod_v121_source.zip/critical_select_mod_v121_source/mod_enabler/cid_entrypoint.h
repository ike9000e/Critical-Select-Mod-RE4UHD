#include <memory>
#include <vector>
#include <string>
#include <algorithm>
#include <functional>
#include <assert.h>
#include <windows.h>
#include <shellapi.h>  //SHFileOperation(), SHFILEOPSTRUCT
#include "detours.h"

enum class CID_EIM {
	CID_EIM_EInstall = 1,
	CID_EIM_EUninstall,
};

struct CidData {
	std::string srCfgFExtName = "dsv";
	std::string srSelfExePathName;
	std::string srTargetPEPathName;   //target PE file, path name.
	std::vector<std::string> aAssetFBNames;
	//cnf-s:
	std::string srAppName = "DLL Installer For Executable Files"; //cnf
	std::string srExtFilter = "*.EXE;*.DLL";
	std::string srBkpExt = "bkp";
	std::string srDllToAddName;// = "dll_dummy_fkdp5o.dll";
	std::string srRegPEPath;
	std::string srAssetFiles;  // one or more file names, semicolon-separated. Base name only, no path part.
};
extern CidData* Cid2;

