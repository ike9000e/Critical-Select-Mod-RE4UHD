#include "hxdw_process.h"
#include <cstring>
#include <assert.h>
#include <assert.h>
#include <windows.h>
#include <tlhelp32.h>  //CreateToolhelp32Snapshot().
#include <psapi.h>     //EnumProcessModules() -> psapi.lib.
#include <dbghelp.h>   //ImageNtHeader() -> dbghelp.lib.
#include "hxdw_utils.h"

/// Returns module base address - the image base.
/// For example, can be used with offsets of compiled values.
/// Offsets can be obtained from eg. Cheat Engine.
/// Can be used inside DLLs or EXEs.
/// \param procId - process id, pid. Eg. use GetCurrentProcessId().
///                 If zero, it is current process.
///                 If both, 'procId' and 'szModName' are null, more reliable method is used.
/// \param szModName - module name of DLL or EXE, eg. "Notepad.exe". Base name - no path part.
///                    if zero, retrieves for the first EXE.
/// ref: https://stackoverflow.com/questions/46821118/c-c-how-can-i-get-base-address-of-exe-running-process
size_t hxdw_GetModuleBaseAddress( uint32_t procId, const char* szModName )
{
	size_t uModBaseAddr = 0;
	const bool bGetForExe = ( !szModName || !(*szModName) );
	const bool bGetForCurrProc = ( !procId && bGetForExe ? 1 : 0 );
	procId = ( procId ? procId : GetCurrentProcessId() );
	if( bGetForCurrProc ){
		// if for current process, use more reliable method
		// by not using tool-snapshot utility.
		HMODULE hModule = 0;
		hxdw_EnumerateProcessModules( procId, [&](const HxdwModOnEnum& inp)->bool{
				std::string ext2 = hxdw_SplitExt( inp.srPath.c_str() ).second;
				if( !lstrcmpi( ext2.c_str(), "exe") ){
					hModule = (HMODULE)inp.hDll;
					return 0;
				}
				return 1;
			});
		if( hModule ){
			// include psapi.h, link to psapi.lib
			// https://stackoverflow.com/a/15200993
			MODULEINFO mii;
			std::memset( &mii, 0, sizeof(mii) );
			bool rs2 = !!GetModuleInformation( GetCurrentProcess(), hModule, &mii, sizeof(mii) );
			if( rs2 ){
				size_t uModBaseAddr2 = (size_t)mii.lpBaseOfDll;
				return uModBaseAddr2;
			}
		}
		return 0;
	}
	HANDLE hSnap = CreateToolhelp32Snapshot( TH32CS_SNAPMODULE | TH32CS_SNAPMODULE32, procId );
	if( hSnap != INVALID_HANDLE_VALUE ){
		MODULEENTRY32 aModEntry;
		aModEntry.dwSize = sizeof(aModEntry);
		for( bool rs2 = !!Module32First( hSnap, &aModEntry ); rs2; rs2 = !!Module32Next( hSnap, &aModEntry ) ){
			if( bGetForExe ){
				std::string ext2 = hxdw_SplitExt(aModEntry.szModule).second;
				//if( !hxdw_StrCmpOpt( ext2.c_str(), "exe", -1, "i") ){}
				if( !lstrcmpi( ext2.c_str(), "exe") ){
					uModBaseAddr = (size_t)aModEntry.modBaseAddr;
					break;
				}
			}else{
				assert(szModName);
				if( !lstrcmpi( aModEntry.szModule, szModName ) ){
					uModBaseAddr = (size_t)aModEntry.modBaseAddr;
					break;
				}
			}
		}
		CloseHandle( hSnap );
	}
	return uModBaseAddr;
}
bool hxdw_EnumerateProcessModules( uint32_t pid2, std::function<bool(const HxdwModOnEnum&)> calb2 )
{
	HMODULE hMods[1024] = {0,};
	HANDLE hProcess;
	DWORD cbNeeded, processID = static_cast<DWORD>( pid2 );
	processID = (processID ? processID : GetCurrentProcessId());
	//
	hProcess = OpenProcess( PROCESS_QUERY_INFORMATION |
							PROCESS_VM_READ,
							FALSE, processID );
	if( !hProcess ){
		return 0;
	}
	// Get a list of all the modules in this process.
	if( EnumProcessModules( hProcess, hMods, sizeof(hMods), &cbNeeded ) ){
		unsigned int ii2;
		for( ii2 = 0; ii2 < ( cbNeeded / sizeof(HMODULE) ); ii2++ ){
			char szModName[MAX_PATH];
			bool rs2 = !!GetModuleFileNameEx( hProcess, hMods[ii2], szModName, sizeof(szModName) );
			if( rs2 ){
				HxdwModOnEnum moe = { hMods[ii2], szModName,};
				if( !calb2( moe ) ){
					break;
				}
			}
		}
	}
	// Release the handle to the process.
	CloseHandle( hProcess );
	return 1;
}

/**
	Check if a process is running
	\param processName Name of process to check if is running
	Returns True if the process is running.
	https://stackoverflow.com/a/14751302
	//IsProcessRunning()
*/
bool hxdw_IsExistingProcess( uint32_t pid_ )
{
	const DWORD pid2 = static_cast<DWORD>( pid_ );
	bool bExists = false;
	PROCESSENTRY32 prentr;
	prentr.dwSize = sizeof(PROCESSENTRY32);
	HANDLE snapshott = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, NULL);
	if( Process32First( snapshott, &prentr ) ){
		while ( Process32Next( snapshott, &prentr ) ){
			if( pid2 && prentr.th32ProcessID == pid2 ){
				bExists = 1;
				break;
			}
			//prentr.th32ParentProcessID//prentr.szExeFile;
		}
	}
	CloseHandle( snapshott );
	return bExists;
}

std::string hxdw_GetProcessBinaryPath( uint32_t pid2 )
{
	std::string outp;
	hxdw_EnumerateProcessModules( pid2, [&](const HxdwModOnEnum& inp)->bool{
		std::string ext2;
		ext2 = hxdw_SplitExt( hxdw_SplitPath( inp.srPath ).second ).second;
		if( !hxdw_StrCmpOpt( ext2.c_str(), "exe", -1, "i") ){
			outp = inp.srPath.c_str();
			return 0;
		}
		return 1;
	});
	return outp;
}


/**
	Enumerates module sections.
	\param hMod - module handle.
		\code
			// Examples:
			HMODULE hMod = GetModuleHandleA("kernelbase.dll");
			HMODULE hMod = GetModuleHandleA("calc.exe");
		\endcode
	Ref:
	https://reverseengineering.stackexchange.com/a/22140
	https://docs.microsoft.com/en-us/windows/win32/api/dbghelp/nf-dbghelp-imagentheader
	https://docs.microsoft.com/en-us/windows/win32/api/winnt/ns-winnt-image_nt_headers32
	https://docs.microsoft.com/en-us/windows/win32/api/winnt/ns-winnt-image_section_header

	Example:
		======================================
		Name            VA      Raw     Size
		======================================
		.text           1000    400     102600
		.rdata          104000  102a00  155e00
		.data           25a000  258800  1600
		.pdata          25f000  259e00  e800
		.didat          26e000  268600  800
		.rsrc           26f000  268e00  600
		.reloc          270000  269400  22400
*/
bool hxdw_EnumerateModuleSections(
		void* hMod, //HMODULE
		std::function<bool( const HxdwMSectEnum& inp )> calb2 )
{
	hMod = ( hMod ? hMod : GetModuleHandleA( nullptr ) );
	if( !hMod ){
		return 0;
	}
	#ifdef _WIN64
		PIMAGE_NT_HEADERS64 NtHeader = ImageNtHeader(hMod);
	#else
		PIMAGE_NT_HEADERS32 NtHeader = ImageNtHeader(hMod);
	#endif
	WORD NumSections = NtHeader->FileHeader.NumberOfSections;
	PIMAGE_SECTION_HEADER section2 = IMAGE_FIRST_SECTION(NtHeader);
	//DWORD old_protect;
	//VirtualProtect( section2, 2, PAGE_READONLY, &old_protect );
	for( WORD i = 0; i < NumSections; i++ ){
		//char bfr2[256];
		//snprintf( bfr2, sizeof(bfr2),
		//		"%-8s\t%x\t%x\t%x",
		//			section2->Name,
		//			section2->VirtualAddress,
		//			section2->PointerToRawData,
		//			section2->SizeOfRawData );
		char bfrName[IMAGE_SIZEOF_SHORT_NAME+1] = "";
		std::memset( bfrName, 0, sizeof(bfrName) );
		std::memcpy( bfrName, section2->Name, IMAGE_SIZEOF_SHORT_NAME );
		const HxdwMSectEnum sMSec = {
				bfrName,
				section2->VirtualAddress,
				section2->PointerToRawData,
				section2->SizeOfRawData, };
		if( !calb2( sMSec ) ){
			break;
		}
		section2++;
	}
	return 1;
}
/**
	Retrieves address (aka. offset aka. VA) of the section (aka. segment) of the module.
	Address also known as offset or virtual address or VA.
	Section also known as segment.

	Returned is the virtual address.
	Eg. the well known section name of the code section is ".text".
	Passing NULL as 'hMod' auto reitrieves the address of the main
	module, executable, the ".exe" (ie. not any of the DLLs).

	\verbatim
		=======================================
		| Name     VA      Raw     Size
		=======================================
		[.text     1000    400     706200]
		[PSFD00    708000  706600  3600]
		[.rdata    70c000  709c00  e6a00]
		[.data     7f3000  7f0600  58a00]
		[.idata    1310000 849000  2000]
		[.rsrc     1312000 84b000  2800]
		[.reloc    1315000 84d800  67600]
	\endverbatim

	Code section address is usefull for patching opcodes
	inside the running executable.
	When using debugger, like IDA, after obtaining an offset inside the
	code section, it then must must be added to both, the image base and
	the section address.

	\param hMod - Handle of a module (HMODULE). If NULL, defaults to the main executable one.
	\param szSecName - section name, eg. ".text". If NULL defaults to ".text".
	\return Code section address or NULL on error.

	// VirtualAddress:
	//     The address of the first byte of the section when loaded into
	//     memory, relative to the image base. For object files, this is
	//     the address of the first byte before relocation is applied.

	\code
		// Example
		size_t addrExeBase     = hxdw_GetModuleBaseAddress(0,"");
		size_t addrCodeSection = hxdw_GetModuleSectionVAddress(0,".text");
		size_t addr_to_patch   = addrExeBase + addrCodeSection + 0xADD8E5;
		std::memcpy( (void*)addr_to_patch, pNewBytes, 5 );
	\endcode
*/
size_t hxdw_GetModuleSectionVAddress( void* hMod, const char* szSecName )
{
	hMod = ( hMod ? hMod : GetModuleHandle( nullptr ) );
	szSecName = ( szSecName ? szSecName : ".text" );
	size_t rslt = 0;
	hxdw_EnumerateModuleSections( hMod, [&]( const HxdwMSectEnum& inp )->bool{
		if( !hxdw_StrCmpOpt( szSecName, inp.szName, -1, "i") ){
			rslt = (size_t)inp.uVirtualAddress;
			return 0;  //0: finish-enumeration.
		}
		return 1;
	} );
	return rslt;
}
/*
	Returns pointer that can be used with memcpy style calls.

	uPID - can be zero. zero defaults to the current process.
	szModName - can be null. null defaults to the main executable (.exe) one.
	szSecName - can be null. null defaults to ".text" - the code section.
	uInSectionOffset - offset in the section, from the section begin.
*/
void* hxdw_GetPtrGivenInSectionOffset(
			uint32_t uPID, const char* szModName,
			const char* szSecName, size_t uInSectionOffset )
{
	szModName = ( szModName && *szModName ? szModName : nullptr );
	void* hMod = GetModuleHandle( szModName );
	if( hMod ){
		size_t addrExeBase = hxdw_GetModuleBaseAddress( uPID, szModName );
		if( addrExeBase ){
			size_t addrCodeSection = hxdw_GetModuleSectionVAddress( hMod, szSecName );
			if( addrCodeSection ){
				size_t addr_to_poke = addrExeBase + addrCodeSection + uInSectionOffset;
				return (void*)addr_to_poke;
			}
		}
	}
	return nullptr;
}


