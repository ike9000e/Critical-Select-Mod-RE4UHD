#include "hxdw_detours_misc.h"
#include <windows.h>
#include <assert.h>
#include "detours.h"   //detours32.lib or detours64.lib

// Renamed, orig: hxdw_GetPEFileImports().
bool hxdw_GetPEFileImportDlls( const char* szFname, std::vector<std::string>* outp, std::string* err2 )
{
	std::string err4, &err3 = ( err2 ? *err2 : err4 );
	PDETOUR_BINARY pExeBin = 0;
	HANDLE hf2 = 0;
	hf2 = CreateFileA( szFname, GENERIC_READ, FILE_SHARE_READ,
					   0, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0 );
	if( !hf2 || hf2 == INVALID_HANDLE_VALUE ){
		err3 = "Failed to open input file [ZuVAM9qi]";
		return 0;
	}
	std::shared_ptr<int> raii2( 0, [&]( int* ){
			if(pExeBin){
				DetourBinaryClose( pExeBin ); pExeBin = 0;
			}
			if(hf2){
				CloseHandle( hf2 ); hf2 = 0;
			}
	} );
	pExeBin = DetourBinaryOpen( hf2 );
	if( !pExeBin ){
		err3 = "Binary open failed [M9qiZuVA]";
		return 0;
	}
	auto func2 = [&]( const char* szDllFname )->bool{
			outp->push_back( szDllFname );
			return 1;
	};
	std::function<bool(const char*)> func3(func2);
	DetourBinaryEditImports( pExeBin, &func3, 0,
			[]( PVOID user2, LPCSTR, LPCSTR szFile, LPCSTR* )->BOOL{
					auto func3 = *reinterpret_cast<std::function<bool(const char*)>*>(user2);
					return func3( szFile );
	}, 0, 0 );
	return 1;
}
bool hxdw_GetPEExports( const char* pathname, std::vector<std::string>& outp )
{
	HMODULE hDll = LoadLibraryExA( pathname, 0, DONT_RESOLVE_DLL_REFERENCES );
	if( !hDll )
		return 0;
	using Fnc2_t = std::function<bool(int, const char*)>;
    auto fnc2 = Fnc2_t( [&]( int nOrdinal, const char* szExportName )->bool{
			outp.push_back( szExportName );
			return 1;
	});
	DetourEnumerateExports( hDll, &fnc2,
			[]( PVOID user2, ULONG nOrdinal, LPCSTR pszSymbol, PVOID pbTarget )->BOOL{
					Fnc2_t* fnc2 = reinterpret_cast<Fnc2_t*>( user2 );
					assert(fnc2);
					return (*fnc2)( static_cast<int>(nOrdinal), pszSymbol );
	});
	FreeLibrary(hDll);
	return 1;
}
/**
	Converts error code returned by any of Detours API into a string.
	Input can be result value fe. from DetourAttach().
*/
std::string hxdw_DetoursErrorToString( long errorcode )
{
	static const std::vector<std::pair<long,const char*>> aErrCodes = {
		{ ERROR_INVALID_BLOCK,"ERROR_INVALID_BLOCK",},
		{ ERROR_INVALID_HANDLE,"ERROR_INVALID_HANDLE",},
		{ ERROR_INVALID_OPERATION,"ERROR_INVALID_OPERATION",},
		{ ERROR_NOT_ENOUGH_MEMORY,"ERROR_NOT_ENOUGH_MEMORY",},
		{ ERROR_BAD_EXE_FORMAT,"ERROR_BAD_EXE_FORMAT",},
		{ ERROR_EXE_MARKED_INVALID,"ERROR_EXE_MARKED_INVALID",},
		{ ERROR_INVALID_EXE_SIGNATURE,"ERROR_INVALID_EXE_SIGNATURE",},
		{ ERROR_MOD_NOT_FOUND,"ERROR_MOD_NOT_FOUND",},
		{ ERROR_INVALID_DATA,"ERROR_INVALID_DATA",},
		//{ ERROR_OUT_OF_MEMORY,"ERROR_OUT_OF_MEMORY",},
	};
	const auto endd = aErrCodes.end();
	auto ir2 = std::find_if( aErrCodes.begin(), endd,
			[errorcode]( const std::pair<long,const char*>& a )->bool{
				return errorcode == a.first;
			});
	if( ir2 != endd ){
		return ir2->second;
	}
	return "<unknown>";
}
BOOL CALLBACK
hxdw_EnumPEFIDllCalb(PVOID user3, HMODULE hModule, LPCSTR pszDllName)
{
	assert( user3 );
	std::vector<HxdwEnumImportsDTO>* ls4 = reinterpret_cast<std::vector<HxdwEnumImportsDTO>*>( user3 );
	assert( ls4 );
	HxdwEnumImportsDTO se2 = { hModule,
		(pszDllName ? pszDllName : "*"), 0, "", nullptr,};
	ls4->push_back( se2 );
	return 1L;
}
BOOL CALLBACK
hxdw_EnumPEFIFuncCalb( PVOID user4, ULONG nOrdinal, LPCSTR pszFncName, PVOID* ppvFunc )
{
	std::vector<HxdwEnumImportsDTO>* ls4 = (std::vector<HxdwEnumImportsDTO>*) user4;
	assert( ls4 );
	char bfr2[64];
	std::sprintf( bfr2, "*%d", (int)nOrdinal );
	bool bByOrdinal = !pszFncName;
	HxdwEnumImportsDTO se3{ 0, "*",
		(bByOrdinal ? (int)nOrdinal : -1),
		(bByOrdinal ? bfr2 : pszFncName),
		(ppvFunc ? ppvFunc : nullptr),};
	ls4->push_back( se3 );
	return 1L;
}
/**
	Gets PE file imports, function names with DLL name each.

	NOTE: DetourEnumerateImports() is buggy. Does not pass
		  user pointer correctly. Detours Package Version 4.0.1.
*/
bool hxdw_GetPEFileImportFunctions(
		const char* szFname,
		std::function<bool(const HxdwEnumImportsDTO&)> calb2,
		const char* flags2,
		std::string* err2 )
{
	flags2 = (flags2 ? flags2 : "");
	assert( calb2 );
	std::string err4, &err3 = ( err2 ? *err2 : err4 );
	HMODULE hDll = 0;
	std::shared_ptr<int> raii3( 0, [&]( int* ){
		if(hDll){
			FreeLibrary(hDll);
			hDll = 0;
		}
	});
	hDll = LoadLibraryExA( szFname, 0, DONT_RESOLVE_DLL_REFERENCES );
	if( !hDll ){
		err3 = "LoadLibraryExA failed [J96ZuZ]";
		return 0L;
	}
	std::vector<HxdwEnumImportsDTO> aImports2;
	bool rs2 = DetourEnumerateImportsEx( hDll, &aImports2,
		hxdw_EnumPEFIDllCalb, hxdw_EnumPEFIFuncCalb );
	if( !rs2 ){
		err3 = "Failed enumerating import modules [rCx6ar]";
		return 0L;
	}
	{
		HMODULE hLastMdl = 0;
		std::string srLastDllName;
		for( auto ir2 = aImports2.begin(); ir2 != aImports2.end(); ++ir2 ){
			if( ir2->hModule ){
				hLastMdl = (HMODULE)ir2->hModule;
			}else if( !ir2->hModule ){
				ir2->hModule = hLastMdl;
			}
			if( ir2->srDllName != "*" ){
				srLastDllName = ir2->srDllName;
			}else if( ir2->srDllName == "*" ){
				ir2->srDllName = srLastDllName;
			}
			//printf("srDllName: [%s], srFuncName: [%s]\n",
			//	ir2->srDllName.c_str(), ir2->srFuncName.c_str() );
		}
	}
	for( auto ir2 = aImports2.begin(); ir2 != aImports2.end(); ){
		if( !ir2->ppvFunc ){
			ir2 = aImports2.erase( ir2 );
		}else{
			++ir2;
		}
	}
	for( auto ir2 = aImports2.begin(); ir2 != aImports2.end(); ++ir2 ){
	/*	printf("srDllName: [%s], nOrdinal: %d, srFuncName: [%s]\n",
			ir2->srDllName.c_str(),
			(int)ir2->nOrdinal,
			ir2->srFuncName.c_str() );
		if( !ir2->srFuncName.empty() && ir2->srFuncName[0] == '*' ){
			fgets( (char*)&errno, 2, stdin );
		}//*/
		if( !calb2( *ir2 ) ){
			break;
		}
	}
	return 1L;
}
