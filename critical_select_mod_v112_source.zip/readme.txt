﻿===================
Critical Select Mod
===================
Author: ike9000
URL: https://www.nexusmods.com/residentevil4/mods/181


This Mod is for Resident Evil 4 Ultimate HD Edition, Steam version.
Compatible with game version 1.1.0 (same as on Steam as of Aug-2022).

This Mod adds options to scale critical damage of selected or all weapons.
For example, it can set critical damage to 2x, 4x, or to any multiplier, including 0x, for Handgun or Broken Butterfly.
This is a game play Mod.

Once installed, use the F5 key in-game.
