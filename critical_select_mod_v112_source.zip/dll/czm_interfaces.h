#pragma once
#include <algorithm>
#include <vector>
#include <inttypes.h>
#include <type_traits>  //std::is_same

struct CzmRE4EnemyData;
enum class CZM_EWT : uint8_t;

// Room Load Type.
enum class CZM_ERLT : int {
	E2_ToMainMenu = 1,
	E2_NewRoom,
};
struct CzmRoomLoadDTO{
	CZM_ERLT eRoomLoadType = CZM_ERLT::E2_NewRoom;
	uint16_t uRoomId = 0;
};
struct CzmTestRun{
	int bTestRun4 = 0;
};
struct CzmDmg2DTO : CzmTestRun {
	CzmRE4EnemyData* pEnmyDtaPtr3 = nullptr;
};
/// Critical damage type.
enum class CZM_ECDT : int {
	CZM_E4_None = 1,
	CZM_E4_Critical,
};
struct CzmDmg3DTO : CzmTestRun {
	CZM_EWT   uWeaponType = (CZM_EWT)0x00;
	uint32_t* pDamgeValue = nullptr;
	CZM_ECDT  eCritDmgType = CZM_ECDT::CZM_E4_None;
};
/// Cutscene type.
enum class CZM_CST: int {
	CZM_E6_TypeAlpha = 0x1,       // eg. r100 in-house cutscene.
	CZM_E6_TypeBeta = 0x2,       // eg. r100 house approach cutscene.
	CZM_E6_TypeGamma = 0x4,       // codex conversations.
	CZM_E6_TypeDelta = 0x8,       // eg. krauser multi-part-cutscene knife fight.
};
// Cutscene skip DTO.
struct CzmCutscSkipDTO : CzmTestRun{
	CZM_CST eCtsType = (CZM_CST)0;
	bool* bSkipCutscene = nullptr;
	CzmCutscSkipDTO() = default;
	CzmCutscSkipDTO( CZM_CST eCtsType_, bool* bSkipCutscene_ );
};

struct CzmHotPatchBase {
	virtual int  notifyEnemyDeath( CzmRE4EnemyData* inp ) {return -1;}
	virtual int  notifyRoomLoad( const CzmRoomLoadDTO& inp ) {return -1;}
	virtual int  notifyDamageAnyEnemy2( const CzmDmg2DTO& inp ) {return -1;}
	virtual int  notifyDamageNormalEnemy( const CzmDmg3DTO& inp ) {return -1;}
	virtual int  notifyCutscenePlay( const CzmCutscSkipDTO& inp ) {return -1;}
	virtual int  notifyNoSkipCutscenePlay( const CzmCutscSkipDTO& inp ) {return -1;}
	bool         pokeIsEnabled( int bSetEnabled = -1 );
	virtual void setAlterableDamageTypes( const std::vector<CZM_EWT>& inp ) {}
	virtual void setCriticalDamageScale( float fCritDmgScale ) {}
	virtual void setDelLagoInstaKO( bool bSet ) {}
	virtual void setCutsceneSkipEnabled( bool bSet ) {}
	virtual void setCutsceneDeltaSkipable( bool bSet ) {}
private:
	bool mEnabled = 0L;
};

template<class Txx, class Uxx>
struct CzmPair{
	static_assert( !std::is_same<Txx,Uxx>::value, "Types must be different." );
	Txx first;
	Uxx second;
	CzmPair( const Txx& first_, const Uxx& second_ ) : first(first_), second(second_) {}
	CzmPair() = default;
	Txx operator*()const {return first;}
	Uxx operator+()const {return second;}
};

/// Gets array size.
template<class Txx> //constexpr
size_t CzmArrSize( Txx& inp )
{
	size_t size_ = sizeof(inp) / sizeof(inp[0]);
	return size_;
}
struct CzmEachHPatchDTO {
	CzmHotPatchBase* hp3 = nullptr;
};
template<class Txx, class Oxx>
Oxx CzmClamp( Txx inp, Txx minval, Txx maxval )
{
	Oxx outp = static_cast<Oxx>(
			std::max<Txx>(
				std::min<Txx>( inp, maxval ), minval ) );
	return outp;
}
