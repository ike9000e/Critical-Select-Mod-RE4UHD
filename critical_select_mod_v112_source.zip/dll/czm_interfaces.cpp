#include "czm_interfaces.h"

bool CzmHotPatchBase::pokeIsEnabled( int bEnable )
{
	if( bEnable != -1 ){
		mEnabled = bEnable;
	}
	return mEnabled;
}
CzmCutscSkipDTO::
CzmCutscSkipDTO( CZM_CST eCtsType_, bool* bSkipCutscene_ )
	: eCtsType(eCtsType_)
	, bSkipCutscene(bSkipCutscene_)
{
}
