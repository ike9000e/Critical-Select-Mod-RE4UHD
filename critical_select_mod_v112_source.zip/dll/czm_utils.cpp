#include "czm_utils.h"
#include <windows.h>
#include <memory>
#include <array>
#include <assert.h>
#include <xinput.h>   //XInputGetState()
#include "Minhook.h"
#include "imgui.h"
#include "detours.h"
#include "hxdw_utils.h"
#include "hxdw_process.h"
#include "hxdw_detours_misc.h"
#include "czm_md5.h"

BOOL __stdcall czm_PeekMessageW( MSG* msg, HWND hw2, UINT wMsgFilterMin, UINT wMsgFilterMax, UINT wRemoveMsg );
BOOL __stdcall czm_PeekMessageA( MSG* msg, HWND hw2, UINT wMsgFilterMin, UINT wMsgFilterMax, UINT wRemoveMsg );
uint32_t czm_XinputDetoursInit();
uint32_t czm_XinputDetoursDeinit();
DWORD WINAPI czm_XInputGetState( DWORD dwUserIndex, XINPUT_STATE* pStateOut );
void czm_EachHotPatch2( std::function< void(const CzmEachHPatchDTO&)> calb2 );

const
std::vector<std::pair<int,int> > CzmData::aUIButtonMap = {
	{ XINPUT_GAMEPAD_DPAD_DOWN, ImGuiKey_DownArrow,},
	{ XINPUT_GAMEPAD_DPAD_UP, ImGuiKey_UpArrow,},
	{ XINPUT_GAMEPAD_DPAD_LEFT, ImGuiKey_LeftArrow,},
	{ XINPUT_GAMEPAD_DPAD_RIGHT, ImGuiKey_RightArrow,},
	{ XINPUT_GAMEPAD_LEFT_SHOULDER, ImGuiKey_ModCtrl,},
	{ XINPUT_GAMEPAD_A, ImGuiKey_Space,},
	{ XINPUT_GAMEPAD_BACK, ImGuiKey_Escape,},
	{ XINPUT_GAMEPAD_X, ImGuiKey_Tab,},
	{ XINPUT_GAMEPAD_Y, ImGuiKey_Enter,},
	{ XINPUT_GAMEPAD_LEFT_THUMB, ImGuiKey_PageUp,},
	{ XINPUT_GAMEPAD_RIGHT_THUMB, ImGuiKey_PageDown,},
};
const int16_t CzmData::nUIButtonMask = ( XINPUT_GAMEPAD_RIGHT_SHOULDER | XINPUT_GAMEPAD_START );
const int16_t CzmData::nUICloseButtons = ( XINPUT_GAMEPAD_START | XINPUT_GAMEPAD_B );
const uint32_t CzmData::uUIButtonIntervalMs = 333;
const size_t CzmData::nMaxLogItems = 128;

bool czm_Print2( const char* fmt, const std::vector<HxdwPrintAdp> args4 )
{
	std::string sr3 = hxdw_StrPrintf( fmt, args4 );
	return hxdw_StdPrint2( sr3.c_str() );
}
bool czm_AnySystemModkeyDown()
{
	static const std::array<int,5> ar2 = { VK_SHIFT,VK_CONTROL,VK_MENU,VK_LWIN,VK_RWIN,};
	for( auto ir2 = ar2.begin(); ir2 != ar2.end(); ++ir2 ){
		if( 0x8000 & GetAsyncKeyState( *ir2 ) ){
			return 1;
		}
	}
	return 0;
}
uint32_t czm_Win32DetoursInit()
{
	HMODULE hUser32Dll = 0;
	hxdw_EnumerateProcessModules( 0, [&]( const HxdwModOnEnum& inp )->bool{
			auto bn2 = hxdw_SplitPath( inp.srPath ).second;
			assert( !bn2.empty() );
			if( !hxdw_StrCmpOpt( bn2.c_str(), "user32.dll", -1, "i" ) ){
				hUser32Dll = (HMODULE)inp.hDll;
				return 0L;
			}
			return 1L;
		});
	assert( hUser32Dll );
	{
		//
		// NOTE: MinHook fails to detour a function that is already detoured.
		//       MS Detours library detours that function correctly, instead.
		//
		Czm->fnOgPeekMessageA = GetProcAddress( hUser32Dll, "PeekMessageA");
		assert( Czm->fnOgPeekMessageA );
		Czm->fnOgPeekMessageW = GetProcAddress( hUser32Dll, "PeekMessageW");
		assert( Czm->fnOgPeekMessageW );
		//
		DetourTransactionBegin();
		DetourUpdateThread( GetCurrentThread() );
		std::shared_ptr<void*> raii4( nullptr, [&]( void* ){
			DetourTransactionCommit();
		});
		Czm->bKeyboardNavError = 1L;
		LONG rs2 = DetourAttach( &Czm->fnOgPeekMessageA, czm_PeekMessageA );
		if( rs2 ){   //NO_ERROR=0; ERROR_INVALID_BLOCK
			std::string msg = hxdw_DetoursErrorToString( rs2 );
			czm_Print2("CZM: ERROR: Detouring PeekMessageA failed. Code:[%d:%s] [qYijfM]\n", { (int)rs2, msg,} );
		}else{
			rs2 = DetourAttach( &Czm->fnOgPeekMessageW, czm_PeekMessageW );
			if( rs2 ){
				std::string msg = hxdw_DetoursErrorToString( rs2 );
				czm_Print2("CZM: ERROR: Detouring PeekMessageW failed. Code:[%d:%s] [XAjpoj]\n", { (int)rs2, msg,} );
			}else{
				Czm->bKeyboardNavError = 0L; //mark no-error.
			}
		}
		//DWORD dwOldProt = 0;
		//bool rs2 = !!VirtualProtect( pPkMsgFunc, 16, PAGE_EXECUTE_READWRITE, &dwOldProt );
		//assert(rs2);
	}
	uint32_t rs2 = czm_XinputDetoursInit();
	assert( !rs2 );

	return 0;
}

uint32_t czm_XinputDetoursInit()
{
	const char* aXinputDllNames[] = {   //taken from ImGui
		"xinput1_4.dll",   // Windows 8+
		"xinput1_3.dll",   // DirectX SDK
		"xinput9_1_0.dll", // Windows Vista, Windows 7
		"xinput1_2.dll",   // DirectX SDK
		"xinput1_1.dll",   // DirectX SDK
	};
	assert( Czm );
	assert( !Czm->hXInputDll );
	hxdw_EnumerateProcessModules( 0, [&](const HxdwModOnEnum& in2)->bool{
		for( size_t ii2=0; ii2 < CzmArrSize(aXinputDllNames); ii2++ ){
			auto bn2 = hxdw_SplitPath( in2.srPath ).second;
			assert( !bn2.empty() );
			if( !hxdw_StrCmpOpt( bn2.c_str(), aXinputDllNames[ii2], -1, "i" ) ){
				assert( in2.hDll );
				Czm->hXInputDll = in2.hDll;
				return 0L;
			}
		}
		return 1L;
	});
	czm_Print2("CZM: XInput Enabled: [%a]\n", { std::string( Czm->hXInputDll ? "Yes": "No"),} );
	if( Czm->hXInputDll ){
		Czm->fnOgXInputGetState = GetProcAddress( (HMODULE)Czm->hXInputDll, "XInputGetState");
		assert( Czm->fnOgXInputGetState );
		DetourTransactionBegin();
		DetourUpdateThread( GetCurrentThread() );
		std::shared_ptr<void*> raii4( nullptr, [&]( void* ){
			DetourTransactionCommit();
		});
		LONG rs2 = DetourAttach( &Czm->fnOgXInputGetState, czm_XInputGetState );
		if( rs2 ){   //NO_ERROR=0
			std::string msg = hxdw_DetoursErrorToString( rs2 );
			czm_Print2("CZM: ERROR: Detouring XInputGetState failed. Code:[%d:%s] [d9WSSU]\n", { (int)rs2, msg,} );
			Czm->bGamepadNavError = 1L;
		}
	}
	return 0;
}

uint32_t czm_Win32DetoursDeinit()   //czm_Win32DetoursInit()
{
	czm_XinputDetoursDeinit();
	{
		//MH_DisableHook( czm_PeekMessageW );
		//MH_DisableHook( czm_PeekMessageA );
		DetourTransactionBegin();
		DetourUpdateThread( GetCurrentThread() );
		DetourDetach( &Czm->fnOgPeekMessageW, czm_PeekMessageW );
		DetourDetach( &Czm->fnOgPeekMessageA, czm_PeekMessageA );
		DetourTransactionCommit();
	}
	return 0;
}
uint32_t czm_XinputDetoursDeinit()   //czm_XinputDetoursInit()
{
	assert( Czm );
	if( Czm->hXInputDll && Czm->fnOgXInputGetState ){
		DetourTransactionBegin();
		DetourUpdateThread( GetCurrentThread() );
		DetourDetach( &Czm->fnOgXInputGetState, czm_XInputGetState );
		DetourTransactionCommit();
	}
	return 0;
}




// IMGUI_IMPL_WIN32_DISABLE_GAMEPAD
/*
	struct XINPUT_GAMEPAD{
		WORD  wButtons;
		BYTE  bLeftTrigger;
		BYTE  bRightTrigger;
		SHORT sThumbLX;
		SHORT sThumbLY;
		SHORT sThumbRX;
		SHORT sThumbRY;
	};
	XINPUT_GAMEPAD::wButtons:
		XINPUT_GAMEPAD_DPAD_UP 	0x0001
		XINPUT_GAMEPAD_DPAD_DOWN 	0x0002
		XINPUT_GAMEPAD_DPAD_LEFT 	0x0004
		XINPUT_GAMEPAD_DPAD_RIGHT 	0x0008
		XINPUT_GAMEPAD_START 	0x0010
		XINPUT_GAMEPAD_BACK 	0x0020
		XINPUT_GAMEPAD_LEFT_THUMB 	0x0040
		XINPUT_GAMEPAD_RIGHT_THUMB 	0x0080
		XINPUT_GAMEPAD_LEFT_SHOULDER 	0x0100
		XINPUT_GAMEPAD_RIGHT_SHOULDER 	0x0200
		XINPUT_GAMEPAD_A 	0x1000
		XINPUT_GAMEPAD_B 	0x2000
		XINPUT_GAMEPAD_X 	0x4000
		XINPUT_GAMEPAD_Y 	0x8000
//*/
void czm_ProcessUIKey( uint16_t nXInputButtons )
{
	assert( Czm );
	ImGuiIO& io3 = ImGui::GetIO();
	const auto& ls2 = CzmData::aUIButtonMap;
	for( auto ir2 = ls2.begin(); ir2 != ls2.end(); ++ir2 ){
		if( nXInputButtons & ir2->first ){
			if( !(Czm->nXInputButtons2 & ir2->first) ){
				io3.AddKeyEvent( ir2->second, 1L );
				Czm->nXInputButtons2 |= ir2->first;
			}
		}else{
			if( Czm->nXInputButtons2 & ir2->first ){
				io3.AddKeyEvent( ir2->second, 0L );
				Czm->nXInputButtons2 &= ~ir2->first;
			}
		}
	}
	if( Czm->bUIOpened && Czm->bFocusNeedleOn ){
		// seecret LB+B
		bool cond2 = (
			(nXInputButtons & (
			XINPUT_GAMEPAD_LEFT_THUMB|XINPUT_GAMEPAD_B)));
		if( !cond2 ){
			cond2 = ( (0x8000 & GetAsyncKeyState('B') &&
				0x8000 & GetAsyncKeyState(VK_CONTROL)) );
		}
		if( cond2 ){
			Czm->bGBossesTabOn = 1L;
		}
		const bool cond3 = (
			nXInputButtons & (
			XINPUT_GAMEPAD_LEFT_THUMB|XINPUT_GAMEPAD_Y));
		if( cond3 ){
			Czm->bGBossesTabOn = 0L;
		}
	}
}
//XInputGetState
DWORD WINAPI czm_XInputGetState( DWORD dwUserIndex, XINPUT_STATE* pStateOut )
{
	assert( Czm );
	assert( Czm->fnOgXInputGetState );
	using fn_t = decltype(czm_XInputGetState)*;
	DWORD retv = ((fn_t)Czm->fnOgXInputGetState)( dwUserIndex, pStateOut );
	if( retv == ERROR_SUCCESS ){
		const WORD bt2 = pStateOut->Gamepad.wButtons;
		const int16_t msk2 = CzmData::nUIButtonMask;
		bool bActv = ( (bt2 & msk2) == msk2 && !(bt2 & (~msk2)) );
		std::shared_ptr<int> raii2( nullptr, [&]( int* ){
			Czm->bUIButtonHeld = bActv;
		});
		if( bActv ){
			pStateOut->Gamepad.wButtons &= ~msk2;
			uint32_t uNow = (uint32_t) hxdw_GetTimeTicksMs();
			if( uNow > Czm->uUIButtonTimePos + CzmData::uUIButtonIntervalMs || !Czm->bUIButtonHeld ){
				Czm->bUIOpened = !Czm->bUIOpened;
				Czm->uUIButtonTimePos = uNow;
			}
		}
		if( Czm->bUIOpened ){
			std::shared_ptr<int> raii3( nullptr, [&]( void* ){
				memset( &pStateOut->Gamepad, 0, sizeof(pStateOut->Gamepad) );
			});
			czm_ProcessUIKey( pStateOut->Gamepad.wButtons );
			{
				const bool cond3 = (
					pStateOut->Gamepad.wButtons & CzmData::nUICloseButtons &&
					!(pStateOut->Gamepad.wButtons & ~CzmData::nUICloseButtons));
				if( cond3 ){
					Czm->bUIOpened = 0L;
					Czm->uUIButtonTimePos = (uint32_t) hxdw_GetTimeTicksMs();
					Czm->bClosingUI = 1L;
				}
			}
		}
		if( Czm->bClosingUI ){
			uint32_t uNow = (uint32_t) hxdw_GetTimeTicksMs();
			if( uNow < Czm->uUIButtonTimePos + CzmData::uUIButtonIntervalMs ){
				pStateOut->Gamepad.wButtons &= ~CzmData::nUICloseButtons;
			}else{
				Czm->bClosingUI = 0L;
			}
		}
	}
	return retv;
}
void CzmData::addLog3( const char* fmt, const std::vector<HxdwPrintAdp> args4 )
{
	std::string sr3 = hxdw_StrPrintf( fmt, args4 );
	for(; aLogText.size() > CzmData::nMaxLogItems ;){
		aLogText.erase( aLogText.begin() );
	}
	aLogText.push_back( CzmLogItem{ sr3,} );
}

CzmPair<const char*,size_t>
CzmData::getLogText2( int nIndex_ )const
{
	if( nIndex_ == -1 ){
		return CzmPair<const char*,size_t>("", aLogText.size() );
	}
	size_t nIndex = (size_t)nIndex_;
	assert( nIndex < aLogText.size() );
	const CzmLogItem* itm2 = &aLogText[nIndex];
	CzmPair<const char*,size_t> outp(
			itm2->srText2.c_str(), aLogText.size() );
	return outp;
}
void CzmData::clearLogText2()
{
	aLogText.clear();
	aLogItemTrack = {0,0,};
}
CzmWndGeomMgr::CzmWndGeomMgr( std::array<float,4> aDflt )
	: aFXywh( aDflt )
{
}
std::string CzmWndGeomMgr::serialize2()const
{
	char bfr2[256];
	std::snprintf( bfr2, sizeof(bfr2),
			"%d,%d,%d,%d,%f,%f,%f,%f",
			aNXywh[0], aNXywh[1],
			aNXywh[2], aNXywh[3],
			aFXywh[0], aFXywh[1],
			aFXywh[2], aFXywh[3]);
	return bfr2;
}
void CzmWndGeomMgr::deserialize2( const char* inp )
{
	{
		const char* sz2 = inp;
		size_t num = 0;
		for(; (sz2 = std::strchr(sz2,',')); sz2 += 1, num += 1 ){}
		assert( (num == 7 || num == 8) && "Number of commas in the input string missmatch [SqPR0n]" );
	}
	std::sscanf( inp, "%d,%d,%d,%d,%f,%f,%f,%f",
		&aNXywh[0], &aNXywh[1],
		&aNXywh[2], &aNXywh[3],
		&aFXywh[0], &aFXywh[1],
		&aFXywh[2], &aFXywh[3]);
}
std::array<int,4> CzmWndGeomMgr::getWindowGeometry()
{
	ImVec2 xy2 = ImGui::GetWindowPos();
	ImVec2 wh2 = ImGui::GetWindowSize();
	std::array<int,4> outp = {
		int(xy2.x), int(xy2.y),
		int(wh2.x), int(wh2.y),};
	return outp;
}
std::array<float,4> CzmWndGeomMgr::getWindowFGeometry()
{
	const auto gmtr2 = getWindowGeometry();
	const ImVec2 dmn4 = ImGui::GetMainViewport()->WorkSize;
	std::array<float,4> out2 = {
		gmtr2[0] / dmn4.x, gmtr2[1] / dmn4.y,
		gmtr2[2] / dmn4.x, gmtr2[3] / dmn4.y,};
	return out2;
}
void CzmWndGeomMgr::updateOnWindowBegin()
{
	if( bNeedGmtryUpdate ){
		ImVec2 xyPos = ImVec2( (float)aNXywh[0], (float)aNXywh[1] );
		ImVec2 whSize = ImVec2( (float)aNXywh[2], (float)aNXywh[3] );
		ImGui::SetWindowPos( xyPos );
		ImGui::SetWindowSize( whSize );
		bNeedGmtryUpdate = 0L;
	}
}
void CzmWndGeomMgr::updateOnWindowEnd()
{
	if( ImGui::IsMouseDown( ImGuiMouseButton_Left ) ){
		aNXywh = getWindowGeometry();
	}
}
void CzmWndGeomMgr::onRezChange( std::array<int,2> aOldRez, std::array<int,2> aNewRez )
{
	std::array<float,4> fracs2 = aFXywh;
	if( aOldRez[0] && aOldRez[1] ){
		fracs2 = {
			float( double(aNXywh[0]) / aOldRez[0] ),
			float( double(aNXywh[1]) / aOldRez[1] ),
			float( double(aNXywh[2]) / aOldRez[0] ),
			float( double(aNXywh[3]) / aOldRez[1] ),
		};
	}
	aNXywh = {
		int( fracs2[0] * aNewRez[0] ),
		int( fracs2[1] * aNewRez[1] ),
		int( fracs2[2] * aNewRez[0] ),
		int( fracs2[3] * aNewRez[1] ),
	};
	bNeedGmtryUpdate = 1L;
}

const std::vector< std::tuple<CZM_EWT,std::string,std::string> > CzmWeaponNames = {
	{CZM_EWT::CZM_E3_Punisher,"CZM_E3_Punisher","Punisher",},
	{CZM_EWT::CZM_E3_Handgun,"CZM_E3_Handgun","Handgun",},
	{CZM_EWT::CZM_E3_Red9,"CZM_E3_Red9","Red9",},
	{CZM_EWT::CZM_E3_Blacktail,"CZM_E3_Blacktail","Blacktail",},
	{CZM_EWT::CZM_E3_Matilda,"CZM_E3_Matilda","Matilda",},
	{CZM_EWT::CZM_E3_TMP,"CZM_E3_TMP","T.M.P.",},
	{CZM_EWT::CZM_E3_Kick,"CZM_E3_Kick","Kick",},
	{CZM_EWT::CZM_E3_Knife,"CZM_E3_Knife","Knife",},
	{CZM_EWT::CZM_E3_ChicagoTypewriter,"CZM_E3_ChicagoTypewriter","ChicagoTypewriter",},
	{CZM_EWT::CZM_E3_RocketLauncher,"CZM_E3_RocketLauncher","RocketLauncher",},
	{CZM_EWT::CZM_E3_RiffleSemiauto,"CZM_E3_RiffleSemiauto","RiffleSemiauto",},
	{CZM_EWT::CZM_E3_HuntingRiffle,"CZM_E3_HuntingRiffle","HuntingRiffle",},
	{CZM_EWT::CZM_E3_BrokenButterfly,"CZM_E3_BrokenButterfly","BrokenButterfly",},
	{CZM_EWT::CZM_E3_Killer7,"CZM_E3_Killer7","Killer7",},
	{CZM_EWT::CZM_E3_Handcannon,"CZM_E3_Handcannon","Handcannon",},
	{CZM_EWT::CZM_E3_MineThrower,"CZM_E3_MineThrower","MineThrower",},
	{CZM_EWT::CZM_E3_Shotgun,"CZM_E3_Shotgun","Shotgun",},
	{CZM_EWT::CZM_E3_Striker,"CZM_E3_Striker","Striker",},
	{CZM_EWT::CZM_E3_RiotGun,"CZM_E3_RiotGun","RiotGun",},
	{CZM_EWT::CZM_E3_Explosion,"CZM_E3_Explosion","Explosion",},
	{CZM_EWT::CZM_E3_FlashGrenade,"CZM_E3_FlashGrenade","FlashGrenade",},
};
std::string czm_GetWeaponTypeName2( CZM_EWT eWeaponType, bool bGetAsEnum )
{
	for( auto ir2 = CzmWeaponNames.begin(); ir2 != CzmWeaponNames.end(); ++ir2 ){
		if( eWeaponType == std::get<0>( *ir2 ) ){
			return (bGetAsEnum ? std::get<1>( *ir2 ) : std::get<2>( *ir2 ));
		}
	}
	return "<unknown_7GHrlY>";
}
CzmPair<bool,CZM_EWT>
czm_GetWeaponTypeByIndex( size_t index2 )
{
	if( index2 < CzmWeaponNames.size() ){
		CZM_EWT eWeaponType = std::get<0>( CzmWeaponNames[index2] );
		return { 1L, eWeaponType,};
	}
	return { 0L, CZM_EWT::CZM_E3_Punisher,};  // not found, unknown
}
size_t czm_GetWeaponTypeCount()
{
	return CzmWeaponNames.size();
}

std::vector< CzmPair<CZM_EWGR,std::vector<CZM_EWT> > >
CzmWeaponGroups = {
	{ CZM_EWGR::CZM_E5_Pistols, {
		CZM_EWT::CZM_E3_Punisher,
		CZM_EWT::CZM_E3_Handgun,
		CZM_EWT::CZM_E3_Red9,
		CZM_EWT::CZM_E3_Blacktail,
		CZM_EWT::CZM_E3_Matilda,
		},},
	{ CZM_EWGR::CZM_E5_Shotguns, {
		CZM_EWT::CZM_E3_Shotgun,
		CZM_EWT::CZM_E3_Striker,
		CZM_EWT::CZM_E3_RiotGun,
	},},
	{ CZM_EWGR::CZM_E5_Rifles, {
		CZM_EWT::CZM_E3_RiffleSemiauto,
		CZM_EWT::CZM_E3_HuntingRiffle,
	},},
	{ CZM_EWGR::CZM_E5_Magnums, {
		CZM_EWT::CZM_E3_BrokenButterfly,
		CZM_EWT::CZM_E3_Killer7,
		CZM_EWT::CZM_E3_Handcannon,
		CZM_EWT::CZM_E3_MineThrower,
	},},
	{ CZM_EWGR::CZM_E5_Mele, {
		CZM_EWT::CZM_E3_Kick,
		CZM_EWT::CZM_E3_Knife,
		},},
	{ CZM_EWGR::CZM_E5_Explosives, {
		CZM_EWT::CZM_E3_Explosion,
		CZM_EWT::CZM_E3_FlashGrenade,
		CZM_EWT::CZM_E3_RocketLauncher,
		},},
	{ CZM_EWGR::CZM_E5_CheatWeapons, {
		CZM_EWT::CZM_E3_Handcannon,
		CZM_EWT::CZM_E3_ChicagoTypewriter,
		},},

};

std::vector<CZM_EWT>
czm_GetWeaponGroupTypeWeapons( CZM_EWGR eWpnGrTy )
{
	std::vector<CZM_EWT> outp;
	auto ir2 = CzmWeaponGroups.begin();
	for( ; ir2 != CzmWeaponGroups.end(); ++ir2 ){
		if( **ir2 == eWpnGrTy ){
			outp = ir2->second;
			break;
		}
	}
	return outp;
}
std::vector<CZM_EWT>
czm_ConvWeaponTypeIndexesToTypes( const std::vector<int>& aIndexes )
{
	std::vector<CZM_EWT> outp;
	size_t idx = 0;
	for( auto flg : aIndexes ){
		if(flg){
			auto rs2 = czm_GetWeaponTypeByIndex( idx );
			assert( *rs2 );
			outp.push_back( +rs2 );
		}
		idx++;
	}
	return outp;
}
void czm_SetupUIElements()
{
	{
		//bool show_demo_window = 1;
		//ImGui::ShowDemoWindow(&show_demo_window);
	}
	if( Czm->bShowStartupTip ){
		const uint32_t uNow2 = (uint32_t) hxdw_GetTimeTicksMs();
		Czm->uStartupTipOpenedAtMs = ( Czm->uStartupTipOpenedAtMs ? Czm->uStartupTipOpenedAtMs : uNow2 );
		const uint32_t nEndsAt = (Czm->uStartupTipOpenedAtMs + Czm->uStartupTipDurationMs);
		if( uNow2 < nEndsAt ){
			double pos2 = (double(nEndsAt-uNow2) / Czm->uStartupTipDurationMs);
			const int flags3 = ( ImGuiWindowFlags_NoCollapse |
				ImGuiWindowFlags_NoTitleBar |
				ImGuiWindowFlags_NoScrollbar |
				ImGuiWindowFlags_NoResize );
			ImGui::SetNextWindowBgAlpha( 1.0f ); //1.0f: fully opaque.
			ImGui::Begin( Czm->szAppName, nullptr, flags3 );
			ImGui::Text("%s : Press", Czm->szAppName );
			ImGui::SameLine();
			ImGui::TextColored( {1,1,0,1,},"F5");
			ImGui::SameLine();
			ImGui::Text("or");
			ImGui::SameLine();
			ImGui::TextColored( {1,1,0,1,},"RIGHT_SHOULDER+START");
			ImGui::SameLine();
			ImGui::Text("to open the setup window.");
			if( Czm->bKeyboardNavError ){
				ImGui::TextColored( {1,0,1,1,},"WARNING: No keyboard navigation.");
			}
			if( Czm->bGamepadNavError ){
				ImGui::TextColored( {1,0,1,1,},"WARNING: No gamepad navigation.");
			}
			ImGui::PushItemWidth( ImGui::GetWindowSize().x );
			ImGui::ProgressBar( float(pos2), {0.f, 1.f,} );
			ImGui::PopItemWidth();

			ImGui::End();
		}else{
			Czm->bShowStartupTip = 0L;
		}
	}
	if( Czm->bShowLogWindow ){
		int flags2 = ( ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoTitleBar );
		if( !Czm->bUIOpened ){
			ImGui::SetNextWindowBgAlpha( 0.3f );  //1.0f: fully opaque.
			flags2 |= ImGuiWindowFlags_NoScrollbar;
			flags2 |= ImGuiWindowFlags_NoResize;
		}
		char bfrA[128];
		snprintf( bfrA, sizeof(bfrA), "<<< Log Window - %s >>>", Czm->szAppName );
		ImGui::Begin( bfrA, nullptr, flags2 );
		Czm->cLogWndGmtr.updateOnWindowBegin();
		if( Czm->bUIOpened ){
			ImGui::Text( bfrA );
			if( ImGui::Button("Clear") ){
				Czm->clearLogText2();
			}
			ImGui::SameLine();
			ImGui::Checkbox("Auto scroll", &Czm->bLogAutoScroll );
		}
		for( size_t ii2 = 0; ii2 < +Czm->getLogText2(); ii2++ ){
			ImGui::Text( *Czm->getLogText2(ii2) );
		}
		{
			if( Czm->bLogAutoScroll && *Czm->aLogItemTrack < +Czm->getLogText2() ){
				Czm->aLogItemTrack.first = +Czm->getLogText2();
				Czm->aLogItemTrack.second = 2;
			}
			if( Czm->aLogItemTrack.second ){
				--Czm->aLogItemTrack.second;
				ImGui::SetScrollY( ImGui::GetScrollMaxY() );
			}
		}
		Czm->cLogWndGmtr.updateOnWindowEnd();
		ImGui::End();
	}
	if( Czm->bUIOpened ){
		std::string srWndName = std::string("Settings - ") + Czm->szAppName;
		ImGui::Begin( srWndName.c_str(), nullptr, ImGuiWindowFlags_NoCollapse );
		Czm->cSettingsWndGmtr.updateOnWindowBegin();
		{
			// ImGuiTabBarFlags, ImGuiTabItemFlags
			ImGui::BeginTabBar("tabs_4XxF16", ImGuiTabBarFlags_FittingPolicyScroll );
			if( ImGui::BeginTabItem("Crit Options", nullptr, 0x0 ) ){
				static float fDmgSc = 1.f;
				static bool bEnable2 = 0;
				bool bOldEnable2 = bEnable2;
				ImGui::Checkbox("Enable Critical Damage Scaling", &bEnable2 );
				if( !bEnable2 ){
					ImGui::BeginDisabled();
				}
				float fOldDmgSc = fDmgSc;
				if( bOldEnable2 != bEnable2 ){
					fOldDmgSc = fDmgSc - 1.f;
				}
				ImGui::InputFloat("Crit. Scale", &fDmgSc, 0.1f, 0.5f, "%f", 0x0 );
				if( ImGui::Button("Reset") ){
					fDmgSc = 1.f;
				}
				ImGui::SameLine();
				if( ImGui::Button("Zero") ){
					fDmgSc = 0.f;
				}
				if( fOldDmgSc != fDmgSc ){
					czm_EachHotPatch2( [&]( const CzmEachHPatchDTO& in2){
						//czm_Print2("CZM: f changed 2 ----- %a ---\n", { std::to_string(fDmgSc),});
						in2.hp3->setCriticalDamageScale( bEnable2 ? fDmgSc : 1.f );
					} );
				}
				ImGui::Text("");

				czm_CreateWeaponTypeUIItems();

				if( !bEnable2 ){
					ImGui::EndDisabled();
				}
				ImGui::EndTabItem();
			}
			if( ImGui::BeginTabItem("Skips", nullptr, 0x0 ) ){
				{
					{
						static bool bCutscSkip2 = 0L;
						bool bOldCutscSkip2 = bCutscSkip2;
						ImGui::Checkbox("Cutscene Skip", &bCutscSkip2 );
						if( bOldCutscSkip2 != bCutscSkip2 ){
							czm_EachHotPatch2( [&]( const CzmEachHPatchDTO& in2){
								in2.hp3->setCutsceneSkipEnabled( bCutscSkip2 );
							});
						}
						Czm->bFocusNeedleOn = ImGui::IsItemFocused(); //bGBossesTabOn
						ImGui::SameLine();
						static bool bCsSkpTooltip = 0L;
						if( ImGui::SmallButton("?##6JaESm") ){
							bCsSkpTooltip = !bCsSkpTooltip;
						}
						if( bCsSkpTooltip ){
							ImGui::Text("May cause crashes.");
						}
					}{
						static bool bDeltaCutscSkip = 0L;
						bool bOldDeltaCutscSkip = bDeltaCutscSkip;
						ImGui::Checkbox("Make Krauser knife fight cutscenes skipable", &bDeltaCutscSkip );
						if( bOldDeltaCutscSkip != bDeltaCutscSkip ){
							czm_EachHotPatch2( [&]( const CzmEachHPatchDTO& in2){
								in2.hp3->setCutsceneDeltaSkipable( bDeltaCutscSkip );
							});
						}
					}
				}
				if( Czm->bGBossesTabOn ){
					static bool bDelLagoKO = 0L;
					bool bOldDelLagoKO = bDelLagoKO;
					ImGui::Checkbox("Del Lago insta KO", &bDelLagoKO );
					if( bOldDelLagoKO != bDelLagoKO ){
						czm_EachHotPatch2( [&]( const CzmEachHPatchDTO& in2){
							in2.hp3->setDelLagoInstaKO( bDelLagoKO );
						});
					}
				}
				ImGui::EndTabItem();
			}
			if( ImGui::BeginTabItem("UI Setup", nullptr, 0x0 ) ){
				int nRqScale = 0;
				nRqScale -= !!ImGui::Button("Scale -");
				ImGui::SameLine();
				nRqScale += !!ImGui::Button("Scale +");
				if( nRqScale ){
					Czm->fUIScale2 *= ( nRqScale > 0 ? 1.1f : 1.0f/1.1f );
					ImGuiIO& io2 = ImGui::GetIO();
					io2.FontGlobalScale = Czm->fUIScale2;
				}
				ImGui::SameLine();
				if( ImGui::Button("Reset") ){
					ImGui::GetIO().FontGlobalScale = Czm->fUIScale2 = 1.0f;
				}
				ImGui::Checkbox("Show Log Window", &Czm->bShowLogWindow );
				ImGui::EndTabItem();
			}
			if( ImGui::BeginTabItem("About", nullptr, 0x0 ) ){
				if( Czm->srVersionCalc.empty() ){
					Czm->srVersionCalc = czm_CalcProgramVersion();
				}
				ImGui::Indent( ImGui::GetWindowSize().x * 0.05f );
				ImGui::Text("");
				std::string srNameText;
				srNameText = hxdw_StrPrintf("\n\x20\x20%a\x20\x20\n\x20",
					{ std::string(Czm->szAppName),});
				ImGui::Button( srNameText.c_str() );
				ImGui::Text("");
				ImGui::Text("Version: %s", Czm->srVersionCalc.c_str() );
				ImGui::Text("");
				ImGui::Text("Web page: %s", CZM_APP_URL );
				//ImGui::Button("");
				ImGui::Unindent();
				ImGui::EndTabItem();
			}
			ImGui::EndTabBar();
		}
		Czm->cSettingsWndGmtr.updateOnWindowEnd();
		ImGui::End();
	}
}
void czm_CreateWeaponTypeUIItems()
{
	assert( Czm );
	auto aOldWpnCheckFlags = Czm->aWpnCheckFlags;

	static_assert( sizeof(int) >= sizeof(bool), "");
	Czm->aWpnCheckFlags.resize( czm_GetWeaponTypeCount(), 0L );

	auto lmbCheckByWpnGrTy = [&]( CZM_EWGR eWGrTy )->void{
		auto guns2 = czm_GetWeaponGroupTypeWeapons( eWGrTy );
		bool bShiftDown = ImGui::GetIO().KeyShift;
		size_t ii3 = 0;
		for( auto& flg : Czm->aWpnCheckFlags ){
			auto rs3 = czm_GetWeaponTypeByIndex( ii3 );
			bool flg2 = std::any_of( guns2.begin(), guns2.end(),
					[&rs3]( CZM_EWT a )->bool{
						return +rs3 == a;
					});
			flg = ( bShiftDown && flg ? flg : flg2 );
			ii3++;
		}
	};
	const int nNumCols = 3;
	bool rs2 = ImGui::BeginTable("table_hNaOSq", nNumCols, 0u);
	if( rs2 ){
		//ImGui::TableSetupColumn("B0");
		//ImGui::TableSetupColumn("B1");
		//ImGui::TableSetupColumn("B3");
		//ImGui::TableHeadersRow();
		{
			size_t ii2;
			for( ii2 = 0; 1; ii2++ ){
				auto rs3 = czm_GetWeaponTypeByIndex( ii2 );
				if( !*rs3 )
					break;
				if( !( ii2 % nNumCols ) ){
					ImGui::TableNextRow( 0u, 4);
				}
				ImGui::TableNextColumn();
				std::string sr2 = czm_GetWeaponTypeName2( +rs3, 0L );
				//static bool bb2 = 0;

				assert( ii2 < Czm->aWpnCheckFlags.size() );
				bool* ptr = (bool*) &Czm->aWpnCheckFlags[ii2];
				ImGui::Checkbox( sr2.c_str(), ptr );
			}
			assert( ii2 == czm_GetWeaponTypeCount() );
		}
		ImGui::EndTable();
		//
		if( ImGui::Button("Clear Selection") ){
			for( auto& a : Czm->aWpnCheckFlags )
				a = 0L;
		}
		ImGui::SameLine();
		if( ImGui::Button("Invert Selection") ){
			for( auto& a : Czm->aWpnCheckFlags )
				a = !a;
		}
		// ImGui::SameLine()
		if( ImGui::Button("Select Pistols") ){
			lmbCheckByWpnGrTy( CZM_EWGR::CZM_E5_Pistols );
		}
		ImGui::SameLine();
		if( ImGui::Button("Select Shotguns") ){
			lmbCheckByWpnGrTy( CZM_EWGR::CZM_E5_Shotguns );
		}
		ImGui::SameLine();
		if( ImGui::Button("Select Rifles") ){
			lmbCheckByWpnGrTy( CZM_EWGR::CZM_E5_Rifles );
		}
		// ImGui::SameLine()
		if( ImGui::Button("Select Magnums") ){
			lmbCheckByWpnGrTy( CZM_EWGR::CZM_E5_Magnums );
		}
		ImGui::SameLine();
		if( ImGui::Button("Select Mele") ){
			lmbCheckByWpnGrTy( CZM_EWGR::CZM_E5_Mele );
		}
		ImGui::SameLine();
		if( ImGui::Button("Select Explosives") ){
			lmbCheckByWpnGrTy( CZM_EWGR::CZM_E5_Explosives );
		}
		// ImGui::SameLine()
		if( ImGui::Button("Select Cheat Weapons") ){
			lmbCheckByWpnGrTy( CZM_EWGR::CZM_E5_CheatWeapons );
		}
		//
		if( aOldWpnCheckFlags != Czm->aWpnCheckFlags ){
			auto ls2 = czm_ConvWeaponTypeIndexesToTypes( Czm->aWpnCheckFlags );
			czm_EachHotPatch2( [&]( const CzmEachHPatchDTO& in2){
				//czm_Print2( "CZM: setting dmg types. n:%a\n", {
				//		(int)ls2.size(),} );
				in2.hp3->setAlterableDamageTypes( ls2 );
			} );
		}
	}
}
void czm_UpdateFromConfigFile()
{
	assert( Czm );
	Czm->srSelfFullPath = hxdw_GetModuleFileNameFromAddr( czm_UpdateFromConfigFile );
	Czm->srSelfDir      = hxdw_SplitPath( Czm->srSelfFullPath ).first;
	Czm->srSelfBaseName = hxdw_SplitPath( Czm->srSelfFullPath ).second;
	Czm->srSelfIniPath  = hxdw_StrPrintf("%a\\%a.ini", {
			Czm->srSelfDir, ( hxdw_SplitExt(Czm->srSelfBaseName).first) });
	//MessageBox( 0, Czm->srSelfIniPath.c_str(), "", 0 );
	{
	/*	std::vector<std::string> lines2;
		hxdw_GetTextLinesFromFile( Czm->srSelfIniPath.c_str(), &lines2 );
		for( auto ir2 = lines2.begin(); ir2 != lines2.end(); ++ir2 ){
			static const char* const needle2 = "bShowStartupTip";
			bool rs2 = hxdw_StrCmpOpt(needle2, ir2->c_str(),
					(int)std::strlen(needle2), "");
			if( !rs2 ){
				if( std::strchr( ir2->c_str(), '0' ) ){
					Czm->bShowStartupTip = 0L;
				}
			}
		}//*/
	}{
		assert( !Czm->ini2 );
		Czm->ini2 = new hxdw_IniData2;
		*Czm->ini2 = hxdw_ParseINIFile( Czm->srSelfIniPath.c_str() );
	}{
		assert( Czm->ini2 );
		Czm->bShowStartupTip = std::atoi(
			Czm->ini2->getValue("s_main", "bShowStartupTip", "1").c_str() );

		Czm->bAllocConsoleFlag = std::atoi(
			Czm->ini2->getValue("s_main", "bAllocConsoleFlag", "0").c_str() );
		if( Czm->bAllocConsoleFlag ){
			AllocConsole();
		}
	}
}
/// Calculates program version from executable file contents via MD5 checksums in INI.
std::string czm_CalcProgramVersion()
{
	assert( Czm );
	assert( Czm->ini2 );
	const char* szUnkVerText = "unknown";
	std::string srMd5x;
	{
		std::vector<uint8_t> data2;
		data2 = hxdw_GetBinaryFileContents( Czm->srSelfFullPath.c_str(), 32*1000*1024 );
		if( data2.empty() ){
			return szUnkVerText;
		}
		{
			CzmMd5 cMd5;
			cMd5.update2( &data2[0], data2.size() );
			cMd5.finalize2();
			srMd5x = cMd5.getHexDigest();
		}
	}
	std::string srVersion;
	Czm->ini2->eachVariable( {"s_versions",},
		[&]( const char* sec_, const char* kname, const char* value2 )->bool{
			if( !hxdw_StrCmpOpt( srMd5x.c_str(), kname, -1, "i") ){
				srVersion = value2;
				return 0L;
			}
			return 1L;
	});
	if( srVersion.empty() ){
		return szUnkVerText;
	}
	return srVersion;
}

