#include "czm_gphax_misc.h"
#include <assert.h>
#include "MinHook.h"
#include "hxdw_utils.h"
#include "hxdw_process.h"
#include "czm_utils.h"
#include "czm_interfaces.h"

CzmGpData* Gpd = nullptr;   //as extern in the .h file.
char bfr2[256], bfr3[256];

void czm_OnDamageAnyEnemy3( CzmRE4EnemyData* pEnmyDtaPtr4 )
{
	assert( Gpd );
	{
		Gpd->cnt2 += 1;
		snprintf( bfr2, sizeof(bfr2),
			"OnDamage-%u: p:0x%X, sEnTy:%s",
				Gpd->cnt2,
				(uint32_t)(size_t)pEnmyDtaPtr4,
				pEnmyDtaPtr4->snprintfEnemyType( bfr3, sizeof(bfr3), "[%02X,%02X]") );
		hxdw_StdPrint2( (std::string(std::string("CZM: ")+bfr2)+"\n").c_str() );
		assert( Czm );
		Czm->addLog3( bfr2, {} );
	}
	if( Gpd->aHotPatches2 ){
		czm_EachHotPatch( [&]( const CzmEachHPatchDTO& in2 ){
			in2.hp3->notifyDamageAnyEnemy2(
				CzmDmg2DTO{ 0L, pEnmyDtaPtr4,} );
		});
	}
}

// dmg2_on_damage_enemy_or_leon_fqYhLH: 0x1B4AF0
uint32_t __stdcall czm_OnDamageAnyEnemy2()
{
	static CzmRE4EnemyData* pEnmyDtaPtr2 = nullptr;
	__asm{
		mov eax, dword ptr [esp+8]
		mov pEnmyDtaPtr2, eax
	}
	assert( czm_OgOnDamageEnemy );
	assert( Gpd );
	czm_OnDamageAnyEnemy3( pEnmyDtaPtr2 );

	using fn_t = decltype(czm_OnDamageAnyEnemy2)*;
	//((fn_t)czm_OgOnDamageEnemy)();
	uint32_t retv = ((fn_t)czm_OgOnDamageEnemy)();
	return retv;
}

// dmg2_enemy_dies_insta_call_VIYHti: 0x1B4EAF
void __stdcall czm_OnEnemyDies()
{
	static CzmRE4EnemyData* pEnmyDtaPtr2 = 0;
	__asm{
		mov pEnmyDtaPtr2, esi
	}
	assert( czm_OgOnEnemyDies );
	Gpd->cnt2 += 1;
	snprintf( bfr2, sizeof(bfr2),
		"CZM: czm_OnEnemyDies(), %03u, pEds:0x%X\n", Gpd->cnt2, (uint32_t)(size_t)pEnmyDtaPtr2 );
	hxdw_StdPrint2( bfr2 );
	//CzmHotPatchBase::notifyEnemyDeath( pEnmyDtaPtr2 )
	czm_OgOnEnemyDies();
}
// dmg2_head_plaga_insta_kill_via_flgrnde_2tyKFv: 0x4ADFA
void __stdcall czm_OnEnemyDiesFlashToHeadPlaga()
{
	static CzmRE4EnemyData* pEnmyDtaPtr2 = 0;
	__asm{
		mov pEnmyDtaPtr2, edi
	}
	assert( czm_OgOnEnemyDiesFlashToHeadPlaga );
	Gpd->cnt2 += 1;
	snprintf( bfr2, sizeof(bfr2),
		"CZM: czm_OnEnemyDiesFlashToHeadPlaga(), %03u, pEds:0x%X\n", Gpd->cnt2, (uint32_t)(size_t)pEnmyDtaPtr2 );
	hxdw_StdPrint2( bfr2 );
	//CzmHotPatchBase::notifyEnemyDeath( pEnmyDtaPtr2 )
	czm_OgOnEnemyDiesFlashToHeadPlaga();
}
//dmg2_enemy_dies_via_drowning_late_call_9WdnhN: 0x41521
void __stdcall czm_OnEnemyDiesDrowning()
{
	static CzmRE4EnemyData* pEnmyDtaPtr2 = 0;
	__asm{
		mov pEnmyDtaPtr2, esi
	}
	assert( czm_OgOnEnemyDiesDrowning );
	Gpd->cnt2 += 1;
	snprintf( bfr2, sizeof(bfr2),
		"CZM: czm_OnEnemyDiesDrowning(), %03u, pEds:0x%X\n", Gpd->cnt2, (uint32_t)(size_t)pEnmyDtaPtr2 );
	hxdw_StdPrint2( bfr2 );
	//CzmHotPatchBase::notifyEnemyDeath( pEnmyDtaPtr2 )
	czm_OgOnEnemyDiesDrowning();
}
uint32_t __cdecl czm_OnRoomLoad( uint32_t arg1, uint32_t arg2 )
{
	hxdw_StdPrint2( "CZM: czm_OnRoomLoad()\n" );
	assert( Gpd->ppUnkRData2 );
	CzmRE4UnkRoomData* pRoomDt = *Gpd->ppUnkRData2;
	{
		snprintf( bfr2, sizeof(bfr2), "0x%X", (int)(pRoomDt->pokeRoomIdValue()) );
		czm_Print2( "CZM: room-id: %a\n", { std::string(bfr2),} );
	}
	using fn_t = decltype(czm_OnRoomLoad)*;
	assert( czm_OgOnRoomLoad );

	//CzmHotPatchBase* p = 0;
	//p->notifyRoomLoad( CzmRoomLoadDTO{ CZM_ERLT::E2_NewRoom,
	//		uint16_t((unsigned int)pRoomDt->pokeRoomIdValue()),});

	uint32_t retv = ((fn_t)czm_OgOnRoomLoad)( arg1, arg2 );
	return retv;
}
// ESL_on_exit_to_the_main_menu_XC3w9F
void __stdcall czm_OnReturnToMainMenu()
{
	assert( czm_OgOnReturnToMainMenu );
	czm_Print2( "CZM: czm_OnReturnToMainMenu()\n", {} );

	//assert(Czm);
	//Czm->OnReturnToMainMenu();

	//CzmHotPatchBase* p = 0;
	//p->notifyRoomLoad( CzmRoomLoadDTO{ CZM_ERLT::E2_ToMainMenu,0,} );

	czm_OgOnReturnToMainMenu();
}
uint32_t __stdcall czm_OnDamageOnNormalEnemy()
{
	assert( Gpd );
	//uint8_t uWeaponType = 0xFF;   //eg. CZM_EWT::CZM_E3_Handgun=0x02
	CZM_EWT uWeaponType = (CZM_EWT)0x00;   //eg. CZM_EWT::CZM_E3_Handgun=0x02
	__asm{
		push eax
		mov al, byte ptr [edi+0x32E]
		mov uWeaponType, al
		pop eax
	}
	using fn_t = decltype(czm_OnDamageOnNormalEnemy)*;
	uint32_t uDmgVal = ((fn_t)czm_OgOnDamageOnNormalEnemy)();
	{
		Gpd->cnt2 += 1;
		snprintf( bfr2, sizeof(bfr2),
			"CZM: czm_OnDamageOnNormalEnemy() exit, %d, dmg:%u_d, wpn:0x%X\n",
			Gpd->cnt2, uDmgVal, (uint32_t)uWeaponType );
		czm_Print2( bfr2, {} );
	}
	if( Gpd->aHotPatches2 ){
	/*	for( size_t ii2=0; Gpd->aHotPatches2_[ii2].pHotPatch; ii2++ ){
			CzmHotPatchBase* ptr = Gpd->aHotPatches2_[ii2].pHotPatch;
			if( ptr && ptr->pokeIsEnabled() ){
				ptr->notifyDamageNormalEnemy(
					CzmDmg3DTO{0L, uWeaponType, &uDmgVal,
						CZM_ECDT::CZM_E4_None,} );
			}
		}//*/
		czm_EachHotPatch( [&]( const CzmEachHPatchDTO& in2 ){
			in2.hp3->notifyDamageNormalEnemy(
				CzmDmg3DTO{ 0L, uWeaponType, &uDmgVal,
					CZM_ECDT::CZM_E4_None,} );
		});
	}
	if( Gpd->bCritRegistered ){
		//uDmgVal = 0;
	}
	Gpd->bCritRegistered = 0;
	return uDmgVal;
}
/*
void __stdcall czm_OnCritDamageValue()
{
	// BYTE PTR [edi+32Eh] -- weapon|mele type, eg. 0x02: handgun, 0x10: knife.

	assert( Gpd );
	assert( czm_OgOnCritDamageValue );
	{
		Gpd->cnt2 += 1;
		snprintf( bfr2, sizeof(bfr2), "CZM: czm_OnCritDamageValue() %d\n", Gpd->cnt2 );
		czm_Print2( bfr2, {} );
	}
	Gpd->bCritRegistered = 1;
	using fn_t = decltype(czm_OnCritDamageValue)*;
	((fn_t)czm_OgOnCritDamageValue)();
}//*/
void __stdcall
czm_OnFloatToIntOnCritical( CZM_EWT uWeaponType, uint32_t* ptrDmgVal )
{
	if( Gpd && Gpd->aHotPatches2 ){
		czm_EachHotPatch( [&]( const CzmEachHPatchDTO& in2 ){
			in2.hp3->notifyDamageNormalEnemy(
				CzmDmg3DTO{ 0L, uWeaponType, ptrDmgVal,
					CZM_ECDT::CZM_E4_Critical,} );
		} );
	}
}
uint32_t __cdecl czm_OnFloatToIntFeCrit()
{
	static uint8_t* pRetAddr = nullptr;
	__asm{
		mov eax, dword ptr [esp+4]  // accessing ESP this must be done at the begin.
		mov pRetAddr, eax
	}
	assert( Gpd );
	static bool bCritModeOpCall = 0;
	bCritModeOpCall = ( pRetAddr == Gpd->pAtCritFloatToIntRetAddr );
	if( bCritModeOpCall ){
		czm_Print2( "CZM: czm_OnFloatToIntFeCrit() [Crit-2]\n", {} );
	}
	using fn_t = decltype(czm_OnFloatToIntFeCrit)*;
	static uint32_t retv;
	retv = ((fn_t)czm_OgOnFloatToIntFeCrit)();
	if( bCritModeOpCall && Gpd->bMdxInitedOneTime ){
		static CZM_EWT uWeaponType = (CZM_EWT)0x00;   //eg. CZM_E3_Handgun=0x02
		__asm{
			mov al, byte ptr [edi+0x32E]
			mov uWeaponType, al
		}
		//Gpd->bCritRegistered = 1;
		czm_OnFloatToIntOnCritical( uWeaponType, &retv );
	}
	return retv;
}
const char* CzmRE4EnemyData::
snprintfEnemyType( char* bfrPtr, size_t nBfrSize_, const char* fmt_ )
{
	{
		size_t nCntPercent = 0;
		for( const char* p=fmt_; (p=std::strchr(p,'%')); nCntPercent++, p++ ){}
		assert( nCntPercent == 2 );
	}
	snprintf( bfrPtr, nBfrSize_, fmt_,
		sEnTy.uEnemyType2,
		sEnTy.uEnemySubType2 );
	return bfrPtr;
}
bool CzmRE4EnemyData::testEnemyType( std::array<uint8_t,2> ty_and_sub_ty )const
{
	if( sEnTy.uEnemyType2 == ty_and_sub_ty[0] && sEnTy.uEnemySubType2 == ty_and_sub_ty[1] ){
		return 1L;
	}
	return 0L;
}//*/
void CzmRE4EnemyData::setHealth( uint16_t inp )
{
	sHealth2.aHealth2[0] = inp & 0xFF;
	sHealth2.aHealth2[1] = (inp>>8) & 0xFF;
}
uint16_t CzmRE4UnkRoomData::
pokeRoomIdValue( bool bSet, uint16_t uNewRoomId )
{
	if( bSet ){
		sRoomId.aValue[0] = uint8_t(uNewRoomId & 0xFF);
		sRoomId.aValue[1] = uint8_t((uNewRoomId >> 8) & 0xFF);;
	}
	uint16_t outp = 0;
	outp |= ( static_cast<uint16_t>(sRoomId.aValue[0]) );
	outp |= ( static_cast<uint16_t>(sRoomId.aValue[1]) << 8 );
	return outp;
}

int CzmDelLagoInstaKO::
notifyDamageAnyEnemy2( const CzmDmg2DTO& inp )
{
	if( inp.bTestRun2 )
		return inp.bTestRun2;

	if( mEnableInstaKO ){
		// 0x2F,0x00 - Del Lago (DelLago)
		if( inp.pEnmyDtaPtr3->testEnemyType( {0x2F,0x00,} ) ){
			inp.pEnmyDtaPtr3->setHealth( 0 );
		}
	}
	return 0;
}
void CzmDelLagoInstaKO::setDelLagoInstaKO( bool bSet )
{
	mEnableInstaKO = bSet;
}
int CzmCritManip::notifyDamageNormalEnemy( const CzmDmg3DTO& inp )
{
	if( inp.bTestRun3 )
		return inp.bTestRun3;

	if( inp.eCritDmgType == CZM_ECDT::CZM_E4_Critical ){
		//setAlterableDamageTypes//setCriticalDamageScale
		if( mCritDmgScale != 1.f ){
			bool rs2 = std::any_of( aAlterableDmgTy.begin(), aAlterableDmgTy.end(),
					[&]( CZM_EWT e )->bool{ return e == inp.uWeaponType;});
			if( rs2 ){
				double val2 = double(*inp.pDamgeValue) * double(mCritDmgScale);
				*inp.pDamgeValue = CzmClamp<double,uint32_t>( val2, 0.f, 65535.f );
			}
		}
	}
	return 0;
}
void CzmCritManip::setAlterableDamageTypes( const std::vector<CZM_EWT>& inp )
{
	aAlterableDmgTy = inp;
}
void CzmCritManip::setCriticalDamageScale( float fCritDmgScale_ )
{
	mCritDmgScale = fCritDmgScale_;
}
uint32_t czm_GpHaxInit()
{
	assert( !Gpd );
	Gpd = new CzmGpData;
	{
		// dmg2_on_damage_enemy_or_leon_fqYhLH
		void* pAtOpCode = hxdw_GetPtrGivenInSectionOffset( 0, nullptr, ".text", 0x1B4AF0 );
		assert( pAtOpCode );
		if( MH_CreateHook( pAtOpCode, czm_OnDamageAnyEnemy2, (void**)(&czm_OgOnDamageEnemy)) ) { return 103; }
		if( MH_EnableHook( pAtOpCode) ) { return 104; }
	}{
		void* pAtOpCode = hxdw_GetPtrGivenInSectionOffset( 0, nullptr, ".text", 0x1B4EAF );
		assert( pAtOpCode );
		if( MH_CreateHook( pAtOpCode, czm_OnEnemyDies, (void**)(&czm_OgOnEnemyDies)) ) { return 103; }
		if( MH_EnableHook( pAtOpCode) ) { return 104; }
	}{
		void* pAtOpCode = hxdw_GetPtrGivenInSectionOffset( 0, nullptr, ".text", 0x4ADFA );
		assert( pAtOpCode );
		if( MH_CreateHook( pAtOpCode, czm_OnEnemyDiesFlashToHeadPlaga, (void**)(&czm_OgOnEnemyDiesFlashToHeadPlaga)) ) { return 103; }
		if( MH_EnableHook( pAtOpCode) ) { return 104; }
	}{
		void* pAtOpCode = hxdw_GetPtrGivenInSectionOffset( 0, nullptr, ".text", 0x41521 );
		assert( pAtOpCode );
		if( MH_CreateHook( pAtOpCode, czm_OnEnemyDiesDrowning, (void**)(&czm_OgOnEnemyDiesDrowning)) ) { return 103; }
		if( MH_EnableHook( pAtOpCode) ) { return 104; }
	}{
		// HFD_RNESL_ROOM_LOAD_FUNCTION_OFFSET=0x1B14C0
		void* pAtOpCode = hxdw_GetPtrGivenInSectionOffset( 0, nullptr, ".text", 0x1B14C0 );
		assert( pAtOpCode );
		if( MH_CreateHook( pAtOpCode, czm_OnRoomLoad, (void**)(&czm_OgOnRoomLoad)) ) { return 105; }
		if( MH_EnableHook( pAtOpCode) ) { return 106;}
	}{
		void* pAtOpCode = hxdw_GetPtrGivenInSectionOffset( 0, nullptr, ".text", 0x251D30 );
		assert( pAtOpCode );
		if( MH_CreateHook( pAtOpCode, czm_OnReturnToMainMenu, (void**)(&czm_OgOnReturnToMainMenu)) ) { return 105; }
		if( MH_EnableHook( pAtOpCode) ) { return 106;}
	}{
		// dmg2_on_hit_damage_normal_enemy_1w00AD4
		void* pAtOpCode = hxdw_GetPtrGivenInSectionOffset( 0, nullptr, ".text", 0x49D40 );
		assert( pAtOpCode );
		if( MH_CreateHook( pAtOpCode, czm_OnDamageOnNormalEnemy, (void**)(&czm_OgOnDamageOnNormalEnemy)) ) { return 628144137; }
		if( MH_EnableHook( pAtOpCode) ) { return 53047405;}
	}{
	/*	// dmg2_possible_patch_point_for_final_crit_dmg_value_V3mNA2
		void* pAtOpCode = hxdw_GetPtrGivenInSectionOffset( 0, nullptr, ".text", 0x49F8E );
		assert( pAtOpCode );
		if( MH_CreateHook( pAtOpCode, czm_OnCritDamageValue, (void**)(&czm_OgOnCritDamageValue)) ) { return 628144137; }
		if( MH_EnableHook( pAtOpCode) ) { return 53047405;}
		//*/
	}{
		// dmg2_float_to_int_fe_on_crit_qaXKLvy : .text+0x66DCF0
		void* pAtOpCode = hxdw_GetPtrGivenInSectionOffset( 0, nullptr, ".text", 0x66DCF0 );
		assert( pAtOpCode );
		if( MH_CreateHook( pAtOpCode, czm_OnFloatToIntFeCrit, (void**)(&czm_OgOnFloatToIntFeCrit)) ) { return 628144137; }
		if( MH_EnableHook( pAtOpCode) ) { return 53047405;}

		// crit. calc. call point: ".text"+0x49F8E
		// crit. calc. ret addr  : ".text"+0x49F8E+5
		void* p = hxdw_GetPtrGivenInSectionOffset( 0, nullptr, ".text", 0x49F8E+5 );
		Gpd->pAtCritFloatToIntRetAddr = (uint8_t*) p;
		assert( Gpd->pAtCritFloatToIntRetAddr );
	}
	{
		#define RE4UNKROOMDATA_OFFSET_IN_DOT_DATA 0x13F3C
		assert( !Gpd->ppUnkRData2 );
		Gpd->ppUnkRData2 = (CzmRE4UnkRoomData**)hxdw_GetPtrGivenInSectionOffset( 0, nullptr, ".data", RE4UNKROOMDATA_OFFSET_IN_DOT_DATA );
		assert( Gpd->ppUnkRData2 );
	}
	{
		size_t ii3 = 0;
		Gpd->aHotPatches2 = new CzmHotPatchDTO[3];
		Gpd->aHotPatches2[ii3++] = CzmHotPatchDTO{ new CzmDelLagoInstaKO,};
		Gpd->aHotPatches2[ii3++] = CzmHotPatchDTO{ new CzmCritManip,};
		Gpd->aHotPatches2[ii3++] = CzmHotPatchDTO{ nullptr,};
		for( size_t ii2=0; Gpd->aHotPatches2[ii2].pHotPatch; ii2++ ){
			auto& hp2 = Gpd->aHotPatches2[ii2];
			if( hp2.pHotPatch ){
				hp2.pHotPatch->pokeIsEnabled( 1L );
			}
		}//*/
		//setAlterableDamageTypes
	}
	Gpd->bMdxInitedOneTime = 1;
	return 0;  //0==ok
}

/// Returns 0 on success.
/// See czm_GpHaxInit().
uint32_t czm_GpHaxDeinit()
{
	assert( Gpd );
	if( !Gpd->bMdxInitedOneTime ){
		return 591502354;
	}
	if( Gpd->bMdxDeinited ){
		return 952045340;
	}
	MH_DisableHook( czm_OnDamageAnyEnemy2 );
	MH_DisableHook( czm_OnEnemyDies );
	MH_DisableHook( czm_OnEnemyDiesFlashToHeadPlaga );
	MH_DisableHook( czm_OnEnemyDiesDrowning );
	MH_DisableHook( czm_OnRoomLoad );
	MH_DisableHook( czm_OnReturnToMainMenu );

	Gpd->bMdxDeinited = 1;

	delete Gpd;
	Gpd = nullptr;
	return 0;
}
//void czm_EachHotPatch_( void(*calb2)( const CzmEachHPatchDTO& inp ) )
void czm_EachHotPatch( std::function< void(const CzmEachHPatchDTO&)> calb2 )
{
	assert( Gpd );
	if( Gpd->aHotPatches2 ){
		for( size_t ii2=0; Gpd->aHotPatches2[ii2].pHotPatch; ii2++ ){
			CzmHotPatchBase* ptr = Gpd->aHotPatches2[ii2].pHotPatch;
			if( ptr && ptr->pokeIsEnabled() ){
				calb2( CzmEachHPatchDTO{ ptr,} );
			}
		}
	}
}
