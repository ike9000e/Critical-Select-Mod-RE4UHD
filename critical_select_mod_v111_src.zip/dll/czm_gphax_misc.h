#pragma once
#include <inttypes.h>   //uint32_t
#include <vector>
#include <functional>
#include <algorithm>
#include "czm_interfaces.h"

#pragma pack(push)  //[m9XodnW:a] //{
#pragma pack(1)
struct CzmRE4EnemyData
{
	union{
		struct{
			uint8_t skip0[0x100];
			uint8_t uEnemyType2 = 0;
			uint8_t uEnemySubType2 = 0;
		}sEnTy;
		struct{
			uint8_t skip0[0x324];
			uint8_t aHealth2[2];
		}sHealth2;
	};
	const char* snprintfEnemyType( char* bfrPtr, size_t nBfrSize_, const char* fmt_ );
//	bool testEnemyType( uint8_t type_, uint8_t sub_type_ )const;
	bool testEnemyType( std::array<uint8_t,2> ty_and_sub_ty )const;
	void setHealth( uint16_t inp );
};
/// Unknown room data on room load.
/// Can be found in the pointer that itself is located at
/// the offset 0x13F3C in the ".data" segment in the "Bio4.exe".
struct CzmRE4UnkRoomData{

	union{
		struct{
			uint8_t skip0[0x4FAC];
			uint8_t aValue[2];
		}sRoomId;
		struct{
			uint8_t skip0[0x5410];
			uint8_t pByte0[1];
		}sESLData;
	};
	uint16_t pokeRoomIdValue( bool bSet=0, uint16_t uNewRoomId=0 );
};
#pragma pack(pop)  //[m9XodnW:b] //}

using CzmVoidStdcallVoid_t = void(__stdcall*)();
void*                czm_OgOnDamageEnemy = nullptr;
CzmVoidStdcallVoid_t czm_OgOnEnemyDies = nullptr;
CzmVoidStdcallVoid_t czm_OgOnEnemyDiesFlashToHeadPlaga = nullptr;
CzmVoidStdcallVoid_t czm_OgOnEnemyDiesDrowning = nullptr;
void*                czm_OgOnRoomLoad = nullptr;
CzmVoidStdcallVoid_t czm_OgOnReturnToMainMenu = nullptr;
//void*              czm_OgOnCritDamageValue = nullptr;
void*                czm_OgOnDamageOnNormalEnemy = nullptr;
void*                czm_OgOnFloatToIntFeCrit = nullptr;

struct CzmHotPatchDTO {
	CzmHotPatchBase* pHotPatch = nullptr;
};
struct CzmDelLagoInstaKO : CzmHotPatchBase {
	virtual int notifyDamageAnyEnemy2( const CzmDmg2DTO& inp ) override;
	virtual void setDelLagoInstaKO( bool bSet ) override;
private:
	bool mEnableInstaKO = 0L;
};
struct CzmCritManip : CzmHotPatchBase {
	virtual int  notifyDamageNormalEnemy( const CzmDmg3DTO& inp ) override;
	virtual void setAlterableDamageTypes( const std::vector<CZM_EWT>& inp ) override;
	virtual void setCriticalDamageScale( float fCritDmgScale_ ) override;
private:
	std::vector<CZM_EWT> aAlterableDmgTy;
	float mCritDmgScale = 1.0f;
};

uint32_t    czm_GpHaxInit();
uint32_t    czm_GpHaxDeinit();
void        czm_EachHotPatch( std::function< void(const CzmEachHPatchDTO&)> calb2 );

/// Gameplay data.
struct CzmGpData
{
	bool bMdxInitedOneTime = 0;
	bool bMdxDeinited = 0;
	int cnt2 = 0;
	//void** ppUnkData2 = nullptr;
	CzmRE4UnkRoomData** ppUnkRData2 = nullptr;
	bool bCritRegistered = 0;
	//CzmHotPatchDTO aHotPatches2[3];
	CzmHotPatchDTO* aHotPatches2 = nullptr;
	uint8_t* pAtCritFloatToIntRetAddr = nullptr;   //offset in ".text": 0x49F8E+5
};
extern CzmGpData* Gpd;
