#pragma once
//#include <algorithm>
//#include <functional>
#include <string>
#include <vector>
#include <array>
#include <inttypes.h>
#include "czm_interfaces.h"

struct IDirect3DDevice9; struct ImGuiContext; struct HxdwPrintAdp;
struct CzmRE4EnemyData;
enum class CZM_EWT : uint8_t;
enum class CZM_EWGR : int;

uint32_t    czm_Win32DetoursInit();
uint32_t    czm_Win32DetoursDeinit();
bool        czm_Print2( const char* fmt, const std::vector<HxdwPrintAdp> args4 );
bool        czm_AnySystemModkeyDown();
void        czm_SetupUIElements();
bool        czm_ProcessUIKey( uint16_t nXInputButtons );

std::string czm_GetWeaponTypeName2( CZM_EWT, bool bGetAsEnum );
auto        czm_GetWeaponTypeByIndex( size_t index2 ) -> CzmPair<bool,CZM_EWT>;
size_t      czm_GetWeaponTypeCount();
auto        czm_GetWeaponGroupTypeWeapons( CZM_EWGR eWpnGrTy ) -> std::vector<CZM_EWT>;
void        czm_CreateWeaponTypeUIItems();
auto        czm_ConvWeaponTypeIndexesToTypes( const std::vector<int>& inp ) -> std::vector<CZM_EWT>;
void        czm_UpdateFromConfigFile();

struct CzmCrNewDevDTO{
	IDirect3DDevice9* pD3d9Device = nullptr;
};
struct CzmLogItem{
	CzmLogItem( std::string inp ) : srText2(inp) {}
	std::string srText2;
};

/// Weapon|damage types.
enum class CZM_EWT : uint8_t {
	CZM_E3_Punisher = 0x01,
	CZM_E3_Handgun = 0x02,
	CZM_E3_Red9 = 0x03,
	CZM_E3_Blacktail = 0x04,   // Leon or Ada
	CZM_E3_Matilda = 0x11,
	CZM_E3_TMP = 0x0B,   //with or w/o the stock.
	// Kick. As Leon or Ada.
	// * Leon. roundhouse kick (thai style).
	// * Leon. turnaround kick (on kneeling enemy).
	// * Ada jump-in kick.
	// * Ada turnaround kick (on kneeling enemy).
	// * ...
	CZM_E3_Kick = 0x14,
	CZM_E3_Knife = 0x10,  //Leon or Ada.
	CZM_E3_ChicagoTypewriter = 0x0C,  //Chicago Typewriter aka. Tommy Gun.
	CZM_E3_RocketLauncher = 0x12,   //single load
	CZM_E3_RiffleSemiauto = 0x0A,  //Sniper Riffle (military style)
	CZM_E3_HuntingRiffle = 0x09, // Riffle (hunting style, with or w/o the scope.)
	CZM_E3_BrokenButterfly = 0x05,
	CZM_E3_Killer7 = 0x06,
	CZM_E3_Handcannon = 0x0F,
	CZM_E3_MineThrower = 0x0E,   //the projectile shot, ie. not the explosion.
	CZM_E3_Shotgun = 0x07,  //base shotgun
	CZM_E3_Striker = 0x08,
	CZM_E3_RiotGun = 0x21,
	// Explosion damage type.
	// Incl. red explosive barrels, Mine Thrower grenade explosion,
	// Frag Grenade explosion.
	CZM_E3_Explosion = 0x13,
	CZM_E3_FlashGrenade = 0x17, //does 0 damage
	//...
};
/// Weapon group types.
enum class CZM_EWGR : int {
	CZM_E5_Pistols = 1,  /// Eg. \ref CZM_E3_Punisher.
	CZM_E5_Shotguns,
	CZM_E5_Rifles,
	CZM_E5_Magnums,
	CZM_E5_Mele,
	CZM_E5_Explosives,
	CZM_E5_CheatWeapons,
};

struct CzmWndGeomMgr {
	CzmWndGeomMgr() = default;
	CzmWndGeomMgr( std::array<float,4> aDflt );
	void        updateOnWindowBegin();
	void        updateOnWindowEnd();
	static auto getWindowGeometry() -> std::array<int,4>;
	static auto getWindowFGeometry() -> std::array<float,4>;
	std::string serialize2()const;
	void        deserialize2( const char* inp );
	void        onRezChange( std::array<int,2> aOldRez, std::array<int,2> aNewRez );
private:
	std::array<int,4>   aNXywh = { 128, 92, 400, 300,};
	std::array<float,4> aFXywh = { 0.1f, 0.1f, 0.8f, 0.8f,};
	bool bNeedGmtryUpdate = 0L;
};
struct CzmData
{
	ImGuiContext* pImGuiCtx{};
	const char* szAppName = "Critical Select Mod";
	//apogee//apex//meridian//zenith//Amplifier
	void*         fnOgPeekMessageA{};  //decltype(PeekMessageA);
	void*         fnOgPeekMessageW{};  //decltype(PeekMessageA);
	void*         fnOgGetRawInputData{};
	void*         hwMain = 0;
	void*         pD3d9Device2{};  //IDirect3DDevice9*
	void*         fnOgDirect3DCreate9{};  //decltype(Direct3DCreate9)*;
	// XInput gamepad.
	void*         hXInputDll{};
	void*         fnOgXInputGetState{};  //XInputGetState()
	// gamepad menu navigation,
	bool bUIOpened = 0L;
	bool bShowLogWindow = 0L;
	bool bLogAutoScroll = 1L;

	bool bShowStartupTip = 1L;
	uint32_t uStartupTipOpenedAtMs = 0;
	uint32_t uStartupTipDurationMs = 10000;
	bool bKeyboardNavError = 0L;
	bool bGamepadNavError = 0L;

	static const std::vector<std::pair<int,int> > aUIButtonMap;
	int16_t nXInputButtons2 = 0;
	static const int16_t nUIButtonMask;
	static const uint32_t uUIButtonIntervalMs;
	uint32_t uUIButtonTimePos = 0;
	bool bUIButtonHeld = 0;
	//
	void addLog3( const char* fmt, const std::vector<HxdwPrintAdp> args4 );
	auto getLogText2( int index = -1 )const -> CzmPair<const char*,size_t>;
	void clearLogText2();
	//
	std::vector<CzmLogItem> aLogText;
	CzmPair<size_t,int> aLogItemTrack = {0,0,};
	//
	static const char* const szAllocConsoleFlag;
	//
	std::array<int,2> aCurrentRez = {0,0,};
	float fUIScale2 = 1.0f;
	//
	CzmWndGeomMgr cLogWndGmtr = CzmWndGeomMgr( {0.005f,0.6f,0.5f,0.33f,});
	CzmWndGeomMgr cSettingsWndGmtr = CzmWndGeomMgr( {0.1f,0.1f,0.8f,0.8f,});
	bool bGBossesTabOn = 0, bFocusNeedleOn = 0L;

	std::vector<int> aWpnCheckFlags;

	std::string srSelfDir, srSelfBaseName, srSelfFullPath, srSelfIniPath;
};
extern CzmData* Czm;
