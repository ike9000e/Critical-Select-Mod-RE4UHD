#pragma once
#include <algorithm>
//#include <functional>
//#include <string>
#include <vector>
//#include <array>
#include <inttypes.h>
#include <type_traits>  //std::is_same

struct CzmRE4EnemyData;
enum class CZM_EWT : uint8_t;

// Room Load Type.
enum class CZM_ERLT : int {
	E2_ToMainMenu = 1,
	E2_NewRoom,
};
struct CzmRoomLoadDTO{
	CZM_ERLT eRoomLoadType = CZM_ERLT::E2_NewRoom;
	uint16_t uRoomId = 0;
};
struct CzmDmg2DTO{
	int bTestRun2 = 0;
	CzmRE4EnemyData* pEnmyDtaPtr3 = nullptr;
};
/// Critical damage type.
enum class CZM_ECDT : int {
	CZM_E4_None = 1,
	CZM_E4_Critical,
};
struct CzmDmg3DTO{
	int bTestRun3 = 0;
	//uint8_t uWeaponType = 0x00;
	CZM_EWT uWeaponType = (CZM_EWT)0x00;
	uint32_t* pDamgeValue = nullptr;
	CZM_ECDT eCritDmgType = CZM_ECDT::CZM_E4_None;
};
struct CzmHotPatchBase {
	virtual int notifyEnemyDeath( CzmRE4EnemyData* inp ) {return -1;}
	virtual int notifyRoomLoad( const CzmRoomLoadDTO& inp ) {return -1;}
	virtual int notifyDamageAnyEnemy2( const CzmDmg2DTO& inp ) {return -1;}
	virtual int notifyDamageNormalEnemy( const CzmDmg3DTO& inp ) {return -1;}
	bool pokeIsEnabled( int bEnable = -1 );
	virtual void setAlterableDamageTypes( const std::vector<CZM_EWT>& inp ) {}
	virtual void setCriticalDamageScale( float fCritDmgScale ) {}
	virtual void setDelLagoInstaKO( bool bSet ) {}
private:
	bool mEnabled = 0L;
};

template<class Txx, class Uxx>
struct CzmPair{
	static_assert( !std::is_same<Txx,Uxx>::value, "Types must be different." );
	Txx first;
	Uxx second;
	CzmPair( const Txx& first_, const Uxx& second_ ) : first(first_), second(second_) {}
	CzmPair() = default;
	Txx operator*()const {return first;}
	Uxx operator+()const {return second;}
};

/// Gets array size.
template<class Txx> //constexpr
size_t CzmArrSize( Txx& inp )
{
	size_t size_ = sizeof(inp) / sizeof(inp[0]);
	return size_;
}
struct CzmEachHPatchDTO {
	CzmHotPatchBase* hp3{};
};
template<class Txx, class Oxx>
Oxx CzmClamp( Txx inp, Txx minval, Txx maxval )
{
	Oxx outp = static_cast<Oxx>(
			std::max<Txx>(
				std::min<Txx>( inp, maxval ), minval ) );
	return outp;
}
