#include "czm_interfaces.h"

bool CzmHotPatchBase::pokeIsEnabled( int bEnable )
{
	if( bEnable != -1 ){
		mEnabled = bEnable;
	}
	return mEnabled;
}

void x()
{
	CzmClamp<double,double>( 21.1, 0.f, 1.f );

}
