#include "cid_entrypoint.h"
#include "hxdw_detours_misc.h"
#include "hxdw_utils.h"

// as extern in the header.
CidData* Cid2 = nullptr;
//const char* const CidData::szBkpExt = "bkp";

static BOOL CALLBACK cid_BywayCallback2(_In_opt_ PVOID pContext,
			_In_opt_ LPCSTR pszFile,
			_Outptr_result_maybenull_ LPCSTR* ppszOutFile )
{
	//printf("CID: DLL: [%s]\n", (pszFile ? pszFile : "null_ptr") );
	if( pszFile ){
		printf("CID: DLL: [%s]\n", pszFile );
	}
	return 1L;
}
static BOOL CALLBACK
cid_DetourBinaryFileCallback(
		PVOID pContext,
		LPCSTR pszOrigFile,
		LPCSTR pszFile,
		LPCSTR* ppszOutFile )
{
	printf("CID: DLL: [%20s] -> [%s]\n", pszOrigFile, pszFile );
	return 1L;
}
/**
	Adds DLL to PE file imports.
	Creates backup of the PE first.

	\param flags2 - flags as c-string;
			        r: reset imports added previously by Detours, if any.
*/
bool cid_AddDLLToPEBinary(
		std::string srTargetPEPathName,
		std::string srBackupFName,
		std::string srDllBaseNameToAdd,
		const char* flags2,
		std::string* srBackupFileNameOu,
		std::string* err2_ )
{
	assert( err2_ );
	assert( hxdw_IsWithPathPart(srTargetPEPathName) );
	assert( !srBackupFName.empty() );
	bool bResetDll = !!std::strchr( flags2, 'r');
	bool bGood = 1L;  // "setdll.cpp"
	HANDLE hOld = INVALID_HANDLE_VALUE;
	HANDLE hNew = INVALID_HANDLE_VALUE;
	PDETOUR_BINARY pBinary = NULL;
	std::shared_ptr<void*> raii5( nullptr, [&]( void* ){
		if( pBinary ){
			DetourBinaryClose(pBinary);
			pBinary = NULL;
		}
		if( hNew != INVALID_HANDLE_VALUE) {
			CloseHandle(hNew);
			hNew = INVALID_HANDLE_VALUE;
		}
		if( hOld != INVALID_HANDLE_VALUE) {
			CloseHandle(hOld);
			hOld = INVALID_HANDLE_VALUE;
		}
	});
	if( !hxdw_IsWithPathPart( srBackupFName ) ){
		srBackupFName = hxdw_StrPrintf("%a\\%a", {
				hxdw_SplitPath(srTargetPEPathName).first,
				srBackupFName,});
	}
	const std::string srIntrmSuff = hxdw_StrPrintf("%a", { (int64_t)hxdw_GetTimeTicksMs(),} );
	const std::string srOrg = srTargetPEPathName;
	const std::string srNew = hxdw_StrPrintf("%a.%a#", { srTargetPEPathName, srIntrmSuff,});
	const std::string srOld = srBackupFName;//hxdw_StrPrintf("%a.%a.bkp", { srTargetPEPathName, ,});
	if( srBackupFileNameOu ){
		*srBackupFileNameOu = srOld;
	}
	struct SLocalCapture2 {
		std::string srDllBaseNameToAdd2;
		int         nCnt3 = 0;
		bool        bDllAdded = 0L;
		int         nTerminalBywayIdx = 0;
	};
	SLocalCapture2 sLCa;
	sLCa.srDllBaseNameToAdd2 = srDllBaseNameToAdd;

	printf("CID: Input File: [%s]\n", srOrg.c_str() );

	hOld = CreateFileA( srOrg.c_str(),
					   GENERIC_READ,
					   FILE_SHARE_READ,
					   NULL,
					   OPEN_EXISTING,
					   FILE_ATTRIBUTE_NORMAL,
					   NULL);
	if( hOld == INVALID_HANDLE_VALUE) {
		printf("CID: Couldn't open input file: [%s], error: %d\n",
			   srOrg.c_str(), GetLastError());
		bGood = 0L;
		return 0L;
	}
	hNew = CreateFileA( srNew.c_str(),
					   GENERIC_WRITE | GENERIC_READ, 0, NULL, CREATE_ALWAYS,
					   FILE_ATTRIBUTE_NORMAL | FILE_FLAG_SEQUENTIAL_SCAN, NULL);
	if( hNew == INVALID_HANDLE_VALUE) {
		printf("CID: Couldn't open output file: [%s], error: %d\n",
			   srNew.c_str(), GetLastError());
		bGood = 0L;
		return 0L;
	}
	if( (pBinary = DetourBinaryOpen(hOld)) == NULL) {
		printf("CID: DetourBinaryOpen failed: %d\n", GetLastError());
		return 0L;
	}
	if( hOld != INVALID_HANDLE_VALUE) {
		CloseHandle(hOld);
		hOld = INVALID_HANDLE_VALUE;
	}
	{
		if( bResetDll ){
			DetourBinaryResetImports( pBinary );
		}
		{
			bool rs3;
			sLCa.nTerminalBywayIdx = 0;
			rs3 = DetourBinaryEditImports( pBinary, &sLCa,
				[]( PVOID pContext, LPCSTR pszFile, LPCSTR* ppszOutFile )->BOOL{
					SLocalCapture2* sLCa = (SLocalCapture2*) pContext;
					*ppszOutFile = pszFile;
					sLCa->nTerminalBywayIdx += 1;
					return 1L;
				}, nullptr, nullptr, nullptr);
			if( !rs3 ){
				printf("CID: DetourBinaryEditImports failed: %d\n", GetLastError());
				return 0L;
			}
			assert( sLCa.nTerminalBywayIdx > 0 );

			sLCa.nCnt3 = 0;
			rs3 = DetourBinaryEditImports( pBinary, &sLCa,
				[]( PVOID pContext, LPCSTR pszFile, LPCSTR* ppszOutFile )->BOOL{
					SLocalCapture2* sLCa = (SLocalCapture2*) pContext;
					*ppszOutFile = pszFile;
					assert( sLCa->nTerminalBywayIdx > 0 );
					if( sLCa->nCnt3 == sLCa->nTerminalBywayIdx-1 && !sLCa->bDllAdded ){
						assert( !pszFile );
						const char* sz2 = sLCa->srDllBaseNameToAdd2.c_str();
						printf("CID: Adding DLL [%s]\n", sz2 );
						*ppszOutFile = sz2;
						sLCa->bDllAdded = 1L;
					}
					sLCa->nCnt3 += 1;
					return 1L;
				}, nullptr, nullptr, nullptr);
			if( !sLCa.bDllAdded ){
				printf("CID: ERROR: Couldn't add DLL. No empty slot found.\n");
				bGood = 0L;
			}
		}
		if( bGood ){
			if( !DetourBinaryWrite(pBinary, hNew)) {
				printf("CID: DetourBinaryWrite failed: %d\n", GetLastError());
				bGood = 0L;
				//return 0L;
			}
		}
		DetourBinaryClose(pBinary);
		pBinary = nullptr;

		if( hNew != INVALID_HANDLE_VALUE ){
			CloseHandle(hNew);
			hNew = INVALID_HANDLE_VALUE;
		}
		if( bGood ){
			if( !DeleteFileA( srOld.c_str() )) {
				DWORD dwError = GetLastError();
				if (dwError != ERROR_FILE_NOT_FOUND) {
					printf("CID: Warning: Couldn't delete %s: %d\n", srOld.c_str(), dwError);
					bGood = 0L;
				}
			}
			if( !MoveFileA( srOrg.c_str(), srOld.c_str() )) {
				printf("CID: Error: Couldn't back up %s to %s: %d\n",
					   srOrg.c_str(), srOld.c_str(), GetLastError());
				bGood = 0L;
			}
			if( !MoveFileA( srNew.c_str(), srOrg.c_str() )) {
				printf("CID: Error: Couldn't install %s as %s: %d\n",
					   srNew.c_str(), srOrg.c_str(), GetLastError());
				bGood = 0L;
			}
		}
		DeleteFileA( srNew.c_str() );
	}
	return bGood;
}
bool cid_ListPEBinaryImports( std::string srTargetPEPathName, std::string* err_ )
{
	std::string sink0, &err2 = ( err_ ? *err_ : sink0 );
	PDETOUR_BINARY pBinary = NULL;
	std::shared_ptr<void*> raii3( nullptr, [&]( void* ){
		if(pBinary) {
			DetourBinaryClose(pBinary);
			pBinary = NULL;
		}
	});
	{
		HANDLE hOld = INVALID_HANDLE_VALUE;
		std::shared_ptr<void*> raii4( nullptr, [&]( void* ){
			if(hOld != INVALID_HANDLE_VALUE) {
				CloseHandle(hOld);
				hOld = INVALID_HANDLE_VALUE;
			}
		});
		hOld = CreateFileA( srTargetPEPathName.c_str(),
						   GENERIC_READ,
						   FILE_SHARE_READ,
						   NULL,
						   OPEN_EXISTING,
						   FILE_ATTRIBUTE_NORMAL,
						   NULL);
		if( hOld == INVALID_HANDLE_VALUE) {
			printf("CID: Couldn't open input file: %s, error: %d\n",
				   srTargetPEPathName.c_str(), GetLastError());
		}else{
			if( (pBinary = DetourBinaryOpen(hOld)) == NULL) {
				printf("CID: DetourBinaryOpen failed: %d\n", GetLastError());
			}
		}
	}
	if( pBinary ){
		bool rs3;
		rs3 = DetourBinaryEditImports( pBinary,
				0,
				cid_BywayCallback2,
				cid_DetourBinaryFileCallback,
				nullptr,
				nullptr);//*/
	}
	return 1L;
}

bool cid_PerformNewInstall( std::string srPEPathName, const char* szBkpExt, std::string* err2 )
{
	std::string srBackupBName3;
	{
		std::string bn4 = hxdw_SplitPath( srPEPathName ).second;
		std::string fn4 = hxdw_SplitExt( bn4 ).first;
		SYSTEMTIME wct = hxdw_GetWallClockTime();
		char bfr2[32];
		snprintf( bfr2, sizeof(bfr2), "%04d%02d%02d",
				(int)wct.wYear, (int)wct.wMonth, (int)wct.wDay );
		std::string sr8DigDate = bfr2;
		//.bkp:
		srBackupBName3 = hxdw_StrPrintf("%a.%a.%a", {
				fn4,
				sr8DigDate,
				std::string(szBkpExt),});
	}
	assert( !srBackupBName3.empty() );
	//std::string srDll = hxdw_StrPrintf("test_dll_%a.dll", { (size_t)hxdw_GetTimeTicksMs(),});
	std::string srDll = Cid2->srDllToAddName;

	cid_ListPEBinaryImports( srPEPathName, nullptr );
	bool rs2;
	rs2 = cid_AddDLLToPEBinary( srPEPathName, srBackupBName3, srDll, "", nullptr, err2 );
	cid_ListPEBinaryImports( srPEPathName, nullptr );
	return rs2;
}

/// Returns date value or 0 on error.
/// Scans for 8-digit date part, eg. "20211112".
std::pair<int,std::string>
cid_GetBkpFile8DigitDatePart( std::string srFileName )
{
	std::string srDatePart, srFnamePart;
	srDatePart = (hxdw_SplitExt( hxdw_SplitExt( srFileName ).first ).second);
	srFnamePart = (hxdw_SplitExt( hxdw_SplitExt( srFileName ).first ).first);
	if( srDatePart.size() != 8 ){
		return {0,"",};
	}
	if( srFnamePart.empty() ){
		return {0,"",};
	}
	for( size_t ii2=0; ii2 < srDatePart.size(); ii2++ ){
		char ch2 = srDatePart[ii2];
		if( !(ch2 >= '0' && ch2 <= '9') ){
			return {0,"",};
		}
	}
	// got 8-digit date.
	int n8DigitDate2 = std::atoi( srDatePart.c_str() );
	return { n8DigitDate2, srFnamePart,};
}
std::pair<std::string,int>
cid_FindBackupFile( std::string srPEPathName, std::string* err2 )
{
	assert( err2 );
	std::string srDir = hxdw_SplitPath( srPEPathName ).first;
	std::string srBaseName = hxdw_SplitPath( srPEPathName ).second;
	std::string srFileName = hxdw_SplitExt( srBaseName ).first;
	assert( !srDir.empty() );
	assert( !srBaseName.empty() );
	assert( !srFileName.empty() );

	struct SBkpFile {
		std::string first;
		std::string second;
		int         nDatePart = 0;
		std::string srFnameNoDate;
	};
	std::vector<SBkpFile> aBkpFiles;
	{
		std::vector<std::string> fnames2;
		hxdw_GetDirFilesRcv( srDir.c_str(), &fnames2, "f");

		// Backup file format: <filename>.20229999.bkp
		// Find all backup (*.bkp) files.
		for( auto ir2 = fnames2.begin(); ir2 != fnames2.end(); ++ir2 ){
			std::string pathname = *ir2;
			//printf("f:[%s]\n", pathname.c_str() );
			std::string ext2 = hxdw_SplitExt( pathname ).second;
			std::string fn2 = hxdw_SplitPath( pathname ).second;
			if( !hxdw_StrCmpOpt( Cid2->srBkpExt.c_str(), ext2.c_str(), -1, "i" ) ){
				SBkpFile bkf2 = { pathname, fn2,};
				// get 8-digit date part eg. "20211112".
				auto res2 = cid_GetBkpFile8DigitDatePart( fn2 );
				if( res2.first ){
					bkf2.nDatePart     = res2.first;
					bkf2.srFnameNoDate = res2.second;
					bool bIsFBackup = !hxdw_StrCmpOpt( srFileName.c_str(),
							bkf2.srFnameNoDate.c_str(), -1, "i");
					if( bIsFBackup ){
						aBkpFiles.push_back( bkf2 );
					}
				}
			}
		}
	}
	if( aBkpFiles.empty() ){
		*err2 = "No backup files found.";
		return {"",0,};
	}
	int nDateIndex = -1;
	{
		// get file with max date.
		int nMaxDate = 0, ii2 = 0;
		for( auto ir3 = aBkpFiles.begin(); ir3 != aBkpFiles.end(); ++ir3, ii2++ ){
			//printf("f2:[%s]\n", ir3->first.c_str() );
			assert( ir3->nDatePart );
			if( nMaxDate < ir3->nDatePart ){
				nMaxDate = ir3->nDatePart;
				nDateIndex = ii2;
			}
		}
	}
	if( nDateIndex == -1 ){
		*err2 = "No backup files for this executable found.";
		return {"",0,};
	}
	return { aBkpFiles[nDateIndex].first,
					aBkpFiles[nDateIndex].nDatePart,};
}
bool cid_PerformUninstall( std::string srPEPathName, std::string* err2,
		std::function<bool(std::string srPathname, int n8DigitDate )> calbAskRestore )
{
	assert( err2 );
	bool bExists2 = hxdw_FileExists( srPEPathName.c_str() );
	assert( bExists2 );

	auto res2 = cid_FindBackupFile( srPEPathName, err2 );
	if( res2.first.empty() ){
		return 0L;
	}
	std::string srBkpFile = res2.first;
	int nBkpDate2 = res2.second;

	printf("CID: Backup file to use: [%s]\n", srBkpFile.c_str() );
	{
		assert( !!calbAskRestore );
		if( !calbAskRestore( srBkpFile, nBkpDate2 ) ){
			*err2 = "User cancel.";
			return 0L;
		}
	}
	bool bExists3 = hxdw_FileExists( srBkpFile.c_str() );
	assert( bExists3 );
	{
		bool rs2;
		{
			// before delete, try to rename existing exec file first.
			std::string dir3 = hxdw_SplitPath( srPEPathName ).first;
			std::string bn3  = hxdw_SplitPath( srPEPathName ).second;
			std::string fn3  = hxdw_SplitExt( bn3 ).first;
			std::string ext3 = hxdw_SplitExt( bn3 ).second;

			std::string srTestRnFileName;
			srTestRnFileName = hxdw_StrPrintf("%a\\%a.%a.%a", {
					dir3,
					fn3,
					std::to_string( hxdw_GetTimeTicksUs() ),
					ext3,});
			// test rename.
			rs2 = MoveFile( srPEPathName.c_str(), srTestRnFileName.c_str() );
			if( !rs2 ){
				*err2 = "Rename failed [xYylz2]";
				return 0L;
			}
			// rename back.
			rs2 = MoveFile( srTestRnFileName.c_str(), srPEPathName.c_str() );
			if( !rs2 ){
				*err2 = "Rename failed [0CqcU8P]";
				return 0L;
			}
		}{
			// Delete file to the recycle bin.
			SHFILEOPSTRUCT sf2;
			memset( &sf2, 0, sizeof(sf2) );
			char bfr2[MAX_PATH*2];
			memset( bfr2, 0, sizeof(bfr2) );
			snprintf( bfr2, sizeof(bfr2)-2, "%s", srPEPathName.c_str() );
			sf2.pFrom  = bfr2;
			sf2.wFunc  = FO_DELETE;
			sf2.fFlags = FOF_ALLOWUNDO|FOF_NOCONFIRMATION;
			int rs3 = SHFileOperation( &sf2 );
			if( rs3 ){
				*err2 = "File delete failed [7y3k1p3]";
				return 0L;
			}
		}{
			// finally, rename backup-file replacing the exec.
			rs2 = MoveFile( srBkpFile.c_str(), srPEPathName.c_str() );
			if( !rs2 ){
				*err2 = "Rename failed [QFYSP02]";
				return 0L;
			}
		}
	}
	return 1L;
}
/**
	Returns path names of folders that the Valve Steam client
	installs the games in.
	By default, one is in the Program Files directory.
	If there are more, these are are added by the user.

	Gets Steam installation directory from the windows registry
	and reads the "config\libraryfolders.vdf" file.

	REF:
		Find steam games folder, Stack Overflow; tezzo
		https://stackoverflow.com/a/34091380
*/
std::vector<std::string> cid_GetSteamGameFolders()
{
	assert( Cid2 );
	std::vector<std::string> outp;
    // 32-bit: HKEY_LOCAL_MACHINE\SOFTWARE\Valve\Steam
    // 64-bit: HKEY_LOCAL_MACHINE\SOFTWARE\Wow6432Node\Valve\Steam
    // libraryfolders.vdf
    // --> ...\config\libraryfolders.vdf

    const std::vector<std::wstring> aRegKeyNames = {
		L"SOFTWARE\\Wow6432Node\\Valve\\Steam",
		L"SOFTWARE\\Valve\\Steam",
    };
    for( auto ir3 = aRegKeyNames.begin(); ir3 != aRegKeyNames.end(); ++ir3 ){
		const std::wstring srRegSubKey = *ir3;
		const std::wstring srRegVarname = L"InstallPath";
		WCHAR bfr2[MAX_PATH * 2] = {0,};
		DWORD cbData = sizeof(bfr2);// /sizeof(bfr2[0]);

		// RegGetValue, RegGetValueW, RegGetValueA
		LSTATUS rc2 = RegGetValueW(
			HKEY_LOCAL_MACHINE,
			srRegSubKey.c_str(),
			srRegVarname.c_str(),
			RRF_RT_REG_SZ,
			nullptr,
			bfr2,
			&cbData
		);
		if( rc2 != ERROR_SUCCESS ){
			//MessageBox(0, "ERROR: RegGetValueW Failed.", Cid2->srAppName.c_str(), MB_OK|MB_ICONERROR);
			//return {};
			continue;
		}
		std::string srInsPath = hxdw_StrWcsToUtf8a( bfr2, -1 );
		// read "config\libraryfolders.vdf" file.
		std::string srVdfCfgFilename =
			hxdw_StrPrintf( "%a\\config\\libraryfolders.vdf", { srInsPath,} );
		std::vector<std::string> lines2;
		hxdw_GetTextLinesFromFile( srVdfCfgFilename.c_str(), &lines2 );
		if( lines2.empty() ){
			//MessageBox(0, "ERROR: Failed reading VDF file.", Cid2->srAppName.c_str(), MB_OK|MB_ICONERROR);
			//return {};
			continue;
		}
		{
			// "libraryfolders"
			// "0" {"path" "data_a" ... }...
			// "1" {"path" "data_a" ... }...
			bool bGotLibFldrsVar = 0, bGotZeroVar = 0;
			for( auto ir2 = lines2.begin(); ir2 != lines2.end(); ++ir2 ){
				std::string ln2 = *ir2;
				ln2 = hxdw_TrimStr( ln2, "\x20\t\r\n", "L", -1 );
				// Sanity checks on the format of the loaded file contents.
				// Check for "libraryfolders" variable that should be at the top of the text file.
				// Check for the first *zero* list|array. The "0" (incl quotes) variable name.
				if( !bGotLibFldrsVar ){
					bGotLibFldrsVar = !!std::strstr( ln2.c_str(), "libraryfolders" );
					if( !bGotLibFldrsVar ){continue;}
				}
				if( !bGotZeroVar ){
					bGotZeroVar = !!std::strstr( ln2.c_str(), "\x22""0\x22" );
					if( !bGotZeroVar ){continue;}
				}
				// look for the "path" (incl. quotes) variable.
				const std::string needle2 = "\x22""path\x22";
				const char* pos2;
				pos2 = std::strstr( ln2.c_str(), needle2.c_str() );
				if( pos2 ){
					pos2 += needle2.size();
					std::string srGpth = pos2;
					srGpth = hxdw_TrimStr( srGpth, "\x20\t\x22\x27\r\n", "LR", -1 );
					srGpth = hxdw_StrReplace( srGpth, "\\\\", "\\" );
					if( !srGpth.empty() ){
						//srTs2 += hxdw_StrPrintf("[%a]\n", { srGpth, } );
						outp.push_back( srGpth );
					}
				}
			}
		}
	}
	{
		//remove duplicates.
		auto& vec = outp;
		std::sort( vec.begin(), vec.end() );
		vec.erase( std::unique( vec.begin(), vec.end() ), vec.end() );
	}
	{
		// remove any non-existing dirs|folders.
		for( auto ir2 = outp.begin(); ir2 != outp.end(); ){
			if( !hxdw_IsDir( ir2->c_str() ) ){
				ir2 = outp.erase( ir2 );
			}else{
				++ir2;
			}
		}
	/*	std::string srTs2;
		for( auto a : outp ){
			srTs2 += a;
			srTs2 += "\n";
		}
		MessageBox(0, srTs2.c_str(), "Steam Folders",0);//*/
	}
	return outp;
}
std::string cid_GetRE4MainExecutablePath()
{
	auto fldrs2 = cid_GetSteamGameFolders();
	// Check for existence of the bio4.exe file.
	for( auto ir2 = fldrs2.begin(); ir2 != fldrs2.end(); ++ir2 ){
		std::string pth = hxdw_StrPrintf(
			"%a\\steamapps\\common\\Resident Evil 4\\Bin32\\bio4.exe", { *ir2,} );
		if( hxdw_FileExists( pth.c_str() ) ){
			return pth;
		}
	}
	return "";
}

int main( int argc, const char*const* argv )
{
	assert( !Cid2 );
	Cid2 = new CidData;
	std::shared_ptr<void*> raii2( nullptr, [&]( void* ){
		assert( Cid2 );
		delete Cid2;
		Cid2 = nullptr;
	});
	{
		Cid2->srSelfExePathName = (hxdw_SplitPath(
				hxdw_GetCurrentExecutableFilePath() ).first);
		assert( !Cid2->srSelfExePathName.empty() );
		//
		std::string srCfg = hxdw_StrPrintf("%a.%a", {
			(hxdw_SplitExt(
				hxdw_GetCurrentExecutableFilePath()).first),
			Cid2->srCfgFExtName,});  //.dsv
		assert( !srCfg.empty() );
		//printf("CID: Cfg file [%s]\n", srCfg.c_str() );

		// read config file.
		std::vector<std::string> lines2;
		hxdw_GetTextLinesFromFile( srCfg.c_str(), &lines2 );
		// remove any comments ("//" only).
		for( auto ir2 = lines2.begin(); ir2 != lines2.end(); ){
			if( ir2->size() >= 2 && !hxdw_StrCmpOpt("//",ir2->c_str(),2,"") ){
				ir2 = lines2.erase(ir2);
			}else{
				++ir2;
			}
		}
		if( lines2.empty() ){
			MessageBox( 0, "Configuration file not found (or empty).", Cid2->srAppName.c_str(),
				MB_OK|MB_ICONERROR );
			return 109;
		}
		int ii2 = 0;
		for( auto ir2 = lines2.begin(); ir2 != lines2.end(); ++ir2, ii2++ ){
			printf("CID: config line %d: [%s]\n", ii2+1, ir2->c_str() );
		}
		if( lines2.size() < 7 ){
			MessageBox( 0, "Bad configuration [IU4AS6]", Cid2->srAppName.c_str(),
				MB_OK|MB_ICONERROR );
			return 110;
		}
		{
			assert( lines2.size() >= 6 );
			if( lines2[0] != "-" )  //line-1
				Cid2->srAppName = lines2[0];
			if( lines2[1] != "-" )  //line-2
				Cid2->srExtFilter = lines2[1];
			if( lines2[2] != "-" )  //line-3
				Cid2->srBkpExt = lines2[2];
			if( lines2[3] != "-" )  //line-4
				Cid2->srDllToAddName = lines2[3];
			if( lines2[4] != "-" )  //line-5
				Cid2->srRegPEPath = lines2[4];
			if( lines2[5] != "-" )  //line-6
				Cid2->srAssetFiles = lines2[5];
			if( lines2[6] != "-" )  //line-7
				Cid2->eExeDPathMode = lines2[6];
		}
		if( Cid2->srDllToAddName.empty() ){
			MessageBox( 0, "Bad configuration [5sqOIw]", Cid2->srAppName.c_str(),
				MB_OK|MB_ICONERROR );
			return 112;
		}
		{
			hxdw_StrExplode( Cid2->srAssetFiles.c_str(),
				Cid2->aAssetFBNames,
				{";",}, -1, ";\x20", "e");

			for( auto sr5 : Cid2->aAssetFBNames ){
				printf("CID: asset file: [%s]\n", sr5.c_str() );
			}
		}
	}{
		std::string sr2 = hxdw_StrPrintf(
			"%a\n"
			"\n"
			"This program will install or uninstall DLL for a selected executable file.\n"
			"Backup file is created by default.\n"
			"\n"
			"Press OK to continue and proceed to select files.\n"
			"Press Cancel to exit.\n",
			{ Cid2->srAppName,} );
		int rs2 = MessageBox( 0, sr2.c_str(), Cid2->srAppName.c_str(),
			MB_OKCANCEL|MB_ICONINFORMATION );
		if( rs2 != IDOK ){
			return 101;
		}
	}
	if( Cid2->eExeDPathMode == "CID_EDPM_RE4UHD_Steam" ){
		Cid2->srTargetPEPathName = cid_GetRE4MainExecutablePath();
		//MessageBox(0, Cid2->srTargetPEPathName.c_str(), "P",0);
	}
	CID_EIM eInsMode = CID_EIM::CID_EIM_EInstall;
	for( ;; ){
		std::string sr2 = hxdw_StrPrintf(
			"%a - Select an executable file", { Cid2->srAppName,} );
		sr2 = hxdw_OpenFileNameWithUI(
				Cid2->srTargetPEPathName.c_str(),
				sr2.c_str(),
				//"*.EXE;*.DLL",
				Cid2->srExtFilter.c_str(), 0 );
		printf("CID: Selected: [%s]\n", sr2.c_str() );
		bool bNotFound = 0L;
		if( !sr2.empty() && !hxdw_FileExists( sr2.c_str() ) ){
			sr2 = "";
			bNotFound = 1L;
		}
		if( sr2.empty() ){
			sr2 = hxdw_StrPrintf(
				"%a\n"
				"Press OK to select again.\n"
				"Press Cancel to exit.\n",
				{
					std::string(bNotFound ? "File not found." : "Nothing selected."),
				});
			int rs2 = MessageBox( 0, sr2.c_str(), Cid2->srAppName.c_str(),
				MB_OKCANCEL|MB_ICONINFORMATION );
			if( rs2 != IDOK ){
				return 102;
			}
			continue;
		}
		Cid2->srTargetPEPathName = sr2;
		{
			assert( !Cid2->srTargetPEPathName.empty() );
			bool bExists = hxdw_FileExists( Cid2->srTargetPEPathName.c_str() );
			assert( bExists );
			{
				bool bAlreadyInjected = 0;
				std::vector<HxdwEnumImportsDTO> ls2;
				std::string err3;
				bool rs2 = hxdw_GetPEFileImportFunctions(
					Cid2->srTargetPEPathName.c_str(),
					[&](const HxdwEnumImportsDTO& in2)->bool{
						//printf("[%-24s] [%s]\n",
						//	in2.srDllName.c_str(), in2.srFuncName.c_str() );
						//bool cond2 = (in2.srDllName == Cid2->srDllToAddName);
						bool cond2 = !hxdw_StrCmpOpt( in2.srDllName.c_str(), Cid2->srDllToAddName.c_str(), -1, "i");
						if( cond2 ){
							bAlreadyInjected = 1L;
							return 0L;
						}
						return 1L;
					}, "", &err3 );
				if( !rs2 ){
					std::string sr4 = hxdw_StrPrintf(
						"ERROR:\n"
						"[%a]\n"
						"\n"
						"Press OK to select again.\n"
						"Press Cancel to exit.\n", { err3,});
					int rs2 = MessageBox( 0, sr4.c_str(), Cid2->srAppName.c_str(),
						MB_OKCANCEL|MB_ICONWARNING );
					if( rs2 != IDOK ){
						return 105;
					}
					continue;
				}
				if( bAlreadyInjected ){
					assert( eInsMode == CID_EIM::CID_EIM_EInstall );
					eInsMode = CID_EIM::CID_EIM_EUninstall;
				}
			}
		}
		break;
	}
	{
		if( eInsMode == CID_EIM::CID_EIM_EInstall ){
			std::string sr3 = hxdw_StrPrintf(
				"Input executable file verified.\n"
				"\n"
				"Press Yes to apply the patch.\n"
				"Press No to exit.\n", {} );
			int rs2 = MessageBox( 0, sr3.c_str(), Cid2->srAppName.c_str(),
				MB_YESNO|MB_ICONQUESTION );
			if( rs2 != IDYES ){
				return 106;
			}
			std::string err2;
			bool rs5 = cid_PerformNewInstall( Cid2->srTargetPEPathName, Cid2->srBkpExt.c_str(), &err2 );
			if( !rs5 ){
				std::string sr4 = hxdw_StrPrintf(
					"ERROR:\n"
					"Installation failed.\n"
					"\n"
					"%a\n"
					"\n", { err2,} );
				MessageBox( 0, sr4.c_str(), Cid2->srAppName.c_str(),
					MB_OK|MB_ICONERROR );
				return 108;
			}
			if( !Cid2->aAssetFBNames.empty() ){  //srAssetFiles
				auto srDstPath = hxdw_SplitPath(Cid2->srTargetPEPathName).first;
				assert( !srDstPath.empty() );
				for( auto ir2 = Cid2->aAssetFBNames.begin(); ir2 != Cid2->aAssetFBNames.end(); ++ir2 ){
					auto src2 = hxdw_StrPrintf("%a\\%a", { Cid2->srSelfExePathName, *ir2,});
					auto dst2 = hxdw_StrPrintf("%a\\%a", { srDstPath, *ir2,});
					CopyFile( src2.c_str(), dst2.c_str(), !"ovrw" );
				}
			}
			std::string sr4 = hxdw_StrPrintf(
				"Installation complete.\n", {} );
			MessageBox( 0, sr4.c_str(), Cid2->srAppName.c_str(),
				MB_OK|MB_ICONINFORMATION );

		}else if( eInsMode == CID_EIM::CID_EIM_EUninstall ){
			{
				std::string sr3 = hxdw_StrPrintf(
					"Existing installation detected.\n"
					"Input executable is already patched.\n"
					"\n"
					"Press OK to continue.\n", {} );
				int rs2 = MessageBox( 0, sr3.c_str(), Cid2->srAppName.c_str(),
					MB_OK|MB_ICONINFORMATION );
			}{
				std::string sr3 = hxdw_StrPrintf(
					"QUESTION:\n"
					"Do you want to uninstall by searching for a backup file?\n"
					"\n"
					"Press Yes to continue and try to perform uninstall.\n"
					"Press No to exit.\n", {} );
				int rs2 = MessageBox( 0, sr3.c_str(), Cid2->srAppName.c_str(),
					MB_OKCANCEL|MB_ICONQUESTION|MB_DEFBUTTON2 );
				if( rs2 != IDOK ){
					return 107;
				}
				std::string err2;
				bool rs5 = cid_PerformUninstall( Cid2->srTargetPEPathName, &err2, [](std::string, int n8DigitDate)->bool{
					std::string sr4 = hxdw_StrPrintf(
						"Backup file found.\n"
						"\n"
						"Date: %a\n"
						"\n"
						"Press OK to continue.\n", { n8DigitDate,});
					int rs2 = MessageBox( 0, sr4.c_str(), Cid2->srAppName.c_str(),
						MB_OKCANCEL|MB_ICONQUESTION );
					return rs2 == IDOK;
				});
				if( !rs5 ){
					std::string sr4 = hxdw_StrPrintf(
						"ERROR:\n"
						"Couldn't restore backup file.\n"
						"\n"
						"%a\n"
						"\n"
						"Press OK to exit.\n", { err2,} );
					MessageBox( 0, sr4.c_str(), Cid2->srAppName.c_str(),
						MB_OK|MB_ICONERROR );
					return 113;
				}

				if( !Cid2->aAssetFBNames.empty() ){  //srAssetFiles
					auto srDstPath = hxdw_SplitPath(Cid2->srTargetPEPathName).first;
					assert( !srDstPath.empty() );
					for( auto ir2 = Cid2->aAssetFBNames.begin(); ir2 != Cid2->aAssetFBNames.end(); ++ir2 ){
						auto path2 = hxdw_StrPrintf("%a\\%a", { srDstPath, *ir2,});
						bool ok2 = !!DeleteFile( path2.c_str() );
						printf("CID: File delete: %s [%s]\n", (ok2 ? "OK" : "FAILED"), path2.c_str() );
					}
				}
				{
					std::string sr4 = hxdw_StrPrintf(
						"Uninstall complete.\n", {} );
					MessageBox( 0, sr4.c_str(), Cid2->srAppName.c_str(),
						MB_OK|MB_ICONINFORMATION );
				}
			}
		}else{
			assert( 0 && "This path is unexpected [s3UzU6]");
		}
	}
    return 0;
}


