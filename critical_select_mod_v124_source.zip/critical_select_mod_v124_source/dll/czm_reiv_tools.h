#pragma once
#include <string>
#include <vector>
#include "czm_interfaces.h"
struct CzmPickupDTO;

CzmRE4Vec   czm_ConvRE4SvecToPos( const CzmRE4Svec& vec16 );
CzmRE4Svec  czm_ConvPosToRE4Svec( const CzmRE4Vec& vec );
CzmRE4Vec   czm_ConvRE4SvecToRotation( const CzmRE4Svec& vec16 );
CzmRE4Svec  czm_ConvRotationToRE4Svec( const CzmRE4Vec& vec );
CzmRE4Vec   czm_Vec3Rotate3( const CzmRE4Vec& vc0, const CzmRE4Vec& vra, float fAngle );
CzmRE4Vec   czm_Vec3Normalize3( const CzmRE4Vec& vec0 );
double      czm_Pi();
float       czm_GetRE4LeonHeight();
auto        czm_GetRE4ForwardNormal() -> const CzmRE4Vec&;
auto        czm_GetRE4UpwardNormal() -> const CzmRE4Vec&;
CzmRE4Vec   czm_GetCurrentForwardNormal( CzmRE4Vec* pRotationOut = nullptr, CzmRE4Svec* pRttn16Out = nullptr );
double      czm_GetRE4RotationFactor();
uint32_t    czm_CallMemberFuncViaEcx( void* thisptr2, void* fnc2, uint32_t* pArgs, uint32_t nNumArgs );
std::string czm_GetWeaponTypeName2( CZM_EWT, bool bGetAsEnum );
auto        czm_GetWeaponTypeByIndex( size_t index2 ) -> CzmPair<bool,CZM_EWT>;
size_t      czm_GetWeaponTypeCount();
auto        czm_GetWeaponGroupTypeWeapons( CZM_EWGR eWpnGrTy ) -> std::vector<CZM_EWT>;
auto        czm_CnvWeaponTypeIndexesToTypes( const std::vector<int>& inp ) -> std::vector<CZM_EWT>;
std::string czm_RE4EnemyToStr( const CzmRE4Enemy* inp );
CzmRE4Vec   czm_GetCommonRelativePos( CZM_ECmRelPos eCrp, CzmRE4Svec* pPos16Out, CzmRE4Vec* pRotationOut, CzmRE4Svec* pRttn16Out );
bool        czm_IsRE4GoldItemType( uint32_t uItemType, double* fScaling );
int         czm_GetRE4GoldPickupPesetasValue( uint32_t uItemType_, uint32_t nAmount );
void        czm_RE4EnumerateItemPickups( std::function<void(const CzmPickupDTO&)> calb2 );
auto        czm_CreateLiveRE4TestItem() -> CzmPair<uint8_t,CzmRE4SceAtDataItem*>;
bool        czm_DeleteLiveRE4Item( uint8_t uItemIdent );

/// Struct for enumerating enemies with CzmEnemyFactory::enumerateEnemyList().
struct CzmEnmDTO{
	CzmRE4Enemy* pEnm4 = nullptr;
	bool*        bBreak2 = nullptr;
};

struct CzmPickupDTO{
	CzmRE4SceAtDataItem* pItem = nullptr;
	bool* bBreak3 = nullptr;
};

/// Adds or removes live enemies in the game.
struct CzmEnemyFactory{
	CzmEnemyFactory();
	uint32_t createLiveEnemy2( const CzmRE4EmList& inp );
	void     destroyLastLiveEnemy2();
	bool     enumerateEnemyList( std::function<void( const CzmEnmDTO& inp )> calb2, const char* flags2 );
	void     frameMoveEnmFactory();
private:
	CzmEnemyFactory( const CzmEnemyFactory& otherr ) = delete;
	void operator=( const CzmEnemyFactory& otherr ) = delete;
	CzmRE4Enemy* callCManagerCreate( void* fnRE4CManagerCreate2, void** ppEmMgr2, uint32_t uTypeId );
	bool destroyEnemyByIndex9( size_t index2 );
private:
	struct SOwnEnm {
		CzmRE4Enemy* pEnm5 = nullptr;
		uint32_t nEnmId = 0;
	};
	void* fnRE4CManagerCreate = nullptr;
	void* fnRE4CManagerDeleteList = nullptr;
	void* fnRE4KillEm = nullptr;
	CzmRE4EnmyMgr* pEmMgr = nullptr;
	std::vector<SOwnEnm> mEnmLs;
	uint32_t uNextEnmId = 1;
	std::vector<size_t> aDelListByIndex;
	std::vector<size_t> aAddListByType;
};
struct CzmLivePickupInspector {
	void protectItemsFromAutoDelExcept( uint8_t uUidItemToSkip );
	void restoreItemStates();
private:
	// unk_uid_u8_36 : uint8_t
	// position_vec_5C : CzmRE4Vec
	struct SSnpsht{
		uint8_t   uItmUid3;
		CzmRE4Vec vPosOrig;
		uint8_t   uFlagsXOrig;
		CzmRE4SceAtDataItem* mPtr2 = nullptr;
	};
	struct ByUidVec {
		CzmRE4SceAtDataItem* mPtr = nullptr;
		ByUidVec( CzmRE4SceAtDataItem* ptr_ );
		ByUidVec() = delete;
		bool operator()( const SSnpsht& inp )const;
	};
	std::vector<SSnpsht> aISnapshot;
	int mUidItemToSkip = -1;
};


