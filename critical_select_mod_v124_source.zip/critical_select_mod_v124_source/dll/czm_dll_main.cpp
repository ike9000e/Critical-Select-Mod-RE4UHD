#include "czm_dll_main.h"
#include <cctype>  //std::tolower()
#include <xinput.h>   //XInputGetState()
#include "hxdw_process.h"
#include "czm_gui.h"

BOOL WINAPI DllMain( HINSTANCE hInst, DWORD dwReason, LPVOID );
extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam );

// extern in the .h file.
CzmData* Czm = nullptr;

int dll_dummy_u7bm84pn2()
{
	return 51;
}
bool czm_CreatedNewD3d9Device( const CzmCrNewDevDTO& inp )
{
	hxdw_StdPrint2("CZM: czm_CreatedNewD3d9Device()\n");
	//std::call_once()
	assert( !Czm->pD3d9Device2 );
	Czm->pD3d9Device2 = inp.pD3d9Device;
	{
		assert( !Czm->hwMain );
		HWND hw2 = hxdw_FindMainWindowGivenPID( 0, "" );
		assert( hw2 );
		Czm->hwMain = hw2;

		bool rs2 = ImGui_ImplWin32_Init( hw2 );
		assert( rs2 );
	}{
		assert( inp.pD3d9Device );
		bool rs2 = ImGui_ImplDX9_Init( inp.pD3d9Device );
		assert( rs2 );
	}
	return 1L;
}
bool czm_DeleteD3d9Device( const CzmCrNewDevDTO& inp )
{
	hxdw_StdPrint2("CZM: czm_DeleteD3d9Device()\n");
	//MessageBox(0,"CZM: czm_DeleteD3d9Device()","",0);
	return 1L;
}
bool czm_BeginSceneA( const CzmCrNewDevDTO& inp )
{
	assert( Czm );
	ImGui_ImplDX9_NewFrame();
	ImGui_ImplWin32_NewFrame();
	{
		// check for rez change, based on ImGuiViewport::WorkSize.
		const ImVec2 dmn2 = ImGui::GetMainViewport()->WorkSize;
		bool bRezChngd = (
			dmn2.x != static_cast<float>(Czm->aCurrentRez[0]) ||
			dmn2.y != static_cast<float>(Czm->aCurrentRez[1])
		);
		if( bRezChngd ){
			std::array<int,2> aOldRez = Czm->aCurrentRez;
			std::array<int,2> aNewRez = {
				static_cast<int>(dmn2.x),
				static_cast<int>(dmn2.y),};
			Czm->aCurrentRez = aNewRez;
			czm_ScreenResolutionChanged( aOldRez, aNewRez );
		}
	}
	ImGuiIO& io4 = ImGui::GetIO();
	if( Czm->bUIOpened || +Czm->bShowToolWindow ){
		//GetAsyncKeyState
		bool bDn = !!(0x8000 & GetKeyState( VK_LBUTTON ));
		io4.AddMouseButtonEvent( 0, bDn );
		io4.MouseDrawCursor = 1L;
	}else{
		io4.MouseDrawCursor = 0L;
	}
	ImGui::NewFrame();

	if( Czm->bUIOpened || Czm->se3.bShowLogWindow || Czm->bShowStartupTip || *Czm->bShowToolWindow ){
		czm_SetupSceneUIElements();
	}
	ImGui::EndFrame();
	return 1L;
}
bool czm_BeginSceneB( const CzmCrNewDevDTO& inp )
{
	return 1L;
}
bool czm_EndSceneA( const CzmCrNewDevDTO& inp )
{
	if( Czm->bUIOpened || Czm->se3.bShowLogWindow || Czm->bShowStartupTip || *Czm->bShowToolWindow ){
		ImGui::Render();
		ImGui_ImplDX9_RenderDrawData( ImGui::GetDrawData() );
	}
	return 1L;
}
BOOL czm_PeekMessageOutline( const CzmPkMsgArgs& sArgs,
		std::function<BOOL( const CzmPkMsgArgs& )> calb2 )
{
	MSG* msg = sArgs.msg;
	HWND hw2 = sArgs.hw2;

	assert( Czm );
	ImGuiIO& io3 = ImGui::GetIO();
	CzmPkMsgArgs sArgs2 = sArgs;

	BOOL bHasMsg = calb2( sArgs2 );
	if( bHasMsg ){
		if( msg->message == WM_KEYDOWN ){
			assert( Czm->anUIKeySuite.size() >= 1 ); //eg. VK_F5
			if( czm_TestHotKeyOnKeyDownMessage( Czm->anUIKeySuite, int(msg->wParam) ) ){
				if( !czm_AnySystemModkeyDown( Czm->anUIKeySuite ) ){
					Czm->bUIOpened = !Czm->bUIOpened;
					double tm2 = ImGui::GetTime();
					czm_Print2("CZM: UI Toggled: Show:%a. Time: %a\n", { (int)Czm->bUIOpened, std::to_string(tm2),} );
					memset( msg, 0, sizeof(*msg) );
					return 0L;
				}
			}
		}
		//if( msg->message == WM_KEYDOWN && msg->wParam == VK_F6 ){
		//	auto dmn3 = ImGui::GetMainViewport()->WorkSize;
		//	Czm->addLog3( "CZM: wnd size4: %a*%a", { (int)dmn3.x, (int)dmn3.y,} );
		//}
		//if( msg->message == WM_KEYDOWN && msg->wParam == VK_F7 ){
		//	io3.AddMouseWheelEvent( 0, 1.0f );
		//}
		//if( msg->message == WM_KEYDOWN && msg->wParam == VK_F8 ){
		//	io3.AddMouseWheelEvent( 0, -1.0f );
		//}
	}
	if( bHasMsg && (Czm->bUIOpened || +Czm->bShowToolWindow) ){
		switch( msg->message ){
		case WM_INPUT:{
				// WM_INPUT includes mouse move that is alt. to the WM_MOUSEMOVE.
				RAWINPUT ri3; UINT size2;
				memset( &ri3, 0, sizeof(ri3) );
				UINT rs4;
				rs4 = GetRawInputData(
					(HRAWINPUT)msg->lParam,
						RID_INPUT,  //RID_HEADER
						&ri3, &size2, sizeof(RAWINPUTHEADER) );
				if( rs4 && ri3.header.dwType == RIM_TYPEMOUSE ){
					if( ri3.data.mouse.usButtonFlags & RI_MOUSE_WHEEL ){  //RI_HMOUSE_WHEEL
						SHORT nMDeltaFix = (SHORT)ri3.data.mouse.usButtonData;
						//static int cnt = 0;
						//Czm->addLog3( "CZM: RI_MOUSE_WHEEL. %a, c:%a", { (int)nMDeltaFix, cnt,} );
						if( nMDeltaFix > 0 ){
							io3.AddMouseWheelEvent( 0, 1.0f );
						}else if( nMDeltaFix < 0 ){
							io3.AddMouseWheelEvent( 0, -1.0f );
						}
						memset( msg, 0, sizeof(*msg) );
						return 0L;
					}
				}
			//	bool rs3 = !!ImGui_ImplWin32_WndProcHandler( hw2, msg->message, msg->wParam, msg->lParam );
			//	if(rs3){return 0L;}
			//	if( io3.WantCaptureMouse || io3.NavActive ){
			//		memset( msg, 0, sizeof(*msg) );
			//		return 0L;
			//	}
				memset( msg, 0, sizeof(*msg) );
				return 0L;
			}break;
		case WM_LBUTTONDOWN:
		case WM_LBUTTONUP:
		case WM_LBUTTONDBLCLK:
		case WM_MOUSEWHEEL:
			if( io3.WantCaptureMouse || io3.NavActive ){
				memset( msg, 0, sizeof(*msg) );
				return 0L;
			}else{
				bool rs3 = !!ImGui_ImplWin32_WndProcHandler( hw2, msg->message, msg->wParam, msg->lParam );
				if(rs3){}
			}

			break;
		//case WM_MOUSEWHEEL:
		//	assert(000);
		//	break;
		case WM_NCMOUSEMOVE:
		case WM_MOUSEMOVE:
			if( io3.WantSetMousePos || io3.WantCaptureMouse || io3.NavActive ){
				memset( msg, 0, sizeof(*msg) );
				return 0L;
			}
			break;
		case WM_KEYDOWN:
		case WM_KEYUP:{
				int nVirtKey = (int) msg->wParam;    // virtual-key code
				bool bDn = msg->message == WM_KEYDOWN;
				if( nVirtKey == VK_BACK && bDn ){
					io3.AddKeyEvent( ImGuiKey_Backspace, 1L );
					io3.AddKeyEvent( ImGuiKey_Backspace, 0L );
					return 0L;
				}
				UINT uChr = MapVirtualKey( nVirtKey, 2 );
				if( uChr > 0x20 ){
					char ch2 = char( uChr & 0xFF );
					if( ch2 && bDn ){
						char ch3 = (char)std::tolower( ch2 );
						if( ch3 != ch2 ){
							//GetAsyncKeyState
							if( 0x8000 & GetKeyState(VK_SHIFT) ){
								ch3 = ch2;  // back to uppercse, eg. a to A.
							}
						}
						io3.AddInputCharacter( ch3 );
						return 0L;
					}
				}
				bool rs3 = !!ImGui_ImplWin32_WndProcHandler( hw2, msg->message, msg->wParam, msg->lParam );
				if(rs3){return 0L;}
				if( io3.WantCaptureKeyboard || io3.WantCaptureMouse || io3.NavActive ){
					memset( msg, 0, sizeof(*msg) );
					return 0L;
				}
			}break;
	//	case WM_CHAR:{
	//			static int cnt = 0;
	//			Czm->addLog3( "WM_CHAR, %d\n", { cnt++,} );
	//			memset( msg, 0, sizeof(*msg) );
	//			return 0L;
	//		}break;
		}
	}
	return bHasMsg;
}
// PeekMessageA,PeekMessageW,PeekMessage
BOOL __stdcall czm_PeekMessageW( MSG* msg, HWND hw2, UINT wMsgFilterMin, UINT wMsgFilterMax, UINT wRemoveMsg )
{
	assert( Czm );
	assert( Czm->fnOgPeekMessageW );
	BOOL rs2 = 0;
	rs2 = czm_PeekMessageOutline(
		CzmPkMsgArgs{ msg, hw2, wMsgFilterMin, wMsgFilterMax, wRemoveMsg,},
		[]( const CzmPkMsgArgs& a )->BOOL{
			using fn_t = decltype(czm_PeekMessageW)*;
			BOOL rs3 = ((fn_t)Czm->fnOgPeekMessageW)(
				a.msg, a.hw2, a.wMsgFilterMin, a.wMsgFilterMax, a.wRemoveMsg );
			return rs3;
		}
	);
	return rs2;
}
// PeekMessageA,PeekMessageW,PeekMessage
BOOL __stdcall czm_PeekMessageA( MSG* msg, HWND hw2, UINT wMsgFilterMin, UINT wMsgFilterMax, UINT wRemoveMsg )
{
	assert( Czm );
	assert( Czm->fnOgPeekMessageA );
	BOOL rs2 = 0;
	rs2 = czm_PeekMessageOutline(
		CzmPkMsgArgs{ msg, hw2, wMsgFilterMin, wMsgFilterMax, wRemoveMsg,},
		[]( const CzmPkMsgArgs& a )->BOOL{
			using fn_t = decltype(czm_PeekMessageA)*;
			BOOL rs3 = ((fn_t)Czm->fnOgPeekMessageA)(
				a.msg, a.hw2, a.wMsgFilterMin, a.wMsgFilterMax, a.wRemoveMsg );
			return rs3;
		}
	);
	return rs2;
}

BOOL WINAPI DllMain( HINSTANCE, DWORD dwReason, LPVOID )
{
	switch( dwReason ){
	case DLL_PROCESS_ATTACH:{
			if( MH_Initialize() ){
				assert(!"CZM: ERROR: MH_Initialize() failed [gmcD2Dk]\n");
			}
			assert( !Czm );
			Czm = new CzmData;
			czm_UpdateFromConfigFile();
			czm_Print2("CZM: DLL_PROCESS_ATTACH. PID:%a\n", { std::to_string((size_t)GetCurrentProcessId()), } );
			if( Czm->bStayDormant ){
				return 1L;
			}
			if( Czm->bAllocConsoleFlag ){
				AllocConsole();
			}
			{
				//Czm->ppGD = (CzmRE4GlobDt**)hxdw_GetPtrGivenInSectionOffset( 0, nullptr, ".data", 0x13F3C );
			}
			{
				assert( !Czm->pImGuiCtx );
				Czm->pImGuiCtx = ImGui::CreateContext();
				//
				ImGuiIO& io2 = ImGui::GetIO();
				io2.MouseDrawCursor = 1L;
				io2.ConfigWindowsMoveFromTitleBarOnly = 1L;
				io2.ConfigWindowsResizeFromEdges = 1L;
				io2.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;
				io2.IniFilename = nullptr;
				ImGui::StyleColorsDark();
			}
			int rs2 = czm_Init_D3d9Detour();
			assert(!rs2);
			uint32_t rs3 = czm_Win32DetoursInit();
			if( rs3 ){
				czm_Print2("CZM: ERROR: code: %a\n", { rs3,} );
				//MessageBox(0,"ERROR","ERROR",0);
			}
			assert(!rs3);
			uint32_t rs4 = czm_GpHaxInit();
			assert(!rs4);
			czm_UpdateSettingsViaCallbacks( Czm->se3, Czm->se3, 1L );
		}
		break;
	case DLL_PROCESS_DETACH:{
			//return czm_DllDeInit();
		}
		break;
	}
	return 1L;
}
/**
	Deinitializes the Mod DLL.
	Formerly called in DllMain() with DLL_PROCESS_DETACH message,
	but it turned out it needed to be called earlier
	(during the process termination chain).
	Reason being the call to ImGui_ImplDX9_Shutdown().
	It has been failing by terminating the process (in undetermined way).

	Current implementation calls this function just before the call
	to Winapi ExitProcess().
*/
bool czm_DllDeInit()
{
	assert( Czm );
	if( Czm->bStayDormant ){
		return 1L;
	}
	{
		uint32_t rs2 = czm_GpHaxDeinit();
		assert(!rs2);
		rs2 = czm_Win32DetoursDeinit();
		assert(!rs2);
	}
	ImGui_ImplDX9_Shutdown();  //ImGui_ImplDX9_Init()
	ImGui_ImplWin32_Shutdown();  //ImGui_ImplWin32_Init()
	assert( Czm->pImGuiCtx );
	ImGui::DestroyContext( Czm->pImGuiCtx );
	Czm->pImGuiCtx = nullptr;
	//
	delete Czm;
	Czm = nullptr;
	MH_Uninitialize();
	return 1L;
}

bool czm_ScreenResolutionChanged( std::array<int,2> aOldRez, std::array<int,2> aNewRez )
{
	assert( Czm );
	{
		std::string sr3 = hxdw_StrPrintf( "Screen resolution change detected. New: %a*%a", {
				Czm->aCurrentRez[0], Czm->aCurrentRez[1],} );
		czm_Print2(  (std::string("CZM: ")+sr3+"\n").c_str(), {} );
		Czm->addLog3( sr3.c_str(), {} );
	}{
		Czm->cLogWndGmtr->onRezChange( aOldRez, aNewRez );
		Czm->cSettingsWndGmtr->onRezChange( aOldRez, aNewRez );
	}
	return 1L;
}


