#pragma once
#include <string>
#include <vector>
#include <array>
#include <inttypes.h>
#include "hxdw_utils.h"
#include "czm_reflection.h"

struct CzmSettings;

void czm_SetupSceneUIElements();
void czm_UpdateSettingsViaCallbacks( const CzmSettings& a, const CzmSettings& b, bool bAll );
void czm_ProcessUIKey( uint16_t nXInputButtons );
void czm_CreateWeaponTypeUIItems( std::string* srIoWpnFlags );

struct CzmWndGeomMgr {
	CzmWndGeomMgr() = default;
	CzmWndGeomMgr( std::array<float,4> aDflt );
	void        updateOnWindowBegin();
	void        updateOnWindowEnd();
	static auto getWindowGeometry() -> std::array<int,4>;
	static auto getWindowFGeometry() -> std::array<float,4>;
	std::string serialize2()const;
	void        deserialize2( const char* inp );
	void        onRezChange( std::array<int,2> aOldRez, std::array<int,2> aNewRez );
private:
	std::array<int,4>   aNXywh = { 128, 92, 400, 300,};
	std::array<float,4> aFXywh = { 0.1f, 0.1f, 0.8f, 0.8f,};
	bool bNeedGmtryUpdate = 0L;
};

struct CzmSettings{
	WPP_OBJECT_NAME_METHOD(CzmSettings)
	WPP_REFLECT(
		(bool) bCritDmgScale ,
		(float) fCritDmgScale2,
		(std::string) srWpnCheckFlags4,

		(bool) bCutscSkip2,
		(bool) bDeltaCutscSkip,
		(bool) bDelLagoKO,
		(bool) bYclAb,
		(bool) bMrchWASkip,

		(bool) bPlagasOvr,
		(int) nPrsChance,
		(bool) bPrsSpwNoLimit,
		(bool) bNoTypeCParasite,
		(bool) bNoParasiteChOne, //bAllowPrsChOne

		(uint64_t) uShowEnmStats,
		(bool) bGoldAutoPickup,
		(bool) bShowLogWindow,

		(int) placeholder0_
	)
	CzmSettings();
	bool          equalsWith( const CzmSettings& )const;
	hxdw_IniData2 serialize3()const;
	bool          deserialize3( const hxdw_IniData2& inp );
};
