#include "czm_gui.h"
#include <assert.h>
#include <xinput.h>   //XInputGetState()
#include "imgui.h"
#include "fp_fat32.h"   //FpDiskImage
#include "czm_utils.h"
#include "czm_reiv_tools.h"

CzmWndGeomMgr::CzmWndGeomMgr( std::array<float,4> aDflt )
	: aFXywh( aDflt )
{
}
std::string CzmWndGeomMgr::serialize2()const
{
	char bfr2[256];
	std::snprintf( bfr2, sizeof(bfr2),
			"%d,%d,%d,%d,%f,%f,%f,%f",
			aNXywh[0], aNXywh[1],
			aNXywh[2], aNXywh[3],
			aFXywh[0], aFXywh[1],
			aFXywh[2], aFXywh[3]);
	return bfr2;
}
void CzmWndGeomMgr::deserialize2( const char* inp )
{
	{
		const char* sz2 = inp;
		size_t num = 0;
		for(; (sz2 = std::strchr(sz2,',')); sz2 += 1, num += 1 ){}
		assert( (num == 7 || num == 8) && "Number of commas in the input string missmatch [SqPR0n]" );
	}
	std::sscanf( inp, "%d,%d,%d,%d,%f,%f,%f,%f",
		&aNXywh[0], &aNXywh[1],
		&aNXywh[2], &aNXywh[3],
		&aFXywh[0], &aFXywh[1],
		&aFXywh[2], &aFXywh[3]);
}
std::array<int,4> CzmWndGeomMgr::getWindowGeometry()
{
	ImVec2 xy2 = ImGui::GetWindowPos();
	ImVec2 wh2 = ImGui::GetWindowSize();
	std::array<int,4> outp = {
		int(xy2.x), int(xy2.y),
		int(wh2.x), int(wh2.y),};
	return outp;
}
std::array<float,4> CzmWndGeomMgr::getWindowFGeometry()
{
	const auto gmtr2 = getWindowGeometry();
	const ImVec2 dmn4 = ImGui::GetMainViewport()->WorkSize;
	std::array<float,4> out2 = {
		gmtr2[0] / dmn4.x, gmtr2[1] / dmn4.y,
		gmtr2[2] / dmn4.x, gmtr2[3] / dmn4.y,};
	return out2;
}
void CzmWndGeomMgr::updateOnWindowBegin()
{
	if( bNeedGmtryUpdate ){
		ImVec2 xyPos = ImVec2( (float)aNXywh[0], (float)aNXywh[1] );
		ImVec2 whSize = ImVec2( (float)aNXywh[2], (float)aNXywh[3] );
		ImGui::SetWindowPos( xyPos );
		ImGui::SetWindowSize( whSize );
		bNeedGmtryUpdate = 0L;
	}
}
void CzmWndGeomMgr::updateOnWindowEnd()
{
	if( ImGui::IsMouseDown( ImGuiMouseButton_Left ) ){
		aNXywh = getWindowGeometry();
	}
}
void CzmWndGeomMgr::onRezChange( std::array<int,2> aOldRez, std::array<int,2> aNewRez )
{
	std::array<float,4> fracs2 = aFXywh;
	if( aOldRez[0] && aOldRez[1] ){
		fracs2 = {
			float( double(aNXywh[0]) / aOldRez[0] ),
			float( double(aNXywh[1]) / aOldRez[1] ),
			float( double(aNXywh[2]) / aOldRez[0] ),
			float( double(aNXywh[3]) / aOldRez[1] ),
		};
	}
	aNXywh = {
		int( fracs2[0] * aNewRez[0] ),
		int( fracs2[1] * aNewRez[1] ),
		int( fracs2[2] * aNewRez[0] ),
		int( fracs2[3] * aNewRez[1] ),
	};
	bNeedGmtryUpdate = 1L;
}
void czm_UpdateSettingsViaCallbacks( const CzmSettings& seNew, const CzmSettings& seOld, bool bAll )
{
	const CzmSettings& snw = seNew, &sbb = seOld;
	if( snw.bCritDmgScale != sbb.bCritDmgScale || snw.fCritDmgScale2 != sbb.fCritDmgScale2 || bAll ){
		czm_EachHotPred2( [&]( const CzmEachHPatchDTO& in2){
			in2.hp3->setCriticalDamageScale( snw.bCritDmgScale ? snw.fCritDmgScale2 : 1.f );
		});
	}
	if( snw.bCutscSkip2 != sbb.bCutscSkip2 || bAll ){
		czm_EachHotPred2( [&]( const CzmEachHPatchDTO& in2){
			in2.hp3->setCutsceneSkipEnabled( snw.bCutscSkip2 );
		});
	}
	if( snw.bDeltaCutscSkip != sbb.bDeltaCutscSkip || bAll ){
		czm_EachHotPred2( [&]( const CzmEachHPatchDTO& in2){
			in2.hp3->setCutsceneDeltaSkipable( snw.bDeltaCutscSkip );
		});
	}
	if( snw.bDelLagoKO != sbb.bDelLagoKO || bAll ){
		czm_EachHotPred2( [&]( const CzmEachHPatchDTO& in2){
			in2.hp3->setDelLagoInstaKO( snw.bDelLagoKO );
		});
	}
	if( snw.bYclAb != sbb.bYclAb || bAll ){
		czm_EachHotPred2( [&]( const CzmEachHPatchDTO& in2){
			in2.hp3->setCanLeaveAshleyBehind( snw.bYclAb );
		});
	}
	if( snw.bMrchWASkip != sbb.bMrchWASkip || bAll ){
		czm_EachHotPred2( [&]( const CzmEachHPatchDTO& in2){
			in2.hp3->setMerchantWelcomeAnimSkip( snw.bMrchWASkip );
		});
	}
	if( snw.bPlagasOvr != sbb.bPlagasOvr || bAll ){
		czm_EachHotPred2( [&]( const CzmEachHPatchDTO& in2){
			in2.hp3->setParasiteSpawnManipEnabled( snw.bPlagasOvr );
		});
	}
	if( snw.nPrsChance != sbb.nPrsChance || bAll ){
		float fPrsChance = float(float(snw.nPrsChance) / 100.f);
		czm_EachHotPred2( [&]( const CzmEachHPatchDTO& in2){
			in2.hp3->setParasiteSpawnChance( fPrsChance );
		});
	}
	if( snw.bPrsSpwNoLimit != sbb.bPrsSpwNoLimit || bAll ){
		czm_EachHotPred2( [&]( const CzmEachHPatchDTO& in2){
			in2.hp3->setParasiteSpawnNoLimit( snw.bPrsSpwNoLimit );
		});
	}
	if( snw.bNoTypeCParasite != sbb.bNoTypeCParasite || bAll ){
		czm_EachHotPred2( [&]( const CzmEachHPatchDTO& in2){
			in2.hp3->setDisableTypeCParasite( snw.bNoTypeCParasite );
		});
	}
	if( snw.bNoParasiteChOne != sbb.bNoParasiteChOne || bAll ){
		czm_EachHotPred2( [&]( const CzmEachHPatchDTO& in2){
			in2.hp3->setNoParasiteInIntialChapters( snw.bNoParasiteChOne );
		});
	}
	if( snw.uShowEnmStats != sbb.uShowEnmStats || bAll ){
		czm_EachHotPred2( [&]( const CzmEachHPatchDTO& in2){
			//in2.hp3->setEnemyStatsEnabled( );
			in2.hp3->setEnemyStatsEnabled( !!snw.uShowEnmStats );
		});
	}
	if( snw.srWpnCheckFlags4 != sbb.srWpnCheckFlags4 || bAll ){
		std::vector<int> aWpnCheckFlags3;
		aWpnCheckFlags3.resize( snw.srWpnCheckFlags4.size(), 0L );
		std::transform( snw.srWpnCheckFlags4.begin(), snw.srWpnCheckFlags4.end(), aWpnCheckFlags3.begin(),
				[]( char a )->int{ return a == 'x'; });
		auto ls2 = czm_CnvWeaponTypeIndexesToTypes( aWpnCheckFlags3 );
		czm_EachHotPred2( [&ls2]( const CzmEachHPatchDTO& in2){
			in2.hp3->setAlterableDamageTypes( ls2 );
		});
	}
	if( snw.bGoldAutoPickup != sbb.bGoldAutoPickup || bAll ){
		czm_EachHotPred2( [&]( const CzmEachHPatchDTO& in2){
			in2.hp3->setEnableGoldAutoPickup( snw.bGoldAutoPickup );
		});
	}
	//snw.bShowLogWindow
}
CzmSettings::CzmSettings()
	: placeholder0_(0)
{
	bCritDmgScale = 0L;
	fCritDmgScale2 = 1.f;
	srWpnCheckFlags4 = "---";

	bCutscSkip2 = 0L;
	bDeltaCutscSkip = 0L;
	bDelLagoKO = 0L;
	bYclAb = 0L;
	bMrchWASkip = 0L;

	bPlagasOvr = 0L;
	nPrsChance = 50;
	bPrsSpwNoLimit = 0L;
	bNoTypeCParasite = 0L;
	bNoParasiteChOne = 0L;
	uShowEnmStats = 0;
	bGoldAutoPickup = 0L;
	bShowLogWindow = 0L;
}
bool CzmSettings::equalsWith( const CzmSettings& otherr )const
{
	bool rs2;
	rs2 = ( this->serialize3().getAsString() == otherr.serialize3().getAsString() );
	return rs2;
}
hxdw_IniData2 CzmSettings::serialize3()const
{
	hxdw_IniData2 outp;
	WppPrinter<> printerr;
	printerr.print2( *this, [&]( std::string name2, std::string value2 ){
		outp.setValue("s_settings", name2.c_str(), value2.c_str() );
	});
	return outp;
}
bool CzmSettings::deserialize3( const hxdw_IniData2& vInpIni )
{
	vInpIni.eachVariable( {"s_settings",},
		[&]( const char* s, const char* kname, const char* value2 )->bool{
			//WppAmplifier<int> amplifier2( kname, atoi(value2) );
			WppAmplifier<std::string> amplifier2( kname, std::string(value2) );
			amplifier2.apply2( this );
			return 1L;
	});
	return 1L;
}
const std::vector<std::pair<int,int> > CzmData::aUIButtonMap = {
	{ XINPUT_GAMEPAD_DPAD_DOWN, ImGuiKey_DownArrow,},
	{ XINPUT_GAMEPAD_DPAD_UP, ImGuiKey_UpArrow,},
	{ XINPUT_GAMEPAD_DPAD_LEFT, ImGuiKey_LeftArrow,},
	{ XINPUT_GAMEPAD_DPAD_RIGHT, ImGuiKey_RightArrow,},
	{ XINPUT_GAMEPAD_LEFT_SHOULDER, ImGuiKey_ModCtrl,},
	{ XINPUT_GAMEPAD_A, ImGuiKey_Space,},
	{ XINPUT_GAMEPAD_BACK, ImGuiKey_Escape,},
	{ XINPUT_GAMEPAD_X, ImGuiKey_Tab,},
	{ XINPUT_GAMEPAD_Y, ImGuiKey_Enter,},
	{ XINPUT_GAMEPAD_LEFT_THUMB, ImGuiKey_PageUp,},
	{ XINPUT_GAMEPAD_RIGHT_THUMB, ImGuiKey_PageDown,},
};
// IMGUI_IMPL_WIN32_DISABLE_GAMEPAD
/*
	struct XINPUT_GAMEPAD{
		WORD  wButtons;
		BYTE  bLeftTrigger;
		BYTE  bRightTrigger;
		SHORT sThumbLX;
		SHORT sThumbLY;
		SHORT sThumbRX;
		SHORT sThumbRY;
	};
	XINPUT_GAMEPAD::wButtons:
		XINPUT_GAMEPAD_DPAD_UP 	0x0001
		XINPUT_GAMEPAD_DPAD_DOWN 	0x0002
		XINPUT_GAMEPAD_DPAD_LEFT 	0x0004
		XINPUT_GAMEPAD_DPAD_RIGHT 	0x0008
		XINPUT_GAMEPAD_START 	0x0010
		XINPUT_GAMEPAD_BACK 	0x0020
		XINPUT_GAMEPAD_LEFT_THUMB 	0x0040
		XINPUT_GAMEPAD_RIGHT_THUMB 	0x0080
		XINPUT_GAMEPAD_LEFT_SHOULDER 	0x0100
		XINPUT_GAMEPAD_RIGHT_SHOULDER 	0x0200
		XINPUT_GAMEPAD_A 	0x1000
		XINPUT_GAMEPAD_B 	0x2000
		XINPUT_GAMEPAD_X 	0x4000
		XINPUT_GAMEPAD_Y 	0x8000
//*/
void czm_ProcessUIKey( uint16_t nXInputButtons )
{
	assert( Czm );
	ImGuiIO& io3 = ImGui::GetIO();
	const auto& ls2 = CzmData::aUIButtonMap;
	for( auto ir2 = ls2.begin(); ir2 != ls2.end(); ++ir2 ){
		if( nXInputButtons & ir2->first ){
			if( !(Czm->nXInputButtons2 & ir2->first) ){
				io3.AddKeyEvent( ir2->second, 1L );
				Czm->nXInputButtons2 |= ir2->first;
			}
		}else{
			if( Czm->nXInputButtons2 & ir2->first ){
				io3.AddKeyEvent( ir2->second, 0L );
				Czm->nXInputButtons2 &= ~ir2->first;
			}
		}
	}
	if( Czm->bUIOpened && Czm->bFocusNeedleOn ){
		// seecret LB+B
		bool cond2 = (
			(nXInputButtons & (
			XINPUT_GAMEPAD_LEFT_THUMB|XINPUT_GAMEPAD_B)));
		if( !cond2 ){
			//GetAsyncKeyState
			cond2 = ( (0x8000 & GetKeyState('B') &&
				0x8000 & GetKeyState(VK_CONTROL)) );//GetAsyncKeyState
		}
		if( cond2 ){
			Czm->bGBossesTabOn = 1L;
		}
		const bool cond3 = (
			nXInputButtons & (
			XINPUT_GAMEPAD_LEFT_THUMB|XINPUT_GAMEPAD_Y));
		if( cond3 ){
			Czm->bGBossesTabOn = 0L;
		}
	}
}

void czm_CreateWeaponTypeUIItems( std::string* srIoWpnFlags_ )
{
	static_assert( sizeof(int) >= sizeof(bool), "");
	assert( Czm );
	std::string& srIoWpnFlags3 = *srIoWpnFlags_;
	std::vector<int> aWpnCheckFlags2;
	{
		srIoWpnFlags3.resize( czm_GetWeaponTypeCount(), '-');
		aWpnCheckFlags2.resize( czm_GetWeaponTypeCount(), 0 );
		std::transform( srIoWpnFlags3.begin(), srIoWpnFlags3.end(), aWpnCheckFlags2.begin(),
				[]( char a )->int{ return a == 'x'; });
	}
	auto lmbCheckByWpnGrTy = [&]( CZM_EWGR eWGrTy )->void{
		const std::vector<CZM_EWT> guns2 = czm_GetWeaponGroupTypeWeapons( eWGrTy );
		const bool bShiftDown = ImGui::GetIO().KeyShift;
		size_t ii3 = 0;
		for( auto& flg : aWpnCheckFlags2 ){
			auto rs3 = czm_GetWeaponTypeByIndex( ii3 );
			bool flg2 = std::any_of( guns2.begin(), guns2.end(),
					[&rs3]( CZM_EWT a )->bool{
						return +rs3 == a;
					});
			flg = ( bShiftDown && flg ? flg : flg2 );
			ii3++;
		}
	};
	const int nNumCols = 3;
	if( ImGui::BeginTable("table_hNaOSq", nNumCols, 0u) ){
		{
			size_t ii2;
			CzmPair<bool,CZM_EWT> rs3;
			for( ii2 = 0; *(rs3 = czm_GetWeaponTypeByIndex(ii2)); ii2++ ){
				if( !( ii2 % nNumCols ) ){
					ImGui::TableNextRow( 0u, 4);
				}
				ImGui::TableNextColumn();
				std::string sr2 = czm_GetWeaponTypeName2( +rs3, 0L );

				assert( ii2 < aWpnCheckFlags2.size() );
				bool* ptr = (bool*) &aWpnCheckFlags2[ii2];
				ImGui::Checkbox( sr2.c_str(), ptr );
			}
			assert( ii2 == czm_GetWeaponTypeCount() );
		}
		ImGui::EndTable();
		//
		if( ImGui::Button("Clear Selection") ){
			for( auto& a : aWpnCheckFlags2 )
				a = 0L;
		}
		ImGui::SameLine();
		if( ImGui::Button("Invert Selection") ){
			for( auto& a : aWpnCheckFlags2 )
				a = !a;
		}
		if( ImGui::Button("Select Pistols") ){
			lmbCheckByWpnGrTy( CZM_EWGR::CZM_E5_Pistols );
		}
		ImGui::SameLine();
		if( ImGui::Button("Select Shotguns") ){
			lmbCheckByWpnGrTy( CZM_EWGR::CZM_E5_Shotguns );
		}
		ImGui::SameLine();
		if( ImGui::Button("Select Rifles") ){
			lmbCheckByWpnGrTy( CZM_EWGR::CZM_E5_Rifles );
		}
		if( ImGui::Button("Select Magnums") ){
			lmbCheckByWpnGrTy( CZM_EWGR::CZM_E5_Magnums );
		}
		ImGui::SameLine();
		if( ImGui::Button("Select Mele") ){
			lmbCheckByWpnGrTy( CZM_EWGR::CZM_E5_Mele );
		}
		ImGui::SameLine();
		if( ImGui::Button("Select Explosives") ){
			lmbCheckByWpnGrTy( CZM_EWGR::CZM_E5_Explosives );
		}
		if( ImGui::Button("Select Cheat Weapons") ){
			lmbCheckByWpnGrTy( CZM_EWGR::CZM_E5_CheatWeapons );
		}
		{
			assert( aWpnCheckFlags2.size() == srIoWpnFlags3.size() );
			std::transform( aWpnCheckFlags2.begin(), aWpnCheckFlags2.end(), srIoWpnFlags3.begin(),
				[]( int a )->char{ return a ? 'x' : '-'; });
		}
	}
}
void czm_SetupSceneUIElements()
{
	{
		//bool show_demo_window = 1;
		//ImGui::ShowDemoWindow(&show_demo_window);
	}
	if( Czm->bShowStartupTip ){
		const uint32_t uNow2 = (uint32_t) hxdw_GetTimeTicksMs();
		Czm->uStartupTipOpenedAtMs = ( Czm->uStartupTipOpenedAtMs ? Czm->uStartupTipOpenedAtMs : uNow2 );
		const uint32_t nEndsAt = (Czm->uStartupTipOpenedAtMs + Czm->uStartupTipDurationMs);
		if( uNow2 < nEndsAt ){
			double pos2 = (double(nEndsAt-uNow2) / Czm->uStartupTipDurationMs);
			const int flags3 = ( ImGuiWindowFlags_NoCollapse |
				ImGuiWindowFlags_NoTitleBar |
				ImGuiWindowFlags_NoScrollbar |
				ImGuiWindowFlags_NoResize );
			ImGui::SetNextWindowBgAlpha( 1.0f ); //1.0f: fully opaque.
			ImGui::Begin( Czm->szAppName, nullptr, flags3 );
			ImGui::Text("%s : Press", Czm->szAppName );
			ImGui::SameLine();
			ImGui::TextColored( {1,1,0,1,},"F5");
			ImGui::SameLine();
			ImGui::Text("or");
			ImGui::SameLine();
			ImGui::TextColored( {1,1,0,1,},"RIGHT_SHOULDER+START");
			ImGui::SameLine();
			ImGui::Text("to open the setup window.");
			if( Czm->bKeyboardNavError ){
				ImGui::TextColored( {1,0,1,1,},"WARNING: No keyboard navigation.");
			}
			if( Czm->bGamepadNavError ){
				ImGui::TextColored( {1,0,1,1,},"WARNING: No gamepad navigation.");
			}
			ImGui::PushItemWidth( ImGui::GetWindowSize().x );
			ImGui::ProgressBar( float(pos2), {0.f, 1.f,} );
			ImGui::PopItemWidth();

			ImGui::End();
		}else{
			Czm->bShowStartupTip = 0L;
		}
	}
	if( Czm->se3.bShowLogWindow ){
		int flags2 = ( ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoTitleBar );
		if( !Czm->bUIOpened ){
			ImGui::SetNextWindowBgAlpha( Czm->fInactiveOpacity );  //1.0f: fully opaque.
			flags2 |= ImGuiWindowFlags_NoScrollbar;
			flags2 |= ImGuiWindowFlags_NoResize;
			flags2 |= ImGuiWindowFlags_NoBackground;
		}
		char bfrA[128];
		snprintf( bfrA, sizeof(bfrA), "<<< Log Window - %s >>>", Czm->szAppName );
		ImGui::Begin( bfrA, nullptr, flags2 );
		Czm->cLogWndGmtr->updateOnWindowBegin();
		if( Czm->bUIOpened ){
			ImGui::Text( bfrA );
			if( ImGui::Button("Clear") ){
				Czm->clearLogText2();
			}
			ImGui::SameLine();
			ImGui::Checkbox("Auto scroll", &Czm->bLogAutoScroll );
		}{
			Czm->purgeOldLogItems();
			size_t num = +Czm->getLogText2();
			for( size_t ii2 = 0; ii2 < num; ii2++ ){
				ImGui::Text( *Czm->getLogText2( (int)ii2 ) );
			}
		}{
			if( Czm->bLogAutoScroll && *Czm->aLogItemTrack < +Czm->getLogText2() ){
				Czm->aLogItemTrack.first = +Czm->getLogText2();
				Czm->aLogItemTrack.second = 2;
			}
			if( Czm->aLogItemTrack.second ){
				--Czm->aLogItemTrack.second;
				ImGui::SetScrollY( ImGui::GetScrollMaxY() );
			}
		}
		Czm->cLogWndGmtr->updateOnWindowEnd();
		ImGui::End();
	}
	if( *Czm->bShowToolWindow ){
		int flags2 = ( ImGuiWindowFlags_NoCollapse );//| ImGuiWindowFlags_NoTitleBar;
		if( !(+Czm->bShowToolWindow) ){
			ImGui::SetNextWindowBgAlpha( Czm->fInactiveOpacity );  //1.0f: fully opaque.
			flags2 |= ImGuiWindowFlags_NoScrollbar;
			flags2 |= ImGuiWindowFlags_NoResize;
		}
		ImGui::Begin("Tool Window", nullptr, flags2 );
		ImGui::Text( "" );
		if( ImGui::Button("[Close]""##qhfvKk5q") ){
			*Czm->bShowToolWindow = 0L;
			+Czm->bShowToolWindow = 0L;
		}
		ImGui::SameLine();
		if( ImGui::Button("[Unfocus]""##Kvabk92") ){ //VK_F8
			+Czm->bShowToolWindow = 0L;
		}
		if( ImGui::Button("Add Enemy""##4Gsac3Z") ){
		/*	CzmRE4EmList sEmls;  //CzmRE4EmList,EM_LIST
			sEmls.setSampleEnemy2();
			sEmls.room_18 = (**Czm->ppGD).curRoomId_4FAC.v;
			if( Czm->ppPlayerGD && *Czm->ppPlayerGD ){
				sEmls.s_pos_C = czm_ConvPosToRE4Svec( (**Czm->ppPlayerGD).position_94.v );
				Czm->cEnmFctry->createLiveEnemy2( sEmls );
			}//*/
		}
		{
			ImGui::Text("");
			std::vector<const char*> aItems2;
			std::vector<std::string> aItems3;//CzmRE4Enemy::id_100
			{
				Czm->cEnmFctry->enumerateEnemyList(
					[&aItems3]( const CzmEnmDTO& inp ){
						aItems3.push_back( czm_RE4EnemyToStr( inp.pEnm4 ) );
					}, "");
				aItems2.resize( aItems3.size(), nullptr );
				std::transform( aItems3.begin(), aItems3.end(), aItems2.begin(),
					[]( const std::string& a )->const char*{ return a.c_str(); });
			}
			ImGui::Text("Select and delete enemy (count:%d)", (int)Czm->aCurEnmList.size() );
			static int nCurrItem = 0;
			ImGui::SetNextItemWidth(
				ImGui::GetMainViewport()->WorkSize.x * 0.25f );
			ImGui::Combo(" ", &nCurrItem, &aItems2[0], (int)aItems2.size() );
			ImGui::SameLine();
			if( ImGui::Button("Delete""##9I5gzeD") ){
				//czm_Print2("DeleteEnm-1 %d\n", { nCurrItem,} );
				if( nCurrItem < (int)aItems2.size() ){
					//Czm->cEnmFctry->destroyEnemyByIndex2( (size_t)nCurrItem );
					assert(!"WIP.");
				}
			}
		}
		ImGui::End();
	}

	if( Czm->bUIOpened ){
		CzmSettings se2 = Czm->se3;

		std::string srWndName = std::string(Czm->szAppName) + std::string(" - Settings");
		ImGui::Begin( srWndName.c_str(), nullptr, ImGuiWindowFlags_NoCollapse );
		Czm->cSettingsWndGmtr->updateOnWindowBegin();
		{
			if( ImGui::SmallButton("[Close]""##tyJsLnt") ){
				Czm->bUIOpened = 0L;
			}
			ImGui::SameLine();
			if( ImGui::SmallButton("[Save Settings]""##P3LQ2DF") ){
				bool rs2; std::string data2;
				assert( Czm->pDbfs );  //[s_settings]
				data2 = Czm->se3.serialize3().getAsString();
				czm_Print2("CZM: INI settings save size: %a bytes\n", { data2.size(),});
				rs2 = Czm->pDbfs->putVFileBytes2( Czm->srSettingsIniVFname.c_str(), data2.c_str(), data2.size(), "r" );
				Czm->srUIFileMessage = { ImGui::GetTime(),
					(rs2 ? "Saved" : "ERROR: Settings save failed."),
				};
			}
			ImGui::SameLine();
			if( ImGui::SmallButton("[Clear Settings]""##nEhH7FN") ){
				se2 = CzmSettings();
			}
			ImGui::SameLine();
			if( ImGui::SmallButton("[Reload Settings]""##tBlT7Rc") ){
				std::vector<uint8_t> data3;
				data3 = Czm->pDbfs->getVFileBytes3( Czm->srSettingsIniVFname.c_str(),
							0, {0L,0,}, "c" );
				auto ini4 = hxdw_ParseINIData( (const char*)&data3[0], -1 );
				if( !ini4.isINIEmpty() ){
					se2.deserialize3( ini4 );
				}
				Czm->srUIFileMessage = { ImGui::GetTime(),
					(!ini4.isINIEmpty() ? "Reloaded" : "ERROR: Settings reload failed."),
				};
			}
			if( *Czm->srUIFileMessage ){
				if( *Czm->srUIFileMessage + 3.0 > ImGui::GetTime() ){
					ImGui::Text( (+Czm->srUIFileMessage).c_str() );
				}else{
					*Czm->srUIFileMessage = 0.0;
					ImGui::Text("");
				}
			}else{
				ImGui::Text("");
			}
			// ImGuiTabBarFlags, ImGuiTabItemFlags
			ImGui::BeginTabBar("tabs_kZZeZT", ImGuiTabBarFlags_FittingPolicyScroll );
			if( ImGui::BeginTabItem("Crit. Options", nullptr, 0x0 ) ){
				ImGui::Checkbox("Enable Critical Damage Scaling", &se2.bCritDmgScale );
				{
					ImGui::SameLine();
					static bool bCdsTooltip = 0L;
					if( ImGui::SmallButton("?##uSIiuQ7") ){
						bCdsTooltip = !bCdsTooltip;
					}
					if( bCdsTooltip ){
						ImGui::Text(
							"This works only on humanoid enemies.\n"
							"I.e. this is the damage done with headshots.");
					}
				}
				if( !se2.bCritDmgScale ){
					ImGui::BeginDisabled();
				}
				ImGui::InputFloat("Crit. Scale", &se2.fCritDmgScale2, 0.1f, 0.5f, "%f", 0x0 );
				if( ImGui::Button("Reset""##xRRQ5E2") ){
					se2.fCritDmgScale2 = 1.f;
				}
				ImGui::SameLine();
				if( ImGui::Button("Zero""##q2RLeF2") ){
					se2.fCritDmgScale2 = 0.f;
				}
				ImGui::SameLine();
				if( ImGui::Button("x10""##faiVyeB") ){
					se2.fCritDmgScale2 *= 10.f;
				}
				ImGui::Text("");
				czm_CreateWeaponTypeUIItems( &se2.srWpnCheckFlags4 );
				if( !se2.bCritDmgScale ){
					ImGui::EndDisabled();
				}
				ImGui::EndTabItem();
			}
			if( ImGui::BeginTabItem("Skips", nullptr, 0x0 ) ){
				{
					{
						ImGui::Checkbox("Cutscene Skip""##bCutscSkip2", &se2.bCutscSkip2 );
						Czm->bFocusNeedleOn = ImGui::IsItemFocused(); //bGBossesTabOn
						ImGui::SameLine();
						static bool bCsSkpTooltip = 0L;
						if( ImGui::SmallButton("?##6JaESm") ){
							bCsSkpTooltip = !bCsSkpTooltip;
						}
						if( bCsSkpTooltip ){
							ImGui::Text(
								"Auto skips most of the skippable cutscenes in the game.\n"
								"Done at the first possible frame.");
						}
					}{
						if( ImGui::Checkbox("Make Krauser knife fight cutscenes skippable", &se2.bDeltaCutscSkip ) ){
						}
					}
				}{
					if( ImGui::Checkbox("Del Lago insta KO", &se2.bDelLagoKO ) ){
					}
				}{
					ImGui::Checkbox("You CAN leave Ashley behind", &se2.bYclAb );
					ImGui::Checkbox("Skip the one-time-per-room merchant \x22""Welcome!\x22 animation", &se2.bMrchWASkip );
					ImGui::Checkbox("Enable Automatic Gold Pickups", &se2.bGoldAutoPickup );
					ImGui::SameLine();
					if( se2.bShowLogWindow ){
						//Notifications//Live Values
						if( ImGui::SmallButton("Live Values +""##gDCX6G") ){
							se2.bShowLogWindow = 0L;
						}
					}else{
						if( ImGui::SmallButton("Live Values -""##UlE8tM") ){
							se2.bShowLogWindow = 1L;
						}
					}
				}
				ImGui::EndTabItem();
			}
			if( ImGui::BeginTabItem("Parasite", nullptr, 0x0 ) ){
				ImGui::Checkbox("Enable Plagas Spawn Override", &se2.bPlagasOvr );
				{
					ImGui::SameLine();
					static bool bPrsOnTooltip = 0L;
					if( ImGui::SmallButton("?##2c2gKaD") ){
						bPrsOnTooltip = !bPrsOnTooltip;
					}
					if( bPrsOnTooltip ){
						ImGui::Text(
							"Also forces the new spawn setting in all chapters,\n"
							"on all eligible enemies, on all eligible kills and in all game modes.\n"
							"Doesn't work in all rooms. eg. start area (r100) or cabin fight area.");
					}
				}
				if( !se2.bPlagasOvr ){
					ImGui::BeginDisabled();
				}
				if( ImGui::InputInt("Parasite Chance %", &se2.nPrsChance, 1, 10, 0x0 ) ){
					se2.nPrsChance = CzmClamp<int,int>( se2.nPrsChance, 0, 100 );
				//	bChanged = 1L;
				}
				if( ImGui::Button("100%##WDeguF") ){
					se2.nPrsChance = 100;
				}
				ImGui::SameLine();
				if( ImGui::Button("0%##IJVwNy") ){
					se2.nPrsChance = 0;
				}
				if( !se2.bPlagasOvr ){
					ImGui::EndDisabled();
				}
				ImGui::Checkbox("Allow Unlimited Parasite Spawns", &se2.bPrsSpwNoLimit );
				{
					ImGui::Checkbox("Disable Parasite Type C", &se2.bNoTypeCParasite );
					ImGui::SameLine();
					static bool bPrsCTooltip = 0L;
					if( ImGui::SmallButton("?##klQbW0") ){
						bPrsCTooltip = !bPrsCTooltip;
					}
					if( bPrsCTooltip ){
						ImGui::Text(
							"Replaces parasite type C (spider-like) with the other parasite.\n"
							"Encountered first in room r20F - the free R.L. room.");
					}
				}{
					ImGui::Checkbox("Disable Parasite Spawn in Chapter 1", &se2.bNoParasiteChOne );
					ImGui::SameLine();
					static bool bPrsCh1Tooltip = 0L;
					if( ImGui::SmallButton("?##sDMC0d") ){
						bPrsCh1Tooltip = !bPrsCh1Tooltip;
					}
					if( bPrsCh1Tooltip ){
						// subchapters, from 1-1 to 1-3, but not 2-1 and forth.
						ImGui::Text(
							"May disable parasite override in the other game modes.");
					}
				}
				ImGui::EndTabItem();
			}
			if( ImGui::BeginTabItem("UI Setup", nullptr, 0x0 ) ){
				int nRqScale = 0;
				nRqScale -= !!ImGui::Button("Scale -");
				ImGui::SameLine();
				nRqScale += !!ImGui::Button("Scale +");
				if( nRqScale ){
					Czm->fUIScale2 *= ( nRqScale > 0 ? 1.1f : 1.0f/1.1f );
					ImGuiIO& io2 = ImGui::GetIO();
					io2.FontGlobalScale = Czm->fUIScale2;
				}
				ImGui::SameLine();
				if( ImGui::Button("Reset") ){
					ImGui::GetIO().FontGlobalScale = Czm->fUIScale2 = 1.0f;
				}
				//if( Czm->bGBossesTabOn ){
					ImGui::Checkbox("Show Log Window", &se2.bShowLogWindow );
				//}
				if( Czm->bDbgFeaturesOn ){
					if( ImGui::Checkbox("Show Tool Window", &(*Czm->bShowToolWindow) ) ){
						if( *Czm->bShowToolWindow )
							+Czm->bShowToolWindow = 1L;
					}
				}
				ImGui::EndTabItem();
			}
			if( ImGui::BeginTabItem("Stats", nullptr, 0x0 ) ){
				{
					assert( Czm );
					assert( Czm->ppGD );
					assert( *Czm->ppGD );
					std::array<bool,64> aFlStats = czm_FlagsToArray<64>( se2.uShowEnmStats );

					ImGui::Checkbox("Enable Stats", &aFlStats[0] );
					ImGui::SameLine();
					ImGui::Checkbox("2""##JTrlkw8", &aFlStats[1] );
					ImGui::SameLine();
					ImGui::Checkbox("3""##Tt9WiTO", &aFlStats[2] );
					se2.uShowEnmStats = czm_ArrayToFlags( &aFlStats[0], aFlStats.size() );
					if( se2.uShowEnmStats & 0x1 ){
						ImGui::Text("Current room id: %s",
							czm_ToStrFmt("r%03X", int64_t((**Czm->ppGD).curRoomId_4FAC.v) ).c_str() );
						ImGui::Text("Dynamic Difficulty points/level: %u/%u",
							uint32_t((**Czm->ppGD).dynamicDifficultyPoints_4F94.v),
							uint32_t((**Czm->ppGD).dynamicDifficultyLevel_4F98.v) );
						ImGui::Text("PlayTime: %u",
							int((**Czm->ppGD).playTime_4FA4.v) );
						ImGui::Text("Chapter: %u",
							uint32_t((**Czm->ppGD).chapter_4F9A.v) );
					}
					if( se2.uShowEnmStats & 0x2 ){
						ImGui::Text("Kill Count c/g: %u/%u",
							uint32_t((**Czm->ppGD).c_kill_cnt_8464.v),
							uint32_t((**Czm->ppGD).g_kill_cnt_8468.v) );
						ImGui::Text("Continue count: %u",
							uint32_t((**Czm->ppGD).r_continue_cnt_4FA0.v) );
						ImGui::Text("Hit count c/g: %u/%u",
							((**Czm->ppGD).c_hit_cnt_846C.v),
							((**Czm->ppGD).g_hit_cnt_8470.v) );
						ImGui::Text("Shot count c/g: %u/%u",
							((**Czm->ppGD).c_shot_cnt_8474.v),
							((**Czm->ppGD).g_shot_cnt_8478.v) );
						{
							CzmRE4Vec vp2 = { 0.f, 0.f, 0.f,};
							CzmRE4Vec vr2 = { 0.f, 0.f, 0.f,};
							if( Czm->ppPlayerGD && *Czm->ppPlayerGD ){
								vp2 = (**Czm->ppPlayerGD).position_94.v;
								vr2 = (**Czm->ppPlayerGD).rotation_A0.v;
							}
							ImGui::Text("Player pos (f32): [%f, %f, %f]", vp2.x, vp2.y, vp2.z );
							CzmRE4Svec vs2 = czm_ConvPosToRE4Svec( vp2 );
							ImGui::Text("Player pos (hex): [%02X %02X %02X %02X %02X %02X]",
									((uint8_t*)&vs2.x)[0],
									((uint8_t*)&vs2.x)[1],
									((uint8_t*)&vs2.y)[0],
									((uint8_t*)&vs2.y)[1],
									((uint8_t*)&vs2.z)[0],
									((uint8_t*)&vs2.z)[1] );
							ImGui::Text("Player rtn (f32): [%f, %f, %f]", vr2.x, vr2.y, vr2.z );
							//
						//	CzmRE4Vec vCamPos;
						//	czm_GetRE4CameraTrajectory( &vCamPos, 0 );
						//	ImGui::Text("Cam pos (f32): [%f, %f, %f]",
						//			vCamPos.x, vCamPos.y, vCamPos.z );
						}
					}
					if( se2.uShowEnmStats & 0x4 ){
						ImGui::Text("Current Enemies (%d):", (int)Czm->aCurEnmList.size() );
						if( Czm->aCurEnmList.empty() ){
							ImGui::Text("    <empty-list>");
						}else{
							auto ir2 = Czm->aCurEnmList.begin();
							for( int ii2 = 0; ir2 != Czm->aCurEnmList.end(); ++ir2, ii2++ ){
								//ir2 : CzmRE4Enemy
								ImGui::Text("%-2d: %s", (int)ii2+1,
									czm_RE4EnemyToStr( &(*ir2) ).c_str() );
							}
						}
					}
				}
				ImGui::EndTabItem();
				Czm->bStatsEnabled = 1L;
			}
			if( ImGui::BeginTabItem("About", nullptr, 0x0 ) ){
				if( Czm->srVersionCalc.empty() ){
					Czm->srVersionCalc = czm_CalcProgramVersion();
				}
				ImGui::Indent( ImGui::GetWindowSize().x * 0.05f );
				ImGui::Text("");
				std::string srNameText;
				srNameText = hxdw_StrPrintf("\n\x20\x20%a\x20\x20\n\x20",
					{ std::string(Czm->szAppName),});
				ImGui::Button( srNameText.c_str() );
				ImGui::Text("");
				ImGui::Text("Version: %s", Czm->srVersionCalc.c_str() );
				ImGui::Text("");
				ImGui::Text("Author: ike9000" );
				ImGui::Text("");
				ImGui::Text("Web page: %s", CZM_APP_URL );
				//ImGui::Button("");
				ImGui::Unindent();
				ImGui::EndTabItem();
			}
			ImGui::EndTabBar();
		}
		Czm->cSettingsWndGmtr->updateOnWindowEnd();
		ImGui::End();
		if( !se2.equalsWith( Czm->se3 ) ){
			czm_UpdateSettingsViaCallbacks( se2, Czm->se3, 0L );
			Czm->se3 = se2;
		}
	}
}

