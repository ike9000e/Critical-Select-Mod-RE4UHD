#include "czm_utils.h"
#include <windows.h>
#include <memory>
#include <assert.h>
#include <xinput.h>   //XInputGetState()
#include "imgui.h"
#include "detours.h"
#include "hxdw_process.h"
#include "hxdw_detours_misc.h"
#include "hxdw_checksum.h"  //HxdwMd5
#include "fp_fat32.h"   //FpDiskImage
#include "czm_gui.h"
#include "czm_reiv_tools.h"
// warning C4091: 'typedef ': ignored on left of '<unnamed-enum-hdBase>' when no variable is declared

BOOL __stdcall czm_PeekMessageW( MSG* msg, HWND hw2, UINT wMsgFilterMin, UINT wMsgFilterMax, UINT wRemoveMsg );
BOOL __stdcall czm_PeekMessageA( MSG* msg, HWND hw2, UINT wMsgFilterMin, UINT wMsgFilterMax, UINT wRemoveMsg );
uint32_t czm_XinputDetoursInit();
uint32_t czm_XinputDetoursDeinit();
DWORD WINAPI czm_XInputGetState( DWORD dwUserIndex, XINPUT_STATE* pStateOut );

const int16_t CzmData::nUIButtonMask = ( XINPUT_GAMEPAD_RIGHT_SHOULDER | XINPUT_GAMEPAD_START );
const int16_t CzmData::nUICloseButtons = ( XINPUT_GAMEPAD_START | XINPUT_GAMEPAD_B );
const uint32_t CzmData::uUIButtonIntervalMs = 333;
const size_t CzmData::nMaxLogItems = 128;
const uint64_t CzmData::uTimeLogItemStaysMs = 5000;//5000;

bool czm_Print2( const char* fmt, const std::vector<HxdwPrintAdp> args4 )
{
	std::string sr3 = hxdw_StrPrintf( fmt, args4 );
	return hxdw_StdPrint2( sr3.c_str() );
}

std::string czm_ToStrFmt( const char* fmt, int64_t inp )
{
	assert( fmt );
	{
		int ii2 = 0;
		for( const char* ptr = fmt; (ptr = std::strchr( ptr, '%' )); ii2++, ptr++ );
		assert( ii2 == 1 && "Format string must contain exactly one percent character [iBnasZ]");
	}
	char bfr4[64];
	std::snprintf( bfr4, sizeof(bfr4), fmt, inp );
	return bfr4;
}
bool czm_AnySystemModkeyDown( const std::vector<int>& aModKeysExcept )
{
	const auto& ls2 = aModKeysExcept;
	static const std::array<int,5> ar2 = { VK_SHIFT,VK_CONTROL,VK_MENU,VK_LWIN,VK_RWIN,};
	for( auto ir2 = ar2.begin(); ir2 != ar2.end(); ++ir2 ){
		auto a = std::find( ls2.begin(), ls2.end(), *ir2 );
		if( a == ls2.end() ){ // if not found.
			if( 0x8000 & GetKeyState( *ir2 ) ){//GetAsyncKeyState
				return 1;
			}
		}
	}
	return 0;
}

void __cdecl czm_XCrtExitProcess( uint32_t uExitCode2 )
{
	assert( Czm->czm_OgXCrtExitProcess );
	void* fnPtrCpy = Czm->czm_OgXCrtExitProcess;

	czm_DllDeInit();
	assert( !Czm );

	//MessageBox(0,"","",0);
	using fn_t = decltype(czm_XCrtExitProcess)*;
	//((fn_t)Czm->czm_OgXCrtExitProcess)( uExitCode2 );
	((fn_t)fnPtrCpy)( uExitCode2 );
}
uint32_t czm_Win32DetoursInit()
{
	DetourTransactionBegin();
	DetourUpdateThread( GetCurrentThread() );
	std::shared_ptr<void*> raii4( nullptr, [&]( void* ){
		DetourTransactionCommit();
	});
	{
		HMODULE hUser32Dll = 0;
		hxdw_EnumerateProcessModules( 0, [&]( const HxdwModOnEnum& inp )->bool{
				auto bn2 = hxdw_SplitPath( inp.srPath ).second;
				assert( !bn2.empty() );
				if( !hxdw_StrCmpOpt( bn2.c_str(), "user32.dll", -1, "i" ) ){
					hUser32Dll = (HMODULE)inp.hDll;
					return 0L;
				}
				return 1L;
			});
		assert( hUser32Dll );
		{
			//
			// NOTE: MinHook fails to detour a function that is already detoured.
			//       MS Detours library detours that function correctly, instead.
			//
			Czm->fnOgPeekMessageA = GetProcAddress( hUser32Dll, "PeekMessageA");
			assert( Czm->fnOgPeekMessageA );
			Czm->fnOgPeekMessageW = GetProcAddress( hUser32Dll, "PeekMessageW");
			assert( Czm->fnOgPeekMessageW );
			//
		//	DetourTransactionBegin();
		//	DetourUpdateThread( GetCurrentThread() );
		//	std::shared_ptr<void*> raii4( nullptr, [&]( void* ){
		//		DetourTransactionCommit();
		//	});
			Czm->bKeyboardNavError = 1L;
			LONG rs2 = DetourAttach( &Czm->fnOgPeekMessageA, czm_PeekMessageA );
			if( rs2 ){   //NO_ERROR=0; ERROR_INVALID_BLOCK
				std::string msg = hxdw_DetoursErrorToString( rs2 );
				czm_Print2("CZM: ERROR: Detouring PeekMessageA failed. Code:[%d:%s] [qYijfM]\n", { (int)rs2, msg,} );
			}else{
				rs2 = DetourAttach( &Czm->fnOgPeekMessageW, czm_PeekMessageW );
				if( rs2 ){
					std::string msg = hxdw_DetoursErrorToString( rs2 );
					czm_Print2("CZM: ERROR: Detouring PeekMessageW failed. Code:[%d:%s] [XAjpoj]\n", { (int)rs2, msg,} );
				}else{
					Czm->bKeyboardNavError = 0L; //mark no-error.
				}
			}
			//DWORD dwOldProt = 0;
			//bool rs2 = !!VirtualProtect( pPkMsgFunc, 16, PAGE_EXECUTE_READWRITE, &dwOldProt );
			//assert(rs2);
		}
	}
	{
		//bool czm_DllDeInit();
		//___crtExitProcess() -> .text+0x670113
		void* pAtOpCode = hxdw_GetPtrGivenInSectionOffset( 0, 0, ".text", 0x670113 );
		assert( pAtOpCode );
		assert( !Czm->czm_OgXCrtExitProcess );
		LONG rs2 = hxdw_DetourAttach( pAtOpCode, &Czm->czm_OgXCrtExitProcess, czm_XCrtExitProcess, DetourAttach );
		assert( !rs2 );
	}
	uint32_t rs2 = czm_XinputDetoursInit();
	assert( !rs2 );
	return 0;
}

uint32_t czm_XinputDetoursInit()
{
	const char* aXinputDllNames[] = {   //taken from ImGui
		"xinput1_4.dll",   // Windows 8+
		"xinput1_3.dll",   // DirectX SDK
		"xinput9_1_0.dll", // Windows Vista, Windows 7
		"xinput1_2.dll",   // DirectX SDK
		"xinput1_1.dll",   // DirectX SDK
	};
	assert( Czm );
	assert( !Czm->hXInputDll );
	hxdw_EnumerateProcessModules( 0, [&](const HxdwModOnEnum& in2)->bool{
		for( size_t ii2=0; ii2 < CzmArrSize(aXinputDllNames); ii2++ ){
			auto bn2 = hxdw_SplitPath( in2.srPath ).second;
			assert( !bn2.empty() );
			if( !hxdw_StrCmpOpt( bn2.c_str(), aXinputDllNames[ii2], -1, "i" ) ){
				assert( in2.hDll );
				Czm->hXInputDll = in2.hDll;
				return 0L;
			}
		}
		return 1L;
	});
	czm_Print2("CZM: XInput Enabled: [%a]\n", { std::string( Czm->hXInputDll ? "Yes": "No"),} );
	if( Czm->hXInputDll ){
		Czm->fnOgXInputGetState = GetProcAddress( (HMODULE)Czm->hXInputDll, "XInputGetState");
		assert( Czm->fnOgXInputGetState );
		DetourTransactionBegin();
		DetourUpdateThread( GetCurrentThread() );
		std::shared_ptr<void*> raii4( nullptr, [&]( void* ){
			DetourTransactionCommit();
		});
		LONG rs2 = DetourAttach( &Czm->fnOgXInputGetState, czm_XInputGetState );
		if( rs2 ){   //NO_ERROR=0
			std::string msg = hxdw_DetoursErrorToString( rs2 );
			czm_Print2("CZM: ERROR: Detouring XInputGetState failed. Code:[%d:%s] [d9WSSU]\n", { (int)rs2, msg,} );
			Czm->bGamepadNavError = 1L;
		}
	}
	return 0;
}

uint32_t czm_Win32DetoursDeinit()   //czm_Win32DetoursInit()
{
	czm_XinputDetoursDeinit();
	{
		//MH_DisableHook( czm_PeekMessageW );
		//MH_DisableHook( czm_PeekMessageA );
		DetourTransactionBegin();
		DetourUpdateThread( GetCurrentThread() );
		DetourDetach( &Czm->fnOgPeekMessageW, czm_PeekMessageW );
		DetourDetach( &Czm->fnOgPeekMessageA, czm_PeekMessageA );
		DetourTransactionCommit();
	}
	return 0;
}
uint32_t czm_XinputDetoursDeinit()   //czm_XinputDetoursInit()
{
	assert( Czm );
	if( Czm->hXInputDll && Czm->fnOgXInputGetState ){
		DetourTransactionBegin();
		DetourUpdateThread( GetCurrentThread() );
		DetourDetach( &Czm->fnOgXInputGetState, czm_XInputGetState );
		DetourTransactionCommit();
	}
	return 0;
}


//XInputGetState
DWORD WINAPI czm_XInputGetState( DWORD dwUserIndex, XINPUT_STATE* pStateOut )
{
	assert( Czm );
	assert( Czm->fnOgXInputGetState );
	using fn_t = decltype(czm_XInputGetState)*;
	DWORD retv = ((fn_t)Czm->fnOgXInputGetState)( dwUserIndex, pStateOut );
	if( retv == ERROR_SUCCESS ){
		const WORD bt2 = pStateOut->Gamepad.wButtons;
		const int16_t msk2 = CzmData::nUIButtonMask;
		bool bActv = ( (bt2 & msk2) == msk2 && !(bt2 & (~msk2)) );
		std::shared_ptr<int> raii2( nullptr, [&]( int* ){
			Czm->bUIButtonHeld = bActv;
		});
		if( bActv ){
			pStateOut->Gamepad.wButtons &= ~msk2;
			uint32_t uNow = (uint32_t) hxdw_GetTimeTicksMs();
			if( uNow > Czm->uUIButtonTimePos + CzmData::uUIButtonIntervalMs || !Czm->bUIButtonHeld ){
				Czm->bUIOpened = !Czm->bUIOpened;
				Czm->uUIButtonTimePos = uNow;
			}
		}
		if( Czm->bUIOpened || +Czm->bShowToolWindow ){
			std::shared_ptr<int> raii3( nullptr, [&]( void* ){
				memset( &pStateOut->Gamepad, 0, sizeof(pStateOut->Gamepad) );
			});
			czm_ProcessUIKey( pStateOut->Gamepad.wButtons );
			{
				const bool cond3 = (
					pStateOut->Gamepad.wButtons & CzmData::nUICloseButtons &&
					!(pStateOut->Gamepad.wButtons & ~CzmData::nUICloseButtons));
				if( cond3 ){
					Czm->bUIOpened = 0L;
					Czm->uUIButtonTimePos = (uint32_t) hxdw_GetTimeTicksMs();
					Czm->bClosingUI = 1L;
				}
			}
		}
		if( Czm->bClosingUI ){
			uint32_t uNow = (uint32_t) hxdw_GetTimeTicksMs();
			if( uNow < Czm->uUIButtonTimePos + CzmData::uUIButtonIntervalMs ){
				pStateOut->Gamepad.wButtons &= ~CzmData::nUICloseButtons;
			}else{
				Czm->bClosingUI = 0L;
			}
		}
	}
	return retv;
}

CzmData::CzmData()
	: se3( *new CzmSettings )
{
	// pGD -> ppGD -> .data+0x13F3C //CzmRE4GlobDt
	assert( !ppGD );
	ppGD = (CzmRE4GlobDt**)hxdw_GetPtrGivenInSectionOffset( 0, nullptr, ".data", 0x13F3C );
	assert( ppGD );

	// ppPlayerGD -> pPL -> .data+0x64054
	assert( !ppPlayerGD );
	ppPlayerGD = (CzmRE4Enemy**)hxdw_GetPtrGivenInSectionOffset( 0, nullptr, ".data", 0x64054 );
	assert( ppPlayerGD );

	assert( !cLogWndGmtr && !cSettingsWndGmtr );
	cLogWndGmtr = new CzmWndGeomMgr( {0.005f,0.6f,0.5f,0.33f,});
	cSettingsWndGmtr = new CzmWndGeomMgr( {0.1f,0.1f,0.8f,0.8f,});

	assert( !ini2 );
	ini2 = new hxdw_IniData2;

	assert( !cHpMgr );
	cHpMgr = new CzmHotPatchMgr;

	assert( !cEnmFctry );
	cEnmFctry = new CzmEnemyFactory;

	assert( !pDbfs );
	pDbfs = new FpDiskImage;

	assert( !pCameraCtrl );
	pCameraCtrl = hxdw_GetPtrGivenInSectionOffset( 0, 0, ".data", 0x7D2D0 );
	assert( pCameraCtrl );

	assert( !fnCameraControlxxgetTrajectory );
	fnCameraControlxxgetTrajectory = hxdw_GetPtrGivenInSectionOffset( 0, 0, ".text", 0x2F3520 );
	assert( fnCameraControlxxgetTrajectory );

	assert( !pGlbPS );
	pGlbPS = (uint32_t*)hxdw_GetPtrGivenInSectionOffset( 0, 0, ".data", 0x745A8 );
	assert( pGlbPS );
	pGlbPicups = (uint32_t*) (((uint8_t*)pGlbPS) + 0x8C);
}
CzmData::~CzmData()
{
	if( pDbfs ){
		delete pDbfs;
		pDbfs = nullptr;
	}
	if( cLogWndGmtr ){
		delete cLogWndGmtr;
		cLogWndGmtr = nullptr;
	}
	if( cSettingsWndGmtr ){
		delete cSettingsWndGmtr;
		cSettingsWndGmtr = nullptr;
	}
	if( ini2 ){
		delete ini2;
		ini2 = nullptr;
	}
	if( cHpMgr ){
		delete cHpMgr;
		cHpMgr = nullptr;
	}
	if( cEnmFctry ){
		delete cEnmFctry;
		cEnmFctry = nullptr;
	}
	assert( &se3 );
	delete &se3;
}
void CzmData::addLog3( const char* fmt, const std::vector<HxdwPrintAdp> args4 )
{
	std::string sr3 = hxdw_StrPrintf( fmt, args4 );
	for(; aLogText.size() > CzmData::nMaxLogItems ;){
		aLogText.erase( aLogText.begin() );
	}
	CzmLogItem li2( sr3 );
	li2.uAddedAt = hxdw_GetTimeTicksMs();
	aLogText.push_back( li2 );
}

CzmPair<const char*,size_t>
CzmData::getLogText2( int nIndex_ )const
{
	if( nIndex_ == -1 ){
		return CzmPair<const char*,size_t>("", aLogText.size() );
	}
	size_t nIndex = (size_t)nIndex_;
	assert( nIndex < aLogText.size() );
	const CzmLogItem* itm2 = &aLogText[nIndex];
	CzmPair<const char*,size_t> outp(
			itm2->srText2.c_str(), aLogText.size() );
	return outp;
}
void CzmData::clearLogText2()
{
	aLogText.clear();
	aLogItemTrack = {0,0,};
}
void CzmData::purgeOldLogItems()
{
	if( aLogText.empty() ){
		return;
	}
	const uint64_t uTmNow = hxdw_GetTimeTicksMs();
	for( auto ir2 = aLogText.begin(); ir2 != aLogText.end(); ){
		if( ir2->uAddedAt + uTimeLogItemStaysMs < uTmNow ){
			ir2 = aLogText.erase( ir2 );
		}else{
			++ir2;
		}
	}
}
void czm_UpdateFromConfigFile()
{
	assert( Czm );
	Czm->srSelfFullPath  = hxdw_GetModuleFileNameFromAddr( czm_UpdateFromConfigFile );
	Czm->srSelfDir       = hxdw_SplitPath( Czm->srSelfFullPath ).first;
	Czm->srSelfBaseName  = hxdw_SplitPath( Czm->srSelfFullPath ).second;
	Czm->srSelfIniPath   = hxdw_StrPrintf("%a\\%a.ini", { Czm->srSelfDir, ( hxdw_SplitExt(Czm->srSelfBaseName).first),});
	Czm->srSelfDbfPath   = hxdw_StrPrintf("%a\\%a.bin", { Czm->srSelfDir, ( hxdw_SplitExt(Czm->srSelfBaseName).first),});
	Czm->srSelfIniBFName = hxdw_SplitPath( Czm->srSelfIniPath ).second;
	{
		assert( Czm->pDbfs );
		bool rs2;
		rs2 = Czm->pDbfs->openDiskImage( Czm->srSelfDbfPath.c_str(), "");
		assert( rs2 && "Couldn't open configuration database [C4tzMoL]" );
		{
			//Czm->pDbfs->putVFileBytes2(
			//		Czm->srDllConfVFName.c_str(), (const uint8_t*)"", 0, "r" );
			std::vector<uint8_t> data2;
			data2 = Czm->pDbfs->getVFileBytes3( Czm->srDllConfVFName.c_str(), 0, {0,0,}, "c" );
			*Czm->ini2 = hxdw_ParseINIData( (const char*)&data2[0], -1 );
			if( hxdw_FileExists( Czm->srSelfIniPath.c_str() ) ){
				auto ini9 = hxdw_ParseINIFile( Czm->srSelfIniPath.c_str() );
				Czm->ini2->updateFrom( ini9 );
			}
		}{
			std::vector<uint8_t> data2;
			data2 = Czm->pDbfs->getVFileBytes3( Czm->srSettingsIniVFname.c_str(), 0, {0,0,}, "c" );
			auto ini4 = hxdw_ParseINIData( (const char*)&data2[0], -1 );
			Czm->se3.deserialize3( ini4 );
		}
	}{
		assert( Czm->ini2 );
		Czm->bShowStartupTip = std::atoi(
			Czm->ini2->getValue("s_main", "bShowStartupTip", "1").c_str() );
		Czm->bAllocConsoleFlag = std::atoi(
			Czm->ini2->getValue("s_main", "bAllocConsoleFlag", "0").c_str() );
		Czm->bStayDormant = std::atoi(
			Czm->ini2->getValue("s_main", "bStayDormant", "0").c_str() );
		Czm->bDbgFeaturesOn = std::atoi(
			Czm->ini2->getValue("s_main", "bDbgFeaturesOn", "0").c_str() );
		std::string sr2;
		if( !(sr2 = Czm->ini2->getValue("s_main", "anUIKeySuite", "116")).empty() ){
			Czm->anUIKeySuite = czm_DecodeHotKeySuite( sr2, {VK_F5,} );  // VK_F5=0x74=116_d
			assert( !Czm->anUIKeySuite.empty() );
		}
	}
}
/// Calculates program version from executable file contents via MD5 checksums in INI.
std::string czm_CalcProgramVersion()
{
	assert( Czm );
	assert( Czm->ini2 );
	const char* szUnkVerText = "unknown";
	std::string srMd5x;
	{
		std::vector<uint8_t> data2;
		data2 = hxdw_GetBinaryFileContents( Czm->srSelfFullPath.c_str(), 32*1000*1024 );
		if( data2.empty() ){
			return szUnkVerText;
		}
		{
			HxdwMd5 cMd5;
			cMd5.update2( &data2[0], (uint32_t) data2.size() );
			cMd5.finalize2();
			srMd5x = cMd5.getHexDigest();
		}
	}
	std::string srVersion;
	Czm->ini2->eachVariable( {"s_versions",},
		[&]( const char* sec_, const char* kname, const char* value2 )->bool{
			if( !hxdw_StrCmpOpt( srMd5x.c_str(), kname, -1, "i") ){
				srVersion = value2;
				return 0L;
			}
			return 1L;
	});
	if( srVersion.empty() ){
		return szUnkVerText;
	}
	return srVersion;
}
bool CzmHotPatchMgr::SHpDep::operator==( CZM_EHPT e )const
{
	return e == eHpTy2;
}
void CzmHotPatchMgr::
addHotPatchDependency( const std::vector<CZM_EHPT>& list2, const char* szGuid )
{
	assert( szGuid );
	assert( *szGuid );
	// check for ones already exitsting, add ref-count or create new.
	for( auto ir2 = list2.begin(); ir2 != list2.end(); ++ir2 ){
		auto ir3 = std::find( aHPatches.begin(), aHPatches.end(), *ir2 );
		if( ir3 == aHPatches.end() ){
			SHpDep hpd2;
			hpd2.eHpTy2  = *ir2;
			hpd2.pHPatch = czm_CreateHotPatchByType( *ir2 );
			hpd2.aGuids.push_back( szGuid );
			assert( hpd2.pHPatch );
			int rs2 = hpd2.pHPatch->install2();
			assert( !rs2 );
			aHPatches.push_back( hpd2 );
		}else{
			bool bExists = std::any_of( ir3->aGuids.begin(), ir3->aGuids.end(),
					[&]( const std::string& a )->bool{ return a == szGuid; } );
			if( !bExists ){
				ir3->aGuids.push_back( szGuid );
			}
		}
	}
}
void CzmHotPatchMgr::
removeHotPatchDependency( const std::vector<CZM_EHPT>& list2, const char* szGuid )
{
	assert( szGuid );
	assert( *szGuid );
	for( auto ir2 = list2.begin(); ir2 != list2.end(); ++ir2 ){
		auto ir3 = std::find( aHPatches.begin(), aHPatches.end(), *ir2 );
		if( ir3 != aHPatches.end() ){
			auto ir4 = std::find( ir3->aGuids.begin(), ir3->aGuids.end(), std::string(szGuid) );
			if( ir4 != ir3->aGuids.end() ){
				ir3->aGuids.erase(ir4);
				if( ir3->aGuids.empty() ){
					assert( ir3->pHPatch );
					int rs2 = ir3->pHPatch->uninstall2();
					assert( !rs2 );
					czm_DeleteHotPatch( ir3->pHPatch );
					aHPatches.erase( ir3 );
					//ir3 = aHPatches.end();
				}
			}
		}
	}
}
std::vector<int> czm_DecodeHotKeySuite( std::string inp, const std::vector<int>& dflt2 )
{
	std::vector<int> outp;
	std::vector<std::string> parts2;
	hxdw_StrExplode( inp.c_str(), parts2, {"+",",",}, 8, "\x20\t", "");
	for( auto ir2 = parts2.begin(); ir2 != parts2.end(); ++ir2 ){
		int key2 = atoi( ir2->c_str() );
		if( key2 ){
			outp.push_back( key2 );
		}
	}
	return outp;
}
bool
czm_TestHotKeyOnKeyDownMessage( const std::vector<int>& aSuite, int nFirstKeyFromMsg )
{
	assert( nFirstKeyFromMsg );
	auto b = std::find( aSuite.begin(), aSuite.end(), nFirstKeyFromMsg );
	if( b == aSuite.end() ){
		return 0L;
	}
	for( auto a = aSuite.begin(); a != aSuite.end(); ++a ){
		if( b != a ){
			if( !(0x8000 & GetKeyState(*a)) ){//GetAsyncKeyState
				return 0L;
			}
		}
	}
	return 1L;
}
bool czm_GetRE4CameraTrajectory( CzmRE4Vec* pCamPosOu, CzmRE4Vec* pCamTrgtOu )
{
	assert( Czm );
	assert( Czm->pCameraCtrl );
	assert( Czm->fnCameraControlxxgetTrajectory );
	assert( Czm->ppGD );
	assert( *Czm->ppGD );
	assert( pCamPosOu || pCamTrgtOu );
	static const CzmRE4Vec vZero = {0.f,0.f,0.f,};
	CzmRE4Vec dmy2, dmy3;
	pCamPosOu  = ( pCamPosOu  ? pCamPosOu  : &dmy2 );
	pCamTrgtOu = ( pCamTrgtOu ? pCamTrgtOu : &dmy3 );
	*pCamPosOu = *pCamTrgtOu = vZero;
/*
	int32_t nOrigFlag = ((**Czm->ppGD).flags_STATUS_0_501C.v & 0x40);
	(**Czm->ppGD).flags_STATUS_0_501C.v |= 0x40;
	uint32_t args2[2] = { (uint32_t)pCamPosOu, (uint32_t)&pCamTrgtOu, };
	czm_CallMemberFuncViaEcx( Czm->pCameraCtrl,
		Czm->fnCameraControlxxgetTrajectory, args2, 2 );
	(**Czm->ppGD).flags_STATUS_0_501C.v |= nOrigFlag;
	//*/
	//cCamera* m_pProc_710;

	if( *pCamPosOu == vZero && *pCamTrgtOu == vZero ){
		return 0L;
	}
	return 1L;
}
bool CzmGoldAutoDTO::ByUid2::operator()( const CzmGoldAutoDTO& inp )const
{
	return inp.uItemUid2 == uItemUid2;
	//return 1L;
}

