#pragma once
// To silence some macro redefinition warnings with MSVC2017.
// ref: https://stackoverflow.com/questions/14363929/vs2012-c-warning-c4005-useheader-macro-redefinition
//#define _USING_V110_SDK71_ 1
#include <windows.h>
#include <assert.h>
//#include <stdio.h>
//#include <ctime> //std::time()
//#include <mmsystem.h>   //PlaySound()
#include "MinHook.h"
#include "imgui.h"
#include "imgui_impl_win32.h"
#include "imgui_impl_dx9.h"
#include "hxdw_utils.h"
#include "czm_d3d9detour.h"
#include "czm_utils.h"

uint32_t czm_GpHaxInit();
uint32_t czm_GpHaxDeinit();
bool     czm_ScreenResolutionChanged( std::array<int,2> oldrez_, std::array<int,2> newrez_ );
bool     czm_DllDeInit();

struct CzmPkMsgArgs
{
	MSG* msg{};
	HWND hw2{};
	UINT wMsgFilterMin{};
	UINT wMsgFilterMax{};
	UINT wRemoveMsg{};
};
