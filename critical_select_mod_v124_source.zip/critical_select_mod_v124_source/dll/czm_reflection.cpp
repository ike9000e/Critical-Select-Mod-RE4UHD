#include "czm_reflection.h"

// Iterating over a struct in C++.
// ---------------------------------
// - ie. reflection to provide serialization of structures.
// - used provided JS script and generated for max struct size to be 99.
// - renamed identifiers and macros adding own prefix and suffix.
// https://stackoverflow.com/a/57746276
// https://stackoverflow.com/questions/17660095/iterating-over-a-struct-in-c/57746276#57746276
// >> Pamela; answered Sep 1, 2019 at 13:12
// >> I wrote a version without Boost or other third-
// >> party library, which has been tested using
// >> GCC 4.9(c++11), clang 5.0(c++11), VS 2008, VS 2019.
// - by default, maximum supported num of struct members: 64.
// - limit on macro nesting in MSVC 2017 prevents of limit increase to 128.


/*
	<script>
		// JS code that Generates helper macros.
		// Can be run in a web browser, either in debug console or as ".html" file.
		// Prints results to debug console.
		(function() {
		  const maxNumOfEle = 99;  //orig: 64
		  const mapNamePrefix = 'WPP_PP_MAP_'; //'_PP_MAP'
		  let codeText = '';

		  function formatNumWidth(num) {
			return ("0" + num).slice(-2);
		  }

		  function AddNewLine() {
			if (codeText.slice(-1) != ' ') {
			  codeText += ' ';
			}

			codeText += '\\\n';
			//codeText += ' '.repeat(5);
			codeText += '\t';
		  }

		  codeText += `#define ${mapNamePrefix}${formatNumWidth(1)}(f, x) f(x)\n`;
		  for (let i = 2; i <= maxNumOfEle; ++i) {
			let funId = formatNumWidth(i);
			codeText += `#define ${mapNamePrefix}${funId}(f, x, ...) f(x)`;

			let nextFunId = formatNumWidth(i - 1);
			codeText += ' WPP_PP_EVAL_(';
			codeText += `${mapNamePrefix}${nextFunId}(f, __VA_ARGS__)`;
			codeText += ')';

			codeText += '\n';
		  }

		  codeText += '\n#define WPP_PP_GET_NTH_ARG_(';
		  AddNewLine();
		  for (let i = 1; i <= maxNumOfEle; ++i) {
			codeText += `_${i}, `;
			if ((i % 10) == 0) {
			  AddNewLine();
			}
		  }
		  codeText += 'N, ...) N\n';

		  codeText += `\n#define ${mapNamePrefix}(f, ...) `;
		  codeText += 'WPP_PP_EVAL_(WPP_PP_EVAL_(WPP_PP_GET_NTH_ARG_(__VA_ARGS__,';
		  AddNewLine();
		  for (let i = maxNumOfEle; i >= 1; --i) {
			let funId = formatNumWidth(i);
			codeText += `${mapNamePrefix}${funId}`;
			if (i != 1) {
			  codeText += ', ';
			}

			if ((i % 5) == 1) {
			  AddNewLine();
			}
		  }
		  codeText += '))(f, __VA_ARGS__))\n';

		  console.log(codeText);
		})();

	</script>
*/

struct WppSDemo2
{
	WPP_OBJECT_NAME_METHOD(WppSDemo2)
	WPP_REFLECT(
		(int) a,
		(uint32_t) b,
		(std::string) c,
		(char) cLetter,
		(const char*) szSample2
	)
	//int d; // DO NOT WPP_REFLECT
};

/*
	Output:
	WppSDemo2.a: 10000
	WppSDemo2.b: 20000
	WppSDemo2.c: 30000
*/
void WppReflectioDemo()
{
	WppSDemo2 a = { 100, 200, "300", '\x10', "sample-2",};
	a.b = 0xFFFFFFFF;
	//WppAmplifier amplifierr;
	//amplifierr.apply2(&a);

	WppPrinter<> printerr;
	printerr.print2( a, [&]( std::string name2, std::string value2 ){
		printf("%s: [%s]\n", name2.c_str(), value2.c_str() );
	} );
}
