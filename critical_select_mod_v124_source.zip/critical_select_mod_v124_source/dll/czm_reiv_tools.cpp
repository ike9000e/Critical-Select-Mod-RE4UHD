#include "czm_reiv_tools.h"
#include <assert.h>
//#define _USE_MATH_DEFINES
#include <math.h>   //M_PI
//#include <cmath>   //M_PI
#include "hxdw_process.h"
#include "czm_interfaces.h"
#include "czm_utils.h"

extern void* czm_OgDelPrim;
//extern void* czm_OgSceAtFuncItem;
extern void* czm_OgSceAtCancelItemAt;
extern void* czm_OgSceAtPtr;
extern void* czm_OgSceAtItemEmItemDelete;
extern void* czm_OgSceAtDestroy;
//void czm_SceAtDeleteItem_Safe2( void* pItem );

uint32_t czm_SceAtCreateItemAt_Safe2( const CzmRE4Vec* vecpos, uint16_t nItemId, uint16_t nItemNum );

uint32_t czm_CallMemberFuncViaEcx( void* thisptr2, void* fnc2, uint32_t* pArgs, uint32_t nNumArgs )
{
	uint32_t retval;
	retval = 0;
	__asm{
			mov   ecx, 0
		lb_begin2:
			cmp   ecx, nNumArgs
			jz    lb_done2
			mov   eax, pArgs
			mov   eax, [eax+ecx*4]
			push  eax
			inc   ecx
			jmp   lb_begin2
		lb_done2:
			mov ecx, thisptr2   ;// this-ptr in ECX
			call fnc2
			mov retval, eax
	}
	return retval;
}
/**
	Returns forward, not rotated, normal of RE4UHD player character.
	Returned vector can be rotated by ''(**Czm->ppPlayerGD).rotation_A0.v.y'',
	which is ''CzmRE4Enemy::rotation_A0::v::y'',
	to get the current, live rotation of the player character.
*/
const CzmRE4Vec& czm_GetRE4ForwardNormal()
{
	static CzmRE4Vec vxx = { 0.f, 0.f, -1.f,};
	return vxx;
}
const CzmRE4Vec& czm_GetRE4UpwardNormal()
{
	static CzmRE4Vec vxx = { 0.f, 1.f, 0.f,};
	return vxx;
}
float czm_GetRE4LeonHeight()
{
	return 1800.f;
}
double czm_Pi()
{
	//double pi_v = 3.14159265358979323846;   // pi // M_PI
	//const double pi_v = acos(-1);
	static const double pi_v = ( atan(1.0) * 4.0 );
	return pi_v;
}
/// Converts position. Returns f32 vector.
CzmRE4Vec czm_ConvRE4SvecToPos( const CzmRE4Svec& vec16 )
{
	CzmRE4Vec ou2;
	ou2.x = float( static_cast<double>( vec16.x ) * 10.0 );
	ou2.y = float( static_cast<double>( vec16.y ) * 10.0 );
	ou2.z = float( static_cast<double>( vec16.z ) * 10.0 );
	return ou2;
}
CzmRE4Svec czm_ConvPosToRE4Svec( const CzmRE4Vec& vec )
{
	CzmRE4Svec outp;
	static_assert( std::is_same<decltype(outp.x),int16_t>::value, "");
	outp.x = int16_t( static_cast<double>( vec.x ) / 10.0 );
	outp.y = int16_t( static_cast<double>( vec.y ) / 10.0 );
	outp.z = int16_t( static_cast<double>( vec.z ) / 10.0 );
	return outp;
}
double czm_GetRE4RotationFactor()
{
	// auto pFltSix = (float*)hxdw_GetPtrGivenInSectionOffset( 0, 0, ".data", 0xE3F4 );
	// assert( *pFltSix == 6.2831855f );
	constexpr float fFltSix = 6.2831855f;
	constexpr double v11 = double(fFltSix) * 0.000030517578125;
	return v11;
}
CzmRE4Vec czm_ConvRE4SvecToRotation( const CzmRE4Svec& vec16 )
{
	CzmRE4Vec outp;
	const double fctr = czm_GetRE4RotationFactor();
	outp.x = float( static_cast<double>(vec16.x) * fctr );
	outp.y = float( static_cast<double>(vec16.y) * fctr );
	outp.z = float( static_cast<double>(vec16.z) * fctr );
	return outp;
}
CzmRE4Svec czm_ConvRotationToRE4Svec( const CzmRE4Vec& vec )
{
	CzmRE4Svec out2;
	const double fctr = czm_GetRE4RotationFactor();
	out2.x = int16_t( static_cast<double>(vec.x) / fctr );
	out2.y = int16_t( static_cast<double>(vec.y) / fctr );
	out2.z = int16_t( static_cast<double>(vec.z) / fctr );
	return out2;
}
const std::vector< std::tuple<CZM_EWT,std::string,std::string> > CzmWeaponNames = {
	{CZM_EWT::CZM_E3_Punisher,"CZM_E3_Punisher","Punisher",},
	{CZM_EWT::CZM_E3_Handgun,"CZM_E3_Handgun","Handgun",},
	{CZM_EWT::CZM_E3_Red9,"CZM_E3_Red9","Red9",},
	{CZM_EWT::CZM_E3_Blacktail,"CZM_E3_Blacktail","Blacktail",},
	{CZM_EWT::CZM_E3_Matilda,"CZM_E3_Matilda","Matilda",},
	{CZM_EWT::CZM_E3_TMP,"CZM_E3_TMP","T.M.P.",},
	{CZM_EWT::CZM_E3_Kick,"CZM_E3_Kick","Kick",},
	{CZM_EWT::CZM_E3_Knife,"CZM_E3_Knife","Knife",},
	{CZM_EWT::CZM_E3_ChicagoTypewriter,"CZM_E3_ChicagoTypewriter","ChicagoTypewriter",},
	{CZM_EWT::CZM_E3_RocketLauncher,"CZM_E3_RocketLauncher","RocketLauncher",},
	{CZM_EWT::CZM_E3_RiffleSemiauto,"CZM_E3_RiffleSemiauto","RiffleSemiauto",},
	{CZM_EWT::CZM_E3_HuntingRiffle,"CZM_E3_HuntingRiffle","HuntingRiffle",},
	{CZM_EWT::CZM_E3_BrokenButterfly,"CZM_E3_BrokenButterfly","BrokenButterfly",},
	{CZM_EWT::CZM_E3_Killer7,"CZM_E3_Killer7","Killer7",},
	{CZM_EWT::CZM_E3_Handcannon,"CZM_E3_Handcannon","Handcannon",},
	{CZM_EWT::CZM_E3_MineThrower,"CZM_E3_MineThrower","MineThrower",},
	{CZM_EWT::CZM_E3_Shotgun,"CZM_E3_Shotgun","Shotgun",},
	{CZM_EWT::CZM_E3_Striker,"CZM_E3_Striker","Striker",},
	{CZM_EWT::CZM_E3_RiotGun,"CZM_E3_RiotGun","RiotGun",},
	{CZM_EWT::CZM_E3_Explosion,"CZM_E3_Explosion","Explosion",},
	{CZM_EWT::CZM_E3_FlashGrenade,"CZM_E3_FlashGrenade","FlashGrenade",},
};
std::string czm_GetWeaponTypeName2( CZM_EWT eWeaponType, bool bGetAsEnum )
{
	for( auto ir2 = CzmWeaponNames.begin(); ir2 != CzmWeaponNames.end(); ++ir2 ){
		if( eWeaponType == std::get<0>( *ir2 ) ){
			return (bGetAsEnum ? std::get<1>( *ir2 ) : std::get<2>( *ir2 ));
		}
	}
	return "<unknown_7GHrlY>";
}
CzmPair<bool,CZM_EWT>
czm_GetWeaponTypeByIndex( size_t index2 )
{
	if( index2 < CzmWeaponNames.size() ){
		CZM_EWT eWeaponType = std::get<0>( CzmWeaponNames[index2] );
		return { 1L, eWeaponType,};
	}
	return { 0L, CZM_EWT::CZM_E3_Punisher,};  // not found, unknown
}
size_t czm_GetWeaponTypeCount()
{
	return CzmWeaponNames.size();
}
std::vector< CzmPair<CZM_EWGR,std::vector<CZM_EWT> > >
CzmWeaponGroups = {
	{ CZM_EWGR::CZM_E5_Pistols, {
		CZM_EWT::CZM_E3_Punisher,
		CZM_EWT::CZM_E3_Handgun,
		CZM_EWT::CZM_E3_Red9,
		CZM_EWT::CZM_E3_Blacktail,
		CZM_EWT::CZM_E3_Matilda,
		},},
	{ CZM_EWGR::CZM_E5_Shotguns, {
		CZM_EWT::CZM_E3_Shotgun,
		CZM_EWT::CZM_E3_Striker,
		CZM_EWT::CZM_E3_RiotGun,
	},},
	{ CZM_EWGR::CZM_E5_Rifles, {
		CZM_EWT::CZM_E3_RiffleSemiauto,
		CZM_EWT::CZM_E3_HuntingRiffle,
	},},
	{ CZM_EWGR::CZM_E5_Magnums, {
		CZM_EWT::CZM_E3_BrokenButterfly,
		CZM_EWT::CZM_E3_Killer7,
		CZM_EWT::CZM_E3_Handcannon,
		CZM_EWT::CZM_E3_MineThrower,
	},},
	{ CZM_EWGR::CZM_E5_Mele, {
		CZM_EWT::CZM_E3_Kick,
		CZM_EWT::CZM_E3_Knife,
		},},
	{ CZM_EWGR::CZM_E5_Explosives, {
		CZM_EWT::CZM_E3_Explosion,
		CZM_EWT::CZM_E3_FlashGrenade,
		CZM_EWT::CZM_E3_RocketLauncher,
		},},
	{ CZM_EWGR::CZM_E5_CheatWeapons, {
		CZM_EWT::CZM_E3_Handcannon,
		CZM_EWT::CZM_E3_ChicagoTypewriter,
		},},
};

std::vector<CZM_EWT>
czm_GetWeaponGroupTypeWeapons( CZM_EWGR eWpnGrTy )
{
	std::vector<CZM_EWT> outp;
	auto ir2 = CzmWeaponGroups.begin();
	for( ; ir2 != CzmWeaponGroups.end(); ++ir2 ){
		if( **ir2 == eWpnGrTy ){
			outp = ir2->second;
			break;
		}
	}
	return outp;
}
std::vector<CZM_EWT>
czm_CnvWeaponTypeIndexesToTypes( const std::vector<int>& aIndexes )
{
	std::vector<CZM_EWT> outp;
	size_t idx = 0;
	for( auto flg : aIndexes ){
		if(flg){
			auto rs2 = czm_GetWeaponTypeByIndex( idx );
			assert( *rs2 );
			outp.push_back( +rs2 );
		}
		idx++;
	}
	return outp;
}

CzmEnemyFactory::CzmEnemyFactory()
{
	{
		// cEm *__thiscall cManager_cEm_::create( cManager_cEm_ *this, uint32_t id );
		// - this-pointer via ECX.
		assert( !fnRE4CManagerCreate );
		void* pAtOpCode = hxdw_GetPtrGivenInSectionOffset( 0, 0, ".text", 0x1B1350 );
		fnRE4CManagerCreate = pAtOpCode;
		assert( fnRE4CManagerCreate );
	}{
		// cManager_cEm_::deleteList(cManager_cEm_ *this, cEm *a2)
		// fnRE4CManagerDeleteList -> .text+0x1AE180
		assert( !fnRE4CManagerDeleteList );
		void* pAtOpCode = hxdw_GetPtrGivenInSectionOffset( 0, 0, ".text", 0x1AE180 );
		fnRE4CManagerDeleteList = pAtOpCode;
		assert( fnRE4CManagerDeleteList );
	}{
		// void __cdecl killEm(int a1)
		// fnRE4KillEm -> .text+0x1AE650
		assert( !fnRE4KillEm );
		void* pAtOpCode = hxdw_GetPtrGivenInSectionOffset( 0, 0, ".text", 0x1AE650 );
		fnRE4KillEm = pAtOpCode;
		assert( fnRE4KillEm );
	}{
		assert( !pEmMgr );
		pEmMgr = (CzmRE4EnmyMgr*)hxdw_GetPtrGivenInSectionOffset( 0, 0, ".data", 0xAB04 );
		assert( pEmMgr );
	}
}
CzmRE4Enemy* CzmEnemyFactory::
callCManagerCreate( void* fnRE4CManagerCreate2, void** ppEmMgr2, uint32_t uTypeId )
{
	CzmRE4Enemy* retval = nullptr;
	retval = (CzmRE4Enemy*)czm_CallMemberFuncViaEcx(
			ppEmMgr2, fnRE4CManagerCreate2, &uTypeId, 1 );
	return retval;
}

/**
	Creates live enemy in the game.
	Should be called from the game main thread.
	Alternativelly, from a game task (no how-to currently).
	Code based on EmSetFromList2().
	Calls cManager_cEm_::create() via fnRE4CManagerCreate ptr.
	Returns global id of the enemy created, CzmRE4Enemy::guid_F8;
	or 0 on error.
*/
uint32_t CzmEnemyFactory::createLiveEnemy2( const CzmRE4EmList& sEmListIn )
{
	assert( fnRE4CManagerCreate );
	assert( pEmMgr );
	assert( Czm && Czm->ppGD );
	assert( *Czm->ppGD );
	CzmRE4EmList sEmList = sEmListIn;
	sEmList.room_18 = (**Czm->ppGD).curRoomId_4FAC.v;

	//CzmRE4Enemy=EM_LIST
	CzmRE4Enemy* pNewEnm = callCManagerCreate( fnRE4CManagerCreate, (void**)pEmMgr, sEmList.id_1 );
	if( !pNewEnm ){
		return 0;
	}

	SOwnEnm sEnm;
	sEnm.pEnm5  = pNewEnm;
	sEnm.nEnmId = uNextEnmId++;
	mEnmLs.push_back( sEnm );
	//
	assert( pNewEnm->id_100.v == sEmList.id_1 );
	pNewEnm->type_101.v = sEmList.type_2;
	pNewEnm->set_395.v = sEmList.set_3;
	pNewEnm->flag_3D0.v = sEmList.flag_4;
	pNewEnm->characterNum_3D8.v = sEmList.Character_B;
	pNewEnm->Guard_r_3D4.v = float( static_cast<double>(sEmList.Guard_r_1A) * 1000.0 );
	pNewEnm->hp_324.v = sEmList.hp_8;
	pNewEnm->hp_max_326.v = sEmList.hp_8;
	//v8=Back=CzmRE4Enemy=cEm
	pNewEnm->rotation_A0.v = czm_ConvRE4SvecToRotation( sEmList.s_ang_12 );
	pNewEnm->position_94.v = czm_ConvRE4SvecToPos( sEmList.s_pos_C );
	// originally, index in the global ESL list.
	pNewEnm->emListIndex_3A0.v = 0xFF;//0xFF//0//0xFF//0x51//0x52
	pNewEnm->pos_old_110.v = pNewEnm->position_94.v;
	//
	// sEmList.be_flag_0 |= 2u;
	// sEmList.be_flag_0 |= ?
	//
	//assert( Czm );
	//assert( Czm->ppPlayerGD );
	//assert( *Czm->ppPlayerGD );
	//CzmRE4Enemy* pPlyr = *Czm->ppPlayerGD;
	//CzmRE4Enemy* pPlyr = pPlayer;
	//assert( pPlyr );
	// possibly just distance calculation on 2D, x-z plane.
	//
	CzmRE4Vec vpx = czm_ConvRE4SvecToPos( sEmList.s_pos_C );
	float v17 = vpx.x - pNewEnm->position_94.v.x;
	float v18 = vpx.z - pNewEnm->position_94.v.z;
	pNewEnm->l_pl_378.v = v18 * v18 + v17 * v17;
	pNewEnm->l_sub_37C.v = float( 1.0e16 );

	// Getting the move() virtual member function pointer:
	// (ECX -> this pointer, cEm*)
	//     // esi = cManager(...)
	//     mov     edx, [esi]       ; get vtable, the 1st pointer in the object.
	//     mov     eax, [edx+10h]   ; DWORD PTR [vtable+0x10]
	//     call    eax
	void* fnMoveAt4 = ((void***)pNewEnm)[0][4];
	assert( fnMoveAt4 );
	czm_CallMemberFuncViaEcx( pNewEnm, fnMoveAt4, nullptr, 0 );
	// CzmRE4Enemy::guid_F8::v : uint32_t
	assert( pNewEnm->guid_F8.v );
	return pNewEnm->guid_F8.v;
}

void CzmEnemyFactory::destroyLastLiveEnemy2()
{
	if( mEnmLs.empty() ){
		return;
	}
	size_t idx = mEnmLs.size() - 1;
	aDelListByIndex.push_back( idx );
}
bool CzmEnemyFactory::destroyEnemyByIndex9( size_t index2 )
{
	assert( index2 < mEnmLs.size() );

	auto ir2 = mEnmLs.begin();
	std::advance( ir2, index2 );

	SOwnEnm sEnm = *ir2;
	CzmRE4Enemy* pLastEnCrtd = sEnm.pEnm5;
	assert( pLastEnCrtd );
	mEnmLs.resize( mEnmLs.size() - 1 );
	//
	using fn_t = void (__cdecl*)(void* pEnmy);
	assert( fnRE4KillEm );
	((fn_t)fnRE4KillEm)( pLastEnCrtd );
	{
		assert( pEmMgr );
		auto lmbGetEnemyAt = [&]( uint32_t ii3 ) -> CzmRE4Enemy* {
			CzmRE4Enemy* enm4 = (CzmRE4Enemy*) ( ((uint8_t*)pEmMgr->m_Array_4.v) + ii3 * pEmMgr->m_blockSize_C.v );
			return enm4;
		};
		for( uint32_t ii2=0; ii2 < pEmMgr->m_nArray_8.v; ii2++ ){
			CzmRE4Enemy* enm3 = lmbGetEnemyAt( ii2 );
			if( enm3 == pLastEnCrtd ){
				czm_Print2("CZM: removing enemy, idx:[%a]\n", { ii2,} );
				enm3->hp_324.v = 0;
			}
		}
	}
	return 1L;
}

bool CzmEnemyFactory::enumerateEnemyList(
		std::function<void( const CzmEnmDTO& )> calb2,
		const char* flags2
		)
{
	flags2 = (flags2 ? flags2 : "");
	for( auto ir2 = mEnmLs.begin(); ir2 != mEnmLs.end(); ++ir2 ){
		bool bBreak = 0L;
		CzmEnmDTO dto2;
		dto2.pEnm4   = ir2->pEnm5;
		dto2.bBreak2 = &bBreak;
		calb2( dto2 );
		if(bBreak)
			break;
	}
	return 1L;
}
void CzmEnemyFactory::frameMoveEnmFactory()
{
	if( !aDelListByIndex.empty() ){
		for( auto a = aDelListByIndex.begin(); a != aDelListByIndex.end(); ++a ){
			size_t index2 = *a;
			czm_Print2("DeleteEnm-3 %d\n", { index2,} );
			assert( index2 < mEnmLs.size() );
			auto b = mEnmLs.begin();
			std::advance( b, index2 );
			destroyEnemyByIndex9( index2 );
		}
		aDelListByIndex.clear();
	}
	if( !aAddListByType.empty() ){
		for( auto a = aAddListByType.begin(); a != aAddListByType.end(); ++a ){
			;
		}
	}
}
//CzmRE4Enemy::id_100
std::string czm_RE4EnemyToStr( const CzmRE4Enemy* inp )
{
	char bfr2[256];
	snprintf( bfr2, sizeof(bfr2),
		"[%02X,%02X] h:%4d/%-4d, uid:%3u, "
			"F:%08X-%08X-%08X",
		inp->id_100.v,
		inp->type_101.v,
		inp->hp_324.v,
		inp->hp_max_326.v,
		inp->guid_F8.v,
		inp->flag_3D0.v,
		inp->be_flag_4.v,
		inp->m_StatusFlag_3CC.v
		//inp->Item_id_3DE.v,
		//inp->Item_num_3E0.v,
		//inp->Item_flg_3E2.v,
		//inp->Auto_item_flg_3E4.v,
		//inp->flags_3E8.v
		);
	return bfr2;
}
template<class Tff>
Tff* czm_Vec3Normalize2( Tff* result, const Tff* v0 )
{
	//MSQRT
	Tff l = std::sqrt( v0[0] * v0[0] + v0[1] * v0[1] + v0[2] * v0[2] );
	result[0] = v0[0] / l;
	result[1] = v0[1] / l;
	result[2] = v0[2] / l;
	return result;
}
template<class Tff>
Tff* czm_Vec3Rotate2( Tff* result, const Tff* v0, const Tff* ra, Tff f )
{
	Tff cs;
	Tff sn;
	Tff x;
	Tff y;
	Tff z;
	Tff rx;
	Tff ry;
	Tff rz;
	Tff ra2[3] = { ra[0], ra[1], ra[2],};
	cs = std::cos(f);  //MCOS
	sn = std::sin(f);  //MSIN
	x = v0[0];
	y = v0[1];
	z = v0[2];
	czm_Vec3Normalize2( ra2, ra2 );
	rx = ra2[0];
	ry = ra2[1];
	rz = ra2[2];
	result[0] = x * (cs + rx * rx * (1 - cs)) + y * (rx * ry * (1 - cs) - rz * sn) + z * (rx * rz * (1 - cs) + ry * sn);
	result[1] = x * (ry * rx * (1 - cs) + rz * sn) + y * (cs + ry * ry * (1 - cs)) + z * (ry * rz * (1 - cs) - rx * sn);
	result[2] = x * (rz * rx * (1 - cs) - ry * sn) + y * (rz * ry * (1 - cs) + rx * sn) + z * (cs + rz * rz * (1 - cs));
	return result;
}
template float* czm_Vec3Rotate2<float>( float* result, const float *v0, const float *ra, float f );
template double* czm_Vec3Rotate2<double>( double* result, const double *v0, const double *ra, double f );

/// Rotates input vector 'vc0' at axis specified by 'vra' by the angle
/// specified in 'fAngle'.
/// \param fAngle - angle in radians, a value from 0 to 2 pi.
CzmRE4Vec czm_Vec3Rotate3( const CzmRE4Vec& vc0, const CzmRE4Vec& vra, float fAngle )
{
	CzmRE4Vec outp;
	czm_Vec3Rotate2<float>( &outp.x, &vc0.x, &vra.x, fAngle );
	return outp;
}
CzmRE4Vec czm_Vec3Normalize3( const CzmRE4Vec& vec0 )
{
	CzmRE4Vec out2;
	czm_Vec3Normalize2<float>( &out2.x, &vec0.x );
	return out2;
}

CzmRE4Vec czm_GetCurrentForwardNormal( CzmRE4Vec* pRttn32Out, CzmRE4Svec* pRttn16Out )
{
	assert( Czm );
	assert( Czm->ppPlayerGD );
	assert( *Czm->ppPlayerGD );
	CzmRE4Vec vr2 = (**Czm->ppPlayerGD).rotation_A0.v;
	CzmRE4Vec vnrm2;
	vnrm2 = czm_Vec3Rotate3( czm_GetRE4ForwardNormal(),
				czm_GetRE4UpwardNormal(), vr2.y + float(czm_Pi()) );
	czm_Vec3Normalize2( &vnrm2.x, &vnrm2.x );
	if( pRttn32Out ){
		*pRttn32Out = vr2;
	}
	if( pRttn16Out ){
		*pRttn16Out = czm_ConvRotationToRE4Svec( vr2 );
	}
	return vnrm2;
}
CzmRE4Vec
czm_GetCommonRelativePos( CZM_ECmRelPos eCrp,
		CzmRE4Svec* pPos16Out,
		CzmRE4Vec* pRttn32Out, CzmRE4Svec* pRttn16Out )
{
	assert( Czm );
	assert( Czm->ppPlayerGD );
	assert( *Czm->ppPlayerGD );
	if( eCrp == CZM_ECRP_AtPlayer || eCrp == CZM_ECRP_AtPlayerHeading ){
		CzmRE4Vec vpos2 = (**Czm->ppPlayerGD).position_94.v;
		if( eCrp == CZM_ECRP_AtPlayerHeading ){
			CzmRE4Vec vnrm2;
			vnrm2 = czm_GetCurrentForwardNormal( pRttn32Out, pRttn16Out );
			vpos2 = vpos2 + (vnrm2 * (3.f * czm_GetRE4LeonHeight()));
		}
		if( pPos16Out ){
			*pPos16Out = czm_ConvPosToRE4Svec( vpos2 );
		}
		return vpos2;
	}
	assert(!"Unexpected branch reached [P07cbkn]");
	return CzmRE4Vec{0,0,0,};
}
// 0x78 - treasure box (s)
// 0x79 - treasure box (l)
// 0x71 - gold bars
static const std::vector<std::pair<uint32_t,double> > CzmRE4GoldPickupScaling = {
		{ CZM_EIT::CZM_E9_TreasureBoxS_78, 10.0, },
		{ CZM_EIT::CZM_E9_TreasureBoxL_79, 100.0, },
		{ CZM_EIT::CZM_E9_GoldBars_71, 1000.0, },
};
/**
	Checks whenever item type is gold|pesetas pickup.
	Includes gold bars and treasure boxes.
	\sa czm_GetRE4GoldPickupPesetasValue()
*/
bool czm_IsRE4GoldItemType( uint32_t uItemType_, double* fScaling )
{
	auto endd = CzmRE4GoldPickupScaling.end();
	auto ir2 = std::find_if( CzmRE4GoldPickupScaling.begin(), endd,
		[&]( const std::pair<uint32_t,double>& inp ){
			return uItemType_ == inp.first;
		});
	if( ir2 != endd ){
		if( fScaling ){
			*fScaling = ir2->second;
		}
		return 1L;
	}
	return 0L;
}
int czm_GetRE4GoldPickupPesetasValue( uint32_t uItemType_, uint32_t uAmount )
{
	double fScaling = 0.0;
	if( !czm_IsRE4GoldItemType( uItemType_, &fScaling ) ){
		return 0;
	}
	assert( fScaling > 0.0 );
	int value2 = [&](){
		if( uItemType_ == CZM_EIT::CZM_E9_GoldBars_71 ){
			return std::max<int>( 5000, int( uAmount * fScaling ) );
		}else{
			uAmount = ( !uAmount ? 1 : uAmount );
			return int( uAmount * fScaling );
		}
	}();
	return value2;
}
/**
	Enumerates live item pickups in the room.
*/
void czm_RE4EnumerateItemPickups( std::function<void(const CzmPickupDTO&)> calb2 )
{
	// code based on ''DelPrim(pS + 0x8C, a1)''.
	assert( Czm );
	assert( Czm->pGlbPicups );
	uint32_t* ptr2 = Czm->pGlbPicups;
	bool bBreak = 0L;
	for( ; ptr2 && ((uint32_t)ptr2) != 0xFFFFFFFF; ){
		CzmPickupDTO dto3;
		dto3.pItem   = (CzmRE4SceAtDataItem*)ptr2; //SCE_AT_DATA
		dto3.bBreak3 = &bBreak;
		calb2( dto3 );
		if(bBreak)
			break;
		ptr2 = (uint32_t*) (((uint32_t)ptr2) & 0xFFFFFFFE);
		ptr2 = (uint32_t*) ( *ptr2 );
	}
}
void CzmLivePickupInspector::
protectItemsFromAutoDelExcept( uint8_t uUidItemToSkip )
{
	assert( aISnapshot.empty() );
	assert( mUidItemToSkip == -1 );
	mUidItemToSkip = (int) uUidItemToSkip;
	czm_RE4EnumerateItemPickups( [&]( const CzmPickupDTO& inp ){
		const uint8_t uItemUid = inp.pItem->unk_uid_u8_36.v;
		if( uItemUid != uUidItemToSkip ){
			aISnapshot.push_back( SSnpsht{
					uItemUid,
					inp.pItem->position_vec_5C.v,
					inp.pItem->flags_field_84.v,
					inp.pItem,});
			// code based on SceAtItemEmItemDelete()
			// if ( (v0[0x34] & 1) != 0 && v0[0x35] == 3 && (v0[0x84] & 0x20) != 0 )
			// pADPtr2->flags_34.v |= 0x1; : uint8_t
			//mark to prevent auto deletion.
			//inp.pItem->flags_34.v = 0;
			inp.pItem->flags_field_84.v &= ~0x20;
		}//*/
	});
}
void CzmLivePickupInspector::restoreItemStates()
{
	assert( mUidItemToSkip != -1 );
	czm_RE4EnumerateItemPickups( [&]( const CzmPickupDTO& inp ){
		const uint8_t uItemUid = inp.pItem->unk_uid_u8_36.v;
		if( uItemUid != (uint8_t)mUidItemToSkip ){
			std::vector<SSnpsht>::iterator ir2;
			ir2 = std::find_if(
					aISnapshot.begin(), aISnapshot.end(),
					ByUidVec( inp.pItem ) );
			//assert( ir2 != aISnapshot.end() );
			if( ir2 != aISnapshot.end() ){
				// restore the original value.
				//inp.pItem->flags_34.v = ir2->uFlagsXOrig;
				inp.pItem->flags_field_84.v = ir2->uFlagsXOrig;
			}else{
				//czm_Print2("CZM: no item match, uid:%d [p3h1gv]\n", {
				//		(int)inp.pItem->unk_uid_u8_36.v,});
			}
		}
	});
}
CzmLivePickupInspector::ByUidVec::ByUidVec( CzmRE4SceAtDataItem* ptr_ )
	: mPtr(ptr_)
{
}//*/
bool CzmLivePickupInspector::ByUidVec::operator()( const CzmLivePickupInspector::SSnpsht& inp )const
{
	return mPtr->unk_uid_u8_36.v == inp.uItmUid3 &&
		mPtr->position_vec_5C.v == inp.vPosOrig;
	//return mPtr->unk_uid_u8_36.v == inp.uItmUid3;
	//return mPtr == inp.mPtr2;
}
/// Returns as pair, pointer to data struct and item identifier.
/// On error, returns the 'second' memeber set to nullptr.
CzmPair<uint8_t,CzmRE4SceAtDataItem*>
czm_CreateLiveRE4Item( uint16_t uItemType, uint16_t uItemNum, const CzmRE4Vec& pos2 )
{
	// Original SceAtCreateItemAt() allocates memory and
	// returns mem pointer value added with 0x36.
	// (Eg. 0x04: handgun ammo (the red box).)
	assert( Czm && Czm->pGlbPicups );

	uint32_t uItmUidBt;
	uItmUidBt = czm_SceAtCreateItemAt_Safe2( &pos2, uItemType, uItemNum );
	if( uItmUidBt >= 0xFF ){  //0xFFFFFFFF
		czm_Print2("CZM: ERROR: item not created, SceAtCreateItemAt() failed [mJv0Cm]\n", {});
		return { 0xFF, nullptr,};
	}
	using fnc5_t = CzmRE4SceAtDataItem*(__cdecl*)( uint32_t );
	assert( czm_OgSceAtPtr );
	CzmRE4SceAtDataItem* pMemPtr3 = nullptr;
	pMemPtr3 = ((fnc5_t)czm_OgSceAtPtr)( uItmUidBt ); //SceAtPtr()
	if( !pMemPtr3 ){
		czm_Print2("CZM: ERROR: item not created, SceAtPtr() failed [ACw61u]\n", {});
		//return { 0xFF, nullptr,};
		return { (uint8_t)uItmUidBt, nullptr,};
	}
	assert( pMemPtr3 );
	assert( pMemPtr3->unk_uid_u8_36.v == uItmUidBt );

	pMemPtr3->flags_field_84.v &= ~0x20; // clearing the auto cleanup flag.

	//CzmRE4SceAtDataItem* pMemPtr = (CzmRE4SceAtDataItem*)( pPtrPlus36h - 0x36);
	//CzmRE4SceAtDataItem* pMemPtr;
	//pMemPtr = (CzmRE4SceAtDataItem*) ( *Czm->pGlbPicups );
	{
		char bfr2[128];
		snprintf( bfr2, sizeof(bfr2), "0x%X", (uint32_t)pMemPtr3 );
		czm_Print2("CZM: czm_CreateLiveRE4Item() end, id:%d, ptr: %s\n",
			{ (int)uItmUidBt, std::string(bfr2),});
	}
	return { (uint8_t)uItmUidBt, pMemPtr3,};
}
CzmPair<uint8_t,CzmRE4SceAtDataItem*>
czm_CreateLiveRE4TestItem()
{
	CzmRE4Vec vPos;
	vPos = czm_GetCommonRelativePos( CZM_ECRP_AtPlayerHeading, 0,0,0);
	return czm_CreateLiveRE4Item( 0x04, 9, vPos );
}
bool
czm_DeleteLiveRE4Item( uint8_t uItemIdent )
{
	using fnc5_t = CzmRE4SceAtDataItem*(__cdecl*)( uint32_t );
	assert( czm_OgSceAtPtr );
	CzmRE4SceAtDataItem* pADPtr2;
	pADPtr2 = ((fnc5_t)czm_OgSceAtPtr)( uItemIdent ); //SceAtPtr()
	if( !pADPtr2 ){
		czm_Print2("CZM: ERROR: cannot delete, item id not found [86gUUn]\n", { (int)uItemIdent,});
		return 0L;
	}
	int cnt2 = 0;
	{
		bool bExists = 0L;
		czm_RE4EnumerateItemPickups( [&]( const CzmPickupDTO& inp ){
			cnt2++;
			if( inp.pItem == pADPtr2 ){
				bExists = 1L;
				*inp.bBreak3 = 1L;
			}
			//czm_Print2("CZM: Item: uid:%a, type:%a, n:%a [v4ILnp]\n", {
			//		(int)inp.pItem->unk_uid_u8_36.v,
			//		czm_ToStrFmt("0x%X", (int)inp.pItem->item_id_u16_78.v ),
			//		(int)inp.pItem->item_num_u16_7C.v,});
		});
		if(bExists){
			czm_Print2("CZM: found pADPtr2 to delete.\n", {});
		}
		assert( bExists );//*/
	}
	{
		// code based on SceAtItemEmItemDelete()
		// if ( (v0[0x34] & 1) != 0 && v0[0x35] == 3 && (v0[0x84] & 0x20) != 0 )
		pADPtr2->flags_field_84.v |= 0x20;
		if( czm_IsRE4GoldItemType( pADPtr2->item_id_u16_78.v, 0 ) ){
			pADPtr2->flags_34.v |= 0x1;
			//pADPtr2->field_35.v = 3;
			//pADPtr2->field_35.v = 0xB;
			//uint8_t* ptr3 = (uint8_t*)pADPtr2;
			//ptr3[0x80] = 1;
			//ptr3[0x81] = 1;
		}
	}
	czm_Print2("CZM: czm_DeleteLiveRE4Item(), ptr:%a, uid:%a, cnt2:%a\n",
		{ czm_ToStrFmt("0x%X", (uint32_t)pADPtr2),
			int(uItemIdent), cnt2,});

	//using fnc7_t = void(__cdecl*)( void* );
	//assert( czm_OgSceAtCancelItemAt );
	//((fnc7_t)czm_OgSceAtCancelItemAt)( pADPtr2 );
	{
		CzmLivePickupInspector lii2;
		lii2.protectItemsFromAutoDelExcept( uItemIdent );
		std::shared_ptr<void*> raii2( nullptr, [&]( void* ){
			lii2.restoreItemStates();
		});
	//	assert( czm_OgSceAtDestroy );
	//	using fnc9_t = char(__cdecl*)( uint32_t );
	//	((fnc9_t)czm_OgSceAtDestroy)( uItemIdent );

		assert( czm_OgSceAtItemEmItemDelete );
		using fnc8_t = uint32_t(__cdecl*)();
		((fnc8_t)czm_OgSceAtItemEmItemDelete)();

	//	assert( czm_OgDelPrim );
	//	using fnc6_t = void(__cdecl*)( void*, void* pItemToDel_ );
	//	((fnc6_t)czm_OgDelPrim)( Czm->pGlbPicups, pADPtr2 );
	}
	return 1L;
}



