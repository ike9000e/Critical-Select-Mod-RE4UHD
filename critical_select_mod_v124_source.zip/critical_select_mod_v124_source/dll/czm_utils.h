#pragma once
#include <string>
#include <vector>
#include <array>
#include <inttypes.h>
#include "hxdw_utils.h"
#include "czm_interfaces.h"
#include "czm_description.h"

struct IDirect3DDevice9; struct ImGuiContext; struct hxdw_IniData2;
struct FpDiskImage; struct CzmSettings; struct CzmWndGeomMgr;
struct CzmEnemyFactory;

uint32_t    czm_Win32DetoursInit();
uint32_t    czm_Win32DetoursDeinit();
bool        czm_Print2( const char* fmt, const std::vector<HxdwPrintAdp> args4 );
bool        czm_AnySystemModkeyDown( const std::vector<int>& aExcept );
void        czm_UpdateFromConfigFile();
std::string czm_CalcProgramVersion();
std::string czm_ToStrFmt( const char* fmt, int64_t inp );
auto        czm_CreateHotPatchByType( CZM_EHPT eHpTy ) -> CzmHotPatch2Base*;
void        czm_DeleteHotPatch( CzmHotPatch2Base* ptr );
auto        czm_DecodeHotKeySuite( std::string inp, const std::vector<int>& dflt2 ) -> std::vector<int>;
bool        czm_TestHotKeyOnKeyDownMessage( const std::vector<int>& aSuite, int nFirstKeyFromMsg );
bool        czm_DllDeInit();

struct CzmCrNewDevDTO{
	IDirect3DDevice9* pD3d9Device = nullptr;
};
struct CzmLogItem{
	CzmLogItem( std::string inp ) : srText2(inp) {}
	std::string srText2;
	uint64_t uAddedAt = 0;
};

struct CzmHotPatchMgr {
	CzmHotPatchMgr() = default;
	void addHotPatchDependency(  const std::vector<CZM_EHPT>& aHPTypeList, const char* szGuid );
	void removeHotPatchDependency(  const std::vector<CZM_EHPT>& aHPTypeList, const char* szGuid );
private:
	struct SHpDep {
		CZM_EHPT                 eHpTy2 = (CZM_EHPT)0;
		CzmHotPatch2Base*        pHPatch = nullptr;
		std::vector<std::string> aGuids;
		bool operator==( CZM_EHPT e )const;
	};
	std::vector<SHpDep> aHPatches;
};
struct CzmGoldAutoDTO {
	uint32_t uItemUid2 = 0xFFFFFFFF;
	uint32_t uItemType = 0xFFFFFFFF;
	uint32_t uAmount2 = 0;
	struct ByUid2{
		uint32_t uItemUid2;
		bool operator()( const CzmGoldAutoDTO& inp )const;
	};
};
struct CzmData
{
	CzmData();
	~CzmData();
	ImGuiContext* pImGuiCtx = nullptr;
	const char* szAppName = CZM_APP_NAME_2;  //"Critical Select Mod";
	std::string srVersionCalc;
	bool bStayDormant = 0L, bDbgFeaturesOn = 0L;
	std::vector<int> anUIKeySuite = { VK_F5,};
	//
	void*         fnOgPeekMessageA{};  //decltype(PeekMessageA);
	void*         fnOgPeekMessageW{};  //decltype(PeekMessageA);
	void*         fnOgGetRawInputData{};
	void*         hwMain = 0;
	void*         pD3d9Device2{};  //IDirect3DDevice9*
	void*         fnOgDirect3DCreate9{};  //decltype(Direct3DCreate9)*;
	// XInput gamepad.
	void*         hXInputDll{};
	void*         fnOgXInputGetState{};  //XInputGetState()
	void*         czm_OgXCrtExitProcess = nullptr;

	// gamepad menu navigation,
	bool bUIOpened = 0L;
	bool bLogAutoScroll = 1L;
	CzmPair<bool,int> bShowToolWindow = {0L,0L,};
	//
	bool bShowStartupTip = 1L, bAllocConsoleFlag = 0L;
	uint32_t uStartupTipOpenedAtMs = 0;
	uint32_t uStartupTipDurationMs = 10000;
	bool bKeyboardNavError = 0L, bGamepadNavError = 0L;
	float fInactiveOpacity = 0.3f;

	static const std::vector<std::pair<int,int> > aUIButtonMap;
	int16_t nXInputButtons2 = 0;
	static const int16_t nUIButtonMask;
	static const int16_t nUICloseButtons;
	static const uint32_t uUIButtonIntervalMs;
	uint32_t uUIButtonTimePos = 0;
	bool bUIButtonHeld = 0;
	bool bClosingUI = 0;
	//
	void addLog3( const char* fmt, const std::vector<HxdwPrintAdp> args4 );
	auto getLogText2( int index = -1 )const -> CzmPair<const char*,size_t>;
	void clearLogText2();
	void purgeOldLogItems();
	//
	std::vector<CzmLogItem> aLogText;
	CzmPair<size_t,int> aLogItemTrack = {0,0,};
	static const size_t nMaxLogItems;  //128
	static const uint64_t uTimeLogItemStaysMs;//5000
	//
	std::array<int,2> aCurrentRez = {0,0,};
	float fUIScale2 = 1.0f;
	//
	CzmWndGeomMgr* cLogWndGmtr = nullptr;// = CzmWndGeomMgr( {0.005f,0.6f,0.5f,0.33f,});
	CzmWndGeomMgr* cSettingsWndGmtr = nullptr;// = CzmWndGeomMgr( {0.1f,0.1f,0.8f,0.8f,});
	bool bGBossesTabOn = 0L, bFocusNeedleOn = 0L;
	bool bStatsEnabled = 0L;

	std::string srSelfDir, srSelfBaseName, srSelfFullPath, srSelfIniPath;
	std::string srSelfIniBFName, srSelfDbfPath;
	std::string srSettingsIniVFname = "settings_0siyn17r.ini";
	std::string srDllConfVFName = "config_dll_3xwfqkj.ini";
	hxdw_IniData2* ini2 = nullptr;
	CzmHotPatchMgr* cHpMgr = nullptr;

	CzmRE4GlobDt** ppGD = nullptr;
	CzmRE4Enemy** ppPlayerGD = nullptr;   // CzmRE4Enemy : cEm...; cPlayer *pPL;
	void* pCameraCtrl = nullptr; //RE4: CameraControl*
	void* fnCameraControlxxgetTrajectory = nullptr;  // CameraControl::getTrajectory()
	//
	std::vector<CzmRE4Enemy> aCurEnmList;
	CzmEnemyFactory* cEnmFctry = nullptr;
	FpDiskImage* pDbfs = nullptr;
	CzmSettings& se3;
	CzmPair<double,std::string> srUIFileMessage = {0.0,"",};
	uint32_t* pGlbPS = nullptr;  //aka. pS; referenced in SceAtCreateItemAt().
	uint32_t* pGlbPicups = nullptr;
	//std::vector<CzmGoldAutoDTO> aGoldAutoPickup;
};
extern CzmData* Czm;
