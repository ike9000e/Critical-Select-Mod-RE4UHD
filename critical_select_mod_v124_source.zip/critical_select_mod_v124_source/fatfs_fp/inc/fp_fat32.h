#pragma once
#include <vector>
#include <string>
#include <functional>
#include <algorithm>

struct FpVFile;
template<class Txx, class Tyy> struct FpPair;

int         FpCmpi( const char* sz2, const char* sz3, int len );
std::string FpTrimStr( const std::string& inp, const std::string& charset2, const char* flags2, int limit2 );
std::string FpStrReplace( std::string str, const std::string& from2, const std::string& to2, int nLimit, int* ouCount );
bool        FpStrExplode2( const char* inp, std::vector<std::string>& parts2, const std::vector<std::string> lsGlueItems, int nLimitSplitPoints, const char* szTrimLR, const char* flags3 );
void        FpStrExplode3( const char* inp, std::function<void(const char*, int len)> calbNewPart, const std::vector<std::string> lsGlueItems2, int nLimitSplitPoints, const char* szTrimLR );
std::string FpToLower( const char* sz2 );
const char* FpGetAnsiUppercaseCharacters();
auto        FpSplitPath( std::string inp2 ) -> FpPair<std::string,std::string>;

/**
	Access to FAT32|FAT16 disk images with simplified R/W access.
	Functionality is that on instance of this class opens
	single virtual FAT32|FAT16 disk image file.
	It is intended to work only with small disk image files and
	small virtual files, fe. up to 8MiB, approximately.
	Internally it operates on FILE* structure - usually
	provided by LIBC.
	Provides functions to do common FS operations such
	as reading|writing files, creating file, listing dir contents,
	deleting files, and deleting entire directories.
	Limitations:
	- image file size, that holds the virtual filesystem,
	  is limited to 4GiB.
	- virtual files, embeded inside the disk image, their size
	  is limited to 2GiB.

*/
struct FpDiskImage{
	FpDiskImage( const char* flags2 = "" );
	~FpDiskImage();
	virtual bool openDiskImage( const char* szLocalPathFileName, const char* flags2 );
	virtual bool closeDiskImage();
	virtual bool isDiskImageOpened()const;
	virtual bool mkfs2( const char* flags2 );
	virtual bool mkVFile( std::string pathname, uint64_t fsize, const char* flags2 );
	virtual bool enumVDirContents2( std::string pathname, const char* flags3, std::function<void(const FpVFile&)> calb2 )const;
	virtual bool enumVDirContents3( std::string pathname, const char* flags3, std::vector<FpVFile>* itemsOu )const;
	virtual bool unlinkVf( std::string pathname, const char* flags2 );
	virtual bool isVDir( std::string pathname )const;
	virtual bool isVFile( std::string pathname )const;
	virtual auto getVFileSize( std::string pathname )const -> uint32_t;
	virtual bool putVFileBytes2( std::string pathname, const void* data2, uint64_t uNumBytes, const char* flags2 );
	virtual bool getVFileBytes2( std::string pathname, std::vector<uint8_t>* data3, uint64_t nStartAddr, std::pair<bool,uint64_t> nMaxRead, const char* flags2 )const;
	virtual auto getVFileBytes3( std::string pathname, uint64_t nStartAddr, std::pair<bool,uint64_t> nMaxRead, const char* flags2 )const -> std::vector<uint8_t>;
private:
	bool isVFileOrDir( std::string pathname, bool bIfIsDir )const;
	bool safeClose();
	bool createDirsIfNeeded( std::string pathname );
	static bool isWithPathPart( std::string pathname );
	static auto fixAnyPathTokens( std::string pathname ) -> std::string;
	bool enumVDirContents9( std::string pathname, const char* flags3, std::function<void(const FpVFile&)> calb2, const std::string& srStartPath, int nDepth2 )const;
	static auto getRelPathGivenAbsAndStart( std::string srAbsPath, std::string srStartPath ) -> std::string;
private:
	struct FATFS;
	bool        mShowStdErs = 0L;
	std::string mImageFileName;
	FILE*       mFp2 = nullptr;
	FATFS*      mFatFs2 = nullptr;
	std::string mMountedName;   //eg. "0:/".
	uint64_t    mDiskSize = 0;
};

/// Used durning directory items enumeration with
/// FpDiskImage::enumVDirContents2() function.
struct FpVFile{
	std::string   srFName;
	std::string   srAbsPath;
	std::string   srRelPath;
	bool          bDir = 0L;
	uint64_t      uFileLen = 0;
	bool*         bBreak = nullptr;
	//
	int           nDepth = 0;
	std::string   srDotDir;    ///< if file, set to dirname(srAbsPath). if dir, set to srAbsPath.
};

template<class Txx, class Tyy>
struct FpPair {
	Txx first;
	Tyy second;
	Txx operator*()const {return first;}
	Tyy operator+()const {return second;}
};

