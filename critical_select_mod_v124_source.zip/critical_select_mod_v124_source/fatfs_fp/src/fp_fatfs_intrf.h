#pragma once
#include <vector>
#include <string>
#include <cstring>
#include <functional>
#include <algorithm>
#include <stdio.h>
#include <assert.h>
#include <inttypes.h>
struct FpDisk;
template<class Txx, class Tyy> struct FpPair;

enum : uint32_t{
	FP_CommonSectorSize = 512,
	FP_MaxFAT32FileSize = 4294967295, ///< FAT32 file limit is 4GiB-1, or exactly 4,294,967,295 bytes.
};
/*
int         FpCmpi( const char* sz2, const char* sz3, int len );
std::string FpTrimStr( const std::string& inp, const std::string& charset2, const char* flags2, int limit2 );
std::string FpStrReplace( std::string str, const std::string& from2, const std::string& to2, int nLimit, int* ouCount );
bool        FpStrExplode2( const char* inp, std::vector<std::string>& parts2, const std::vector<std::string> lsGlueItems, int nLimitSplitPoints, const char* szTrimLR, const char* flags3 );
void        FpStrExplode3( const char* inp, std::function<void(const char*, int len)> calbNewPart, const std::vector<std::string> lsGlueItems2, int nLimitSplitPoints, const char* szTrimLR );
std::string FpToLower( const char* sz2 );
const char* FpGetAnsiUppercaseCharacters();
//*/
//auto        FpSplitPath( std::string inp2 ) -> FpPair<std::string,std::string>;

bool        FpSetDisk( const char* szDisk );
std::string FpCnvFatFsErrorCodeToStr( int nErrorCode, int nResultMode );
std::string FpAddFsDisk( std::FILE* guid, uint64_t mDiskSize2 );
bool        FpRemoveFsDisk( std::FILE* guid );
bool        FpSeek32( FILE* hfp, uint64_t position2 );
uint64_t    FpGetFileSize32( FILE* hf4 );

template<class Txx>
Txx FpMax( Txx a, Txx b )
{
	return a > b ? a : b;
}
template<class Txx>
Txx FpMin( Txx a, Txx b )
{
	return a < b ? a : b;
}

struct FpDisk {
	uint64_t    uFileSize = 0;
	std::FILE*  fph2 = nullptr;
	int         nFsIdent = 0;
	uint32_t    uSectorSize = 0;
};
/*template<class Txx, class Tyy>
struct FpPair {
	Txx first;
	Tyy second;
	Txx operator*()const {return first;}
	Tyy operator+()const {return second;}
};//*/
struct FpData {
	int         nCurrentDisk = 0;
	int         nNextDiskId = 0;
	std::vector<FpDisk> FpOpenedDisks;
};
extern FpData* Fpd;





