#pragma once
#include <string>
#include <vector>
#include <array>
#include <inttypes.h>
#include "czm_interfaces.h"
#include "czm_description.h"
#include "czm_reiv_tools.h"

struct IDirect3DDevice9; struct ImGuiContext; struct HxdwPrintAdp;
struct CzmRE4EnemyData;
struct hxdw_IniData2;

uint32_t    czm_Win32DetoursInit();
uint32_t    czm_Win32DetoursDeinit();
bool        czm_Print2( const char* fmt, const std::vector<HxdwPrintAdp> args4 );
bool        czm_AnySystemModkeyDown();
void        czm_SetupUIElements();
void        czm_ProcessUIKey( uint16_t nXInputButtons );
void        czm_CreateWeaponTypeUIItems();
void        czm_UpdateFromConfigFile();
std::string czm_CalcProgramVersion();
std::string czm_ToStrFmt( const char* fmt, int64_t inp );
auto        czm_CreateHotPatchByType( CZM_EHPT eHpTy ) -> CzmHotPatch2Base*;
void        czm_DeleteHotPatch( CzmHotPatch2Base* ptr );

struct CzmCrNewDevDTO{
	IDirect3DDevice9* pD3d9Device = nullptr;
};
struct CzmLogItem{
	CzmLogItem( std::string inp ) : srText2(inp) {}
	std::string srText2;
};

struct CzmWndGeomMgr {
	CzmWndGeomMgr() = default;
	CzmWndGeomMgr( std::array<float,4> aDflt );
	void        updateOnWindowBegin();
	void        updateOnWindowEnd();
	static auto getWindowGeometry() -> std::array<int,4>;
	static auto getWindowFGeometry() -> std::array<float,4>;
	std::string serialize2()const;
	void        deserialize2( const char* inp );
	void        onRezChange( std::array<int,2> aOldRez, std::array<int,2> aNewRez );
private:
	std::array<int,4>   aNXywh = { 128, 92, 400, 300,};
	std::array<float,4> aFXywh = { 0.1f, 0.1f, 0.8f, 0.8f,};
	bool bNeedGmtryUpdate = 0L;
};

struct CzmHotPatchMgr {
	CzmHotPatchMgr() = default;
	void addHotPatchDependency(  const std::vector<CZM_EHPT>& aHPTypeList, const char* szGuid );
	void removeHotPatchDependency(  const std::vector<CZM_EHPT>& aHPTypeList, const char* szGuid );
private:
	struct SHpDep {
		CZM_EHPT                 eHpTy2 = (CZM_EHPT)0;
		CzmHotPatch2Base*        pHPatch = nullptr;
		std::vector<std::string> aGuids;
		bool operator==( CZM_EHPT e )const;
	};
	std::vector<SHpDep> aHPatches;
};

struct CzmData
{
	CzmData();
	ImGuiContext* pImGuiCtx{};
	const char* szAppName = CZM_APP_NAME_2;  //"Critical Select Mod";
	std::string srVersionCalc;
	bool bStayDormant = 0L, bDbgFeaturesOn = 0L;
	//
	void*         fnOgPeekMessageA{};  //decltype(PeekMessageA);
	void*         fnOgPeekMessageW{};  //decltype(PeekMessageA);
	void*         fnOgGetRawInputData{};
	void*         hwMain = 0;
	void*         pD3d9Device2{};  //IDirect3DDevice9*
	void*         fnOgDirect3DCreate9{};  //decltype(Direct3DCreate9)*;
	// XInput gamepad.
	void*         hXInputDll{};
	void*         fnOgXInputGetState{};  //XInputGetState()
	// gamepad menu navigation,
	bool bUIOpened = 0L;
	bool bShowLogWindow = 0L;
	bool bLogAutoScroll = 1L;
	//
	bool bShowStartupTip = 1L, bAllocConsoleFlag = 0L;
	uint32_t uStartupTipOpenedAtMs = 0;
	uint32_t uStartupTipDurationMs = 10000;
	bool bKeyboardNavError = 0L, bGamepadNavError = 0L;

	static const std::vector<std::pair<int,int> > aUIButtonMap;
	int16_t nXInputButtons2 = 0;
	static const int16_t nUIButtonMask;
	static const int16_t nUICloseButtons;
	static const uint32_t uUIButtonIntervalMs;
	uint32_t uUIButtonTimePos = 0;
	bool bUIButtonHeld = 0;
	bool bClosingUI = 0;
	//
	void addLog3( const char* fmt, const std::vector<HxdwPrintAdp> args4 );
	auto getLogText2( int index = -1 )const -> CzmPair<const char*,size_t>;
	void clearLogText2();
	//
	std::vector<CzmLogItem> aLogText;
	CzmPair<size_t,int> aLogItemTrack = {0,0,};
	static const size_t nMaxLogItems;  //128
	//
	std::array<int,2> aCurrentRez = {0,0,};
	float fUIScale2 = 1.0f;
	//
	CzmWndGeomMgr cLogWndGmtr = CzmWndGeomMgr( {0.005f,0.6f,0.5f,0.33f,});
	CzmWndGeomMgr cSettingsWndGmtr = CzmWndGeomMgr( {0.1f,0.1f,0.8f,0.8f,});
	bool bGBossesTabOn = 0L, bFocusNeedleOn = 0L;
	bool bStatsEnabled = 0L;

	std::vector<int> aWpnCheckFlags;

	std::string srSelfDir, srSelfBaseName, srSelfFullPath, srSelfIniPath;
	hxdw_IniData2* ini2 = nullptr;
	//
	CzmHotPatchMgr* cHpMgr = new CzmHotPatchMgr;
	CzmRE4GlobDt** ppGD = nullptr;
	CzmRE4Enemy** ppPlayerGD = nullptr;   // CzmRE4Enemy : cEm...; cPlayer *pPL;
	std::vector<CzmRE4Enemy> aCurEnmList;
	CzmRE4EnemyFactory* cEnmFctry = new CzmRE4EnemyFactory;
};
extern CzmData* Czm;
