#pragma once
#include <inttypes.h>   //uint32_t
#include <vector>
#include <functional>
#include <algorithm>
#include "czm_interfaces.h"

uint32_t czm_GpHaxInit();
uint32_t czm_GpHaxDeinit();
void     czm_EachHotPred2( std::function< void(const CzmEachHPatchDTO&)> calb2 );
auto     czm_CreateHotPatchByType( CZM_EHPT eHpTy ) -> CzmHotPatch2Base*;
void     czm_DeleteHotPatch( CzmHotPatch2Base* ptr );
int      czm_RemoveMHDetoursByList2( std::vector<void*>* inp );

#pragma pack(push)  //[m9XodnW:a] //{
#pragma pack(1)

/*
/// Unknown room data on room load.
/// Can be found in the pointer that itself is located at
/// the offset 0x13F3C in the ".data" segment in the "Bio4.exe".
struct CzmRE4UnkRoomData{

	union{
		struct{
			uint8_t skip0[0x4FAC];
			uint8_t aValue[2];
		}sRoomId;
		//struct{
		//	uint8_t skip0[0x5410];
		//	uint8_t pByte0[1];
		//}sESLData;
	};
	uint16_t pokeRoomIdValue( bool bSet=0, uint16_t uNewRoomId=0 );
};//*/

#pragma pack(pop)  //[m9XodnW:b] //}

using CzmVoidStdcallVoid_t = void(__stdcall*)();
void*                czm_OgOnDamageEnemy = nullptr;
CzmVoidStdcallVoid_t czm_OgOnEnemyDies = nullptr;
CzmVoidStdcallVoid_t czm_OgOnEnemyDiesDrowning = nullptr;
void*                czm_OgOnRoomLoad = nullptr;
CzmVoidStdcallVoid_t czm_OgOnReturnToMainMenu = nullptr;
//void*              czm_OgOnCritDamageValue = nullptr;
void*                czm_OgOnDamageOnNormalEnemy = nullptr;
void*                czm_OgOnFloatToIntFeCrit = nullptr;
void*                czm_OgKeyTrgCheckZero = nullptr; //"KeyTrgCheck_0"
void*                czm_OgScenarioChkEvCancel = nullptr;
void*                czm_OgEventxxRun = nullptr;
void*                czm_OgEnemyDeath = nullptr;
void*                czm_OgDamageEnemyOrPlayer = nullptr;
void*                czm_OgSpwParasiteChgChk = nullptr;
void*                czm_OgCheckParasiteCnt = nullptr;
void*                czm_OgEnemyMgrxxmove = nullptr;
void*                czm_OgTaskScheduler = nullptr;
void*                czm_GameEmSetFromList2 = nullptr;



//czm_DamageEnemyOrPlayer,CzmHotPatch2Base,notifyDamageAnyEnemy2
struct CzmHPDmgEnemyOrPlayer : CzmHotPatch2Base {
	virtual int install2() override;
	virtual int uninstall2() override;
private:
	static int __cdecl czm_DamageEnemyOrPlayer( CzmRE4Enemy* pEnm2, int arg2, int arg3, char arg4 );
private:
	bool mIsInstalled = 0L;
	void* pAtOpCode2 = nullptr;
};

struct CzmHPFloatToIntFeCrit : CzmHotPatch2Base {
	virtual int install2() override;
	virtual int uninstall2() override;
private:
	static uint32_t __cdecl czm_OnFloatToIntFeCritESPAware();
	static void __stdcall czm_OnFloatToIntOnCritical( CZM_EWT uWeaponType, uint32_t* ptrDmgVal );
	//notifyDamageNormalEnemy
private:
	static uint8_t* pAtCritFloatToIntRetAddr;
	void* pAtOpCode4 = nullptr;
};
struct CzmHPCutsceneSkips : CzmHotPatch2Base {
	virtual int install2() override;
	virtual int uninstall2() override;
private:
	static uint8_t __cdecl czm_KeyTrgCheckZeroESPAware( uint32_t arg0, uint32_t arg1 );
	static bool __fastcall czm_KeyTrgCheckZeroOutline( uint8_t* pEipRetAddr );
	static int8_t __cdecl czm_ScenarioChkEvCancel();
	static uint32_t __cdecl czm_EventxxRun();
	static void __fastcall czm_EventxxRunOutline( uint8_t* thisptr2 );
private:
	std::vector<void*> aOpAddrs;
	static uint8_t* pAtCutscASkipEipAddr;
	static uint8_t* pAtCutscCSkipEipAddr;
	static uint8_t* pAtCutscBAlphaTrgrPtr;
	static uint32_t* pAtCutscBBetaTrgrPtr;
};

struct CzmHPHeadPlagasCtrl : CzmHotPatch2Base {
	virtual int install2() override;
	virtual int uninstall2() override;
private:
	static uint32_t __cdecl czm_SpwParasiteChgChk();
	static uint32_t __cdecl czm_CheckParasiteCnt( void* pCtrl12, int32_t arg2, uint32_t arg3 );
private:
	std::vector<void*> aOpAddrs2;
};

struct CzmHPEnemyMgrMove : CzmHotPatch2Base {
	virtual int install2() override;
	virtual int uninstall2() override;
private:
	static void __cdecl czm_EnemyMgrxxmove();
private:
	std::vector<void*> aOpAddrs3;
};

struct CzmHPAshleyChecks : CzmHotPatch2Base {
	virtual int install2() override;
	virtual int uninstall2() override;
private:
	static uint8_t __cdecl czm_CheckAshleyActive();
private:
	std::vector<void*> aOpAddrs4;
	static void* mOgCheckAshleyActive;// = 0;
};

struct CzmHPMerchandiseAnim : CzmHotPatch2Base {
	virtual int install2() override;
	virtual int uninstall2() override;
private:
	static void* __cdecl czm_em18TradeAction( CzmRE4Enemy* pEnmy );
	static char __cdecl czm_em10TradeAction( CzmRE4Enemy* pEnmy );
private:
	std::vector<void*> aOpAddrs5;
	static void* mOgEm18TradeAction, *mOgEm10TradeAction;
};

struct CzmDelLagoInstaKO : CzmHotPredicateBase {
	virtual int notifyDamageAnyEnemy2( const CzmDmg2DTO& inp ) override;
	virtual void setDelLagoInstaKO( bool bSet ) override;
private:
	bool mEnableInstaKO = 0L;
};
struct CzmCritManip : CzmHotPredicateBase {
	virtual int  notifyDamageNormalEnemy( const CzmDmg3DTO& inp ) override;
	virtual void setAlterableDamageTypes( const std::vector<CZM_EWT>& inp ) override;
	virtual void setCriticalDamageScale( float fCritDmgScale_ ) override;
private:
	std::vector<CZM_EWT> aAlterableDmgTy;
	float mCritDmgScale = 1.0f;
};
// Cutscene skip hot patch.
struct CzmCutscSkip : CzmHotPredicateBase {
	virtual int notifyCutscenePlay( const CzmCutscSkipDTO& inp ) override;
	virtual int notifyUnskippableCutscenePlay( const CzmCutscSkipDTO& inp ) override;
	virtual void setCutsceneSkipEnabled( bool bSet ) override;
	virtual void setCutsceneDeltaSkipable( bool bSet ) override;
private:
	bool mSkipEnable = 0L, mDtSkipEnable = 0L;
};

struct CzmHeadParasiteDiceManip : CzmHotPredicateBase {
	virtual int notifyDiceForParasiteSpawn( const CzmPrsDiceDTO& inp )override;
	virtual void setParasiteSpawnManipEnabled( bool bEnable )override;
	virtual void setParasiteSpawnChance( float fChancePerc )override;
	virtual void setNoParasiteInIntialChapters( bool bDisable )override;
private:
	bool mEnabled = 0L, mNotInInitialChp = 0L;
	float mPrsChance = 1.f;
};
struct CzmHeadParasiteLiveLimitRemove : CzmHotPredicateBase {
	virtual void setParasiteSpawnNoLimit( bool bEnable )override;
	virtual int notifyCheckAllowNewLiveParasite( const CzmPrsSpwChkDTO& inp )override;
private:
	// limit in-game seems to be 2.
	bool mEnabled = 0L;
};
struct CzmDisableTypeCParasite : CzmHotPredicateBase {
	virtual int notifyEnemyMgrEnmsMove( const CzmEnmMgrMvDTO& inp )override;
	virtual void setDisableTypeCParasite( bool bDisable )override;
private:
	bool mEnabled = 0L;
};
struct CzmStatsListLiveEnmy : CzmHotPredicateBase {
	virtual int notifyEnemyMgrEnmsMove( const CzmEnmMgrMvDTO& inp )override;
	virtual void setEnemyStatsEnabled( bool bSet )override;
private:
	bool mEnabled = 0L;
};
struct CzmMerchandiseAnimSkip : CzmHotPredicateBase {
	virtual void setMerchantWelcomeAnimSkip( bool bSet )override;
	virtual int notifyMerchantTradeAction( const CzmMerchieDTO& inp )override;
private:
	bool mEnabled = 0L;
};

struct CzmCanLeaveAshleyBehind : CzmHotPredicateBase { //CzmHPAshleyChecks
	virtual void setCanLeaveAshleyBehind( bool bSet )override;
	virtual int notifyCheckAshleyActive( const CzmPredMiscDTO& inp )override;
private:
	bool mEnabled = 0L;
};
/// Gameplay data.
struct CzmGpData
{
	bool bMdxInitedOneTime = 0;
	bool bMdxDeinited = 0;
	int cnt2 = 0;
	//CzmRE4GlobDt** ppGD = nullptr;
	bool bCritRegistered = 0;
	CzmHotPatchDTO* aHotPreds2 = nullptr;
};
extern CzmGpData* Gpd;
