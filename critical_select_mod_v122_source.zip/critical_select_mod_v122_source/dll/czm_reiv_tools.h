#pragma once
#include <string>
#include <vector>
#include "czm_interfaces.h"

CzmRE4Vec   czm_ConvRE4SvecToPos( const CzmRE4Svec& vec16 );
CzmRE4Svec  czm_ConvPosToRE4Svec( const CzmRE4Vec& vec );
CzmRE4Vec   czm_ConvRE4SvecToRotation( const CzmRE4Svec& vec16 );
uint32_t    czm_CallMemberFuncViaEcx( void* thisptr2, void* fnc2, uint32_t* pArgs, uint32_t nNumArgs );
std::string czm_GetWeaponTypeName2( CZM_EWT, bool bGetAsEnum );
auto        czm_GetWeaponTypeByIndex( size_t index2 ) -> CzmPair<bool,CZM_EWT>;
size_t      czm_GetWeaponTypeCount();
auto        czm_GetWeaponGroupTypeWeapons( CZM_EWGR eWpnGrTy ) -> std::vector<CZM_EWT>;
auto        czm_ConvWeaponTypeIndexesToTypes( const std::vector<int>& inp ) -> std::vector<CZM_EWT>;

struct CzmRE4EnemyFactory{
	CzmRE4EnemyFactory();
	CzmRE4EnemyFactory( const CzmRE4EnemyFactory& otherr ) = delete;
	void operator=( const CzmRE4EnemyFactory& otherr ) = delete;
	bool createLiveEnemy2( const CzmRE4EmList& inp, CzmRE4Enemy* pPlayer );
private:
	CzmRE4Enemy* callCmanagerCreate( void* fnRE4CManagerCreate2, void** ppEmMgr2, uint32_t uTypeId );
private:
	void* fnRE4CManagerCreate = nullptr;
	void** ppEmMgr = nullptr;
};
