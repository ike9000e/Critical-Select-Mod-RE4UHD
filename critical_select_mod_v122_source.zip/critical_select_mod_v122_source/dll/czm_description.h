#pragma once
#define CZM_APP_NAME_2 "Critical Select Mod"
#define CZM_APP_NAME_3 "Critical Select Mod for RE4UHD"
#define CZM_APP_URL "https://www.nexusmods.com/residentevil4/mods/181\0"
