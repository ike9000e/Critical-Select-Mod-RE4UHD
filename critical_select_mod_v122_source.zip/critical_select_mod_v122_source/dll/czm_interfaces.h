#pragma once
#include <algorithm>
#include <vector>
#include <array>
#include <inttypes.h>
#include <type_traits>  //std::is_same

struct CzmRE4EnemyData;
enum class CZM_EWT : uint8_t;
struct CzmRE4Enemy;
struct CzmRe4EnmyMgr;

// Room Load Type.
enum class CZM_ERLT : int {
	CZM_E2_ToMainMenu = 1,
	CZM_E2_NewRoom,
};
struct CzmRoomLoadDTO{
	CZM_ERLT eRoomLoadType = CZM_ERLT::CZM_E2_NewRoom;
	uint16_t uRoomId = 0;
};
struct CzmTestRun{
	int bTestRun4 = 0;
};
struct CzmDmg2DTO : CzmTestRun {
	CzmRE4Enemy* pEnmyDtaPtr5 = nullptr;
};
/// Critical damage type.
enum class CZM_ECDT : int {
	CZM_E4_None = 1,
	CZM_E4_Critical,
};
struct CzmDmg3DTO : CzmTestRun {
	CZM_EWT   uWeaponType = (CZM_EWT)0x00;
	uint32_t* pDamgeValue = nullptr;
	CZM_ECDT  eCritDmgType = CZM_ECDT::CZM_E4_None;
};
/// Cutscene type.
enum class CZM_CST: int {
	CZM_E6_TypeAlpha = 0x1,       // eg. r100 in-house cutscene.
	CZM_E6_TypeBeta = 0x2,       // eg. r100 house approach cutscene.
	CZM_E6_TypeGamma = 0x4,       // codex conversations.
	CZM_E6_TypeDelta = 0x8,       // eg. krauser multi-part-cutscene knife fight.
};
// Cutscene skip DTO.
struct CzmCutscSkipDTO : CzmTestRun{
	CZM_CST eCtsType = (CZM_CST)0;
	bool* bSkipCutscene = nullptr;
	CzmCutscSkipDTO() = default;
	CzmCutscSkipDTO( CZM_CST eCtsType_, bool* bSkipCutscene_ );
};
struct CzmEnmMgrMvDTO {
	CzmRe4EnmyMgr* pEnMgr2 = nullptr;
	CzmRE4Enemy* getNextEnemy2( size_t nIndex2 )const;
};
using CZM_EHPT = size_t;

struct CzmHotPatch2Base {
	virtual int install2() = 0;
	virtual int uninstall2() = 0;
};

struct CzmPrsDiceDTO{
	bool* bPrsOverride2 = nullptr;
	bool* bPrsSpawnNow2 = nullptr;
};
struct CzmPrsSpwChkDTO{
	//bool* bCtrlNewParasite2 = nullptr;
	bool* bAllowNewParasite2 = nullptr;
};

struct CzmPredMiscDTO{
	mutable bool bEnableAOverride = 0L;
	mutable int bNewAValue = 0L;
};

struct CzmMerchieDTO{
	CzmRE4Enemy* enmy2 = nullptr;
	//bool bIs2ndCall = 0L;
	bool bIsEm18Call = 0L, bIsEm10Call = 0L;
};

struct CzmHotPredicateBase {
	virtual int  notifyEnemyDeath( CzmRE4EnemyData* inp ) {return -1;}
	virtual int  notifyRoomLoad( const CzmRoomLoadDTO& inp ) {return -1;}
	virtual int  notifyDamageAnyEnemy2( const CzmDmg2DTO& inp ) {return -1;}
	virtual int  notifyDamageNormalEnemy( const CzmDmg3DTO& inp ) {return -1;}
	virtual int  notifyCutscenePlay( const CzmCutscSkipDTO& inp ) {return -1;}
	virtual int  notifyUnskippableCutscenePlay( const CzmCutscSkipDTO& inp ) {return -1;}
	virtual int  notifyEnemyMgrEnmsMove( const CzmEnmMgrMvDTO& inp ) {return -1;}
	virtual void setAlterableDamageTypes( const std::vector<CZM_EWT>& inp ) {}
	virtual void setCriticalDamageScale( float fCritDmgScale ) {}
	virtual void setDelLagoInstaKO( bool bSet ) {}
	virtual void setCutsceneSkipEnabled( bool bSet ) {}
	virtual void setCutsceneDeltaSkipable( bool bSet ) {}
	virtual int notifyDiceForParasiteSpawn( const CzmPrsDiceDTO& inp ) {return -1;}
	virtual void setParasiteSpawnManipEnabled( bool bEnable ) {}
	virtual void setParasiteSpawnChance( float fChancePerc ) {}
	virtual void setParasiteSpawnNoLimit( bool bEnable ) {}
	virtual int notifyCheckAllowNewLiveParasite( const CzmPrsSpwChkDTO& inp ) {return -1;}
	virtual void setDisableTypeCParasite( bool bDisable ) {}
	virtual void setNoParasiteInIntialChapters( bool bDisable ) {}
	virtual void setEnemyStatsEnabled( bool bSet ) {}
	virtual int notifyCheckAshleyActive( const CzmPredMiscDTO& inp ) {return -1;}
	virtual void setCanLeaveAshleyBehind( bool bSet ) {}
	virtual int notifyMerchantTradeAction( const CzmMerchieDTO& inp ) {return -1;}
	virtual void setMerchantWelcomeAnimSkip( bool bSet ) {}
};

template<class Txx, class Uxx>
struct CzmPair{
	static_assert( !std::is_same<Txx,Uxx>::value, "Types must be different." );
	Txx first;
	Uxx second;
	CzmPair( const Txx& first_, const Uxx& second_ ) : first(first_), second(second_) {}
	CzmPair() = default;
	Txx operator*()const {return first;}
	Uxx operator+()const {return second;}
};

/// Gets array size.
template<class Txx> //constexpr
size_t CzmArrSize( const Txx& inp )
{
	size_t size_ = sizeof(inp) / sizeof(inp[0]);
	return size_;
}

struct CzmEachHPatchDTO {
	CzmHotPredicateBase* hp3 = nullptr;
};
template<class Oxx, class Txx>
Oxx CzmClamp( Txx inp, Txx minval, Txx maxval )
{
	Oxx outp = static_cast<Oxx>(
		std::max<Txx>(
			std::min<Txx>( inp, maxval ), minval ) );
	return outp;
}

struct CzmHotPatchDTO {
	CzmHotPredicateBase* pHotPatch = nullptr;
};

struct CzmEnemyTypeAdp {
	uint8_t uEnmType;    // CzmRE4Enemy::id_100
	uint8_t uEnmSubType;   // CzmRE4Enemy::type_101
	//
	CzmEnemyTypeAdp() = delete;
	CzmEnemyTypeAdp( const CzmRE4Enemy* inp );
	CzmEnemyTypeAdp( const std::array<uint8_t,2>& aEnmTySubTy );
	virtual bool isNormalHumanoidEnemyType()const;
	virtual bool isSpecialHumanoidEnemyType()const;
	virtual bool isLethalEnemyType()const;
};

#pragma pack(push)  //[mhyBqJJN:a] //{
#pragma pack(1)

//EMINFO_WK
struct CzmRE4EmInfoWK {
	uint8_t WorkType_0;
	uint8_t Work0_1;
	uint8_t Work1_2;
	uint8_t Work2_3;
	float Pos_4[3];   //Vec Pos_4; x, y and z.
	float Dir_mb_10;
	float Dir_mb_14;
	uint8_t Dummy_18[40];   //uint8_t[40] Dummy_18;
};
// EMINFO_DATA
struct CzmEmInfoData {
	uint32_t Num_0;
	uint32_t Id_4;
	CzmRE4EmInfoWK Data_8[256];  //EMINFO_WK[]
};
// This is a 16-bit vector that is used in ESL files for enemy
// position and orientation|rotation|angle.
// SVEC
struct CzmRE4Svec {
	int16_t x;
	int16_t y;
	int16_t z;
};
//Vec
struct CzmRE4Vec {
	float x;
	float y;
	float z;
};

//EM_LIST
struct CzmRE4EmList {
	uint8_t be_flag_0;  //EM_BE_FLAG
	int8_t id_1;
	int8_t type_2;
	int8_t set_3;
	uint32_t flag_4;
	int16_t hp_8;
	uint8_t emset_no_A;
	int8_t Character_B;
	CzmRE4Svec s_pos_C;    //SVEC
	CzmRE4Svec s_ang_12;   //SVEC
	uint16_t room_18;
	int16_t Guard_r_1A;
	uint8_t Dummy_1C[4];
	//
	CzmRE4EmList& setSampleEnemy2();
};
/// Global game data.
/// Can be found in the pointer that itself is located at
/// the offset 0x13F3C in the ".data" segment in the "Bio4.exe".
/// GLOBAL_WK.
struct CzmRE4GlobDt {
	union{
		struct{
			uint8_t skip0[0x2];
			int8_t v;
		}CardLastSelNo_2;
		//struct{
		//	uint8_t skip0[0x28];
		//	uint16_t v;
		//}RoomNo_next;
		struct{
			uint8_t skip0[0x5C];
			uint32_t v;
		}curGameTime_5C;
		struct{
			uint8_t skip0[0x4FA4];
			int32_t v;  //int
		}playTime_4FA4;
		struct{
			uint8_t skip0[0x4F30];
			CzmEmInfoData* v;  //int
		}pEmi_4F30;
		struct{
			uint8_t skip0[0x4F9A];
			uint8_t v;  //int
			/// game chapter value. 0: 1-1, 2: 1-3: 3: 2-1, etc.
		}chapter_4F9A;
		//uint16_t save_cnt_4F9C;
		//uint16_t game_cnt_4F9E;
		struct{
			uint8_t skip0[0x4FA0];
			uint16_t v;  //int
		}r_continue_cnt_4FA0;
		struct{
			uint8_t skip0[0x4FA8];
			int32_t v;  //int
		}goldAmount_4FA8;
		struct{
			uint8_t skip0[0x4FAC];
			uint16_t v;
		}curRoomId_4FAC;  //room-id, eg. r100
		struct{
			uint8_t skip0[0x4FC9];
			uint8_t v;
		}plCostume_4FC9;
		struct{
			uint8_t skip0[0x4FCB];
			uint8_t v;
		}subCostume_4FCB;
		struct{
			uint8_t skip0[0x8464];
			uint32_t v;
		}c_kill_cnt_8464;
		struct{
			uint8_t skip0[0x8468];
			uint32_t v;
		}g_kill_cnt_8468;
		struct{
			uint8_t skip0[0x4F94];
			uint32_t v;
		}dynamicDifficultyPoints_4F94;
		struct{
			uint8_t skip0[0x4F98];
			uint8_t v;
		}dynamicDifficultyLevel_4F98;
		struct{
			uint8_t skip0[0x846C];
			uint32_t v;
		}c_hit_cnt_846C;
		struct{
			uint8_t skip0[0x8470];
			uint32_t v;
		}g_hit_cnt_8470;
		struct{
			uint8_t skip0[0x8474];
			uint32_t v;
		}c_shot_cnt_8474;
		struct{
			uint8_t skip0[0x8478];
			uint32_t v;
		}g_shot_cnt_8478;
		struct{
			uint8_t      skip0[0x5410];
			CzmRE4EmList v[256];   //EM_LIST[256]
		}Em_list_5410;
		//ITEM_SAVE_WORK[256] item_save_7410;
		struct{
			uint8_t skip0[0x4FB3];
			int8_t  v;
		}curEmListNumber_4FB3;
	};
	CzmRE4GlobDt() = delete;
	uint16_t pokeRoomIdValue( bool bSet=0, uint16_t uNewRoomId=0 );
};

// CzmRE4EnemyData
// struct cEm : cModel
// struct cEm18 - inherits: cEm, cModel, cCoord, cUnit
struct CzmRE4Enemy {
	union{
		struct{
			void** v;
		}vftable_0;   // vtable at offset 0. (cUnit::__vftable : cUnit_vtbl*)
		struct{
			uint8_t   skip0[0x94];
			CzmRE4Vec v;
		}position_94; // cCoord::position_94 : Vec
		struct{
			uint8_t   skip0[0xA0];
			CzmRE4Vec v;
		}rotation_A0; // cCoord::rotation_A0 : Vec
		struct{
			uint8_t skip0[0x324];
			int16_t v;
		}hp_324;
		struct{
			uint8_t skip0[0x326];
			int16_t v;
		}hp_max_326;
		struct{
			uint8_t skip0[0xF8];
			uint32_t v;
		}guid_F8;
		struct{
			uint8_t skip0[0x328];
			uint32_t v;
		}m_DmgInfo_328;  // sizeof: h 344-328=1C
		struct{
			uint8_t skip0[0x328+0x6];
			uint8_t v;
		}m_DmgInfo_328_Wep_6;
		struct{
			uint8_t skip0[0x100];
			uint8_t v;
		}id_100;   //uEnemyType2
		struct{
			uint8_t skip0[0x101];
			uint8_t v;
		}type_101;   //uEnemySubType2
		struct{
			uint8_t skip0[0x3D0];
			uint32_t v;
		}flag_3D0;
		struct{
			uint8_t skip0[0x8];
			CzmRE4Enemy* v;
		}nextUnit_8;
		struct{
			uint8_t skip0[0x4];
			uint32_t v;
		}be_flag_4; //cUnit::be_flag_4 : UNIT_BE_FLAG

		struct{
			uint8_t skip0[0x3CC];
			uint32_t v;
		}m_StatusFlag_3CC;
		struct{
			uint8_t skip0[0x3DE];
			uint16_t v;
		}Item_id_3DE;
		struct{
			uint8_t skip0[0x3E0];
			uint16_t v;
		}Item_num_3E0;
		struct{
			uint8_t skip0[0x3E2];
			uint16_t v;
		}Item_flg_3E2;
		struct{
			uint8_t skip0[0x3E4];
			uint16_t v;
		}Auto_item_flg_3E4;
		struct{
			uint8_t skip0[0x3E8];
			uint32_t v;
		}flags_3E8;
		struct{
			uint8_t skip0[0x7EE];
			uint8_t v;
		}em10unk_field_7EE;
		struct{
			uint8_t skip0[0x395];
			uint8_t v;   // CzmRE4EmList::set_3
		}set_395;
		struct{
			uint8_t skip0[0x3D8];
			uint8_t v;
		}characterNum_3D8;
		struct{
			uint8_t skip0[0x3D4];
			float v;
		}Guard_r_3D4;
		struct{
			uint8_t skip0[0x3A0];
			uint8_t v;
		}emListIndex_3A0;
		struct{
			uint8_t   skip0[0x110];
			CzmRE4Vec v;
		}pos_old_110;
		struct{
			uint8_t skip0[0x37C];
			float   v;
		}l_sub_37C;
		struct{
			uint8_t skip0[0x378];
			float   v;
		}l_pl_378;
	};
	CzmRE4Enemy();
	bool testEnemyType2( const std::array<uint8_t,2>& ty_and_sub_ty )const;
};
// cManager_cEm_
// struct cEmMgr : cManager_cEm_ { }
struct CzmRe4EnmyMgr {
	union{
		struct{
			uint8_t skip0[0x4];
			CzmRE4Enemy* v;   //cEm*
		}m_Array_4;
		struct{
			uint8_t skip0[0x8];
			uint32_t v;   //cEm*
		}m_nArray_8;
		struct{
			uint8_t skip0[0xC];
			uint32_t v;
		}m_blockSize_C;
		struct{
			uint8_t skip0[0x14];
			CzmRE4Enemy* v;   //cEm*
		}m_pAlive_14;
	};
};
#pragma pack(pop)  //[mhyBqJJN:b] //}

/// Enemy id types, aka. the base type.
/// used by the CzmRE4Enemy::id_100 member.
/// REF:
/// https://github.com/emoose/re4-research/issues/3#issuecomment-1047158003
namespace CZM_EEIT {
	enum : uint8_t {
		CZM_E7_Ganado =0x10,
		CZM_E7_Ganado_Villager_12 =0x12,
		CZM_E7_Ganado_Villager_15 =0x15,
		CZM_E7_Ganado_Villager_and_Bella_Sisters =0x16,
		CZM_E7_Ganado_Villager_17 =0x17,
		CZM_E7_Merchant =0x18,
		CZM_E7_Ganado_Soldier =0x20,
		CZM_E7_Colmillos =0x22,   //Plaga-infested wolves
		CZM_E7_Crow =0x23,
		CZM_E7_Snake =0x24,
		CZM_E7_Plagas_C_r20F =0x25,
		CZM_E7_Cow =0x26,
		CZM_E7_Piranha =0x27,
		CZM_E7_Chicken =0x28,
		CZM_E7_Bat =0x29,
		CZM_E7_Unnamed_0x2A =0x2A,
		CZM_E7_El_Gigante =0x2B,
		CZM_E7_Verdugo =0x2C,
		CZM_E7_Novistador =0x2D,   //"wasp"
		CZM_E7_Child =0x2E,
		CZM_E7_DelLago =0x2F,  //Del Lago, DelLago
		CZM_E7_No_0_Sadler =0x30,
		CZM_E7_No_0_Sadler_after_transformation =0x31,
		CZM_E7_U3 =0x32,
		CZM_E7_MendezAForm =0x34, //Mendez
		CZM_E7_MendezBForm =0x35, //Mendez
		CZM_E7_Regenerator_and_Iron_Maiden =0x36,
		CZM_E7_Salazar =0x38,
		CZM_E7_Krauser =0x39,
		CZM_E7_Robot_0x3A =0x3A,
		CZM_E7_TruckOrWagon =0x3B,
		CZM_E7_KnightType = 0x3C,
		CZM_E7_MikesHelicopter =0x3D,
		CZM_E7_Unnamed_3E =0x3E,
		CZM_E7_Unnamed_4B =0x4B,
		CZM_E7_ShipCannon =0x4E,
		CZM_E7_Soldier = 0x1D,
		CZM_E7_Soldier2 = 0x1E,
		CZM_E7_HeavySoldier = 0x1F,
		CZM_E7_Zealot = 0x11,
		CZM_E7_Zealot2 = 0x14,
		CZM_E7_Zealot3 = 0x19,
		CZM_E7_Zealot4 = 0x1A,
		CZM_E7_Zealot5 = 0x1B,
		CZM_E7_Zealot6 = 0x1C,
		CZM_E7_Saddler_SW =0x3F,
		CZM_E7_VillagerSW =0x44, //SW = the Separate Ways mode.
		CZM_E7_VillagerSW2 =0x42,
		CZM_E7_SoldierSW =0x43,
	};
}
namespace CZM_EESTM {
	/// Misc enemy sub-types, used by CzmRE4Enemy::type_101.v.
	enum{
		CZM_E8_CaptainJJ = 0x02,  //[1D,02] J.J. aka. beret guy with M.G.
		CZM_E8_SuperSalvador = 0x16, //[20,16]
		CZM_E8_RegularGarradorWith1B = 0x0A,   //[1B,0A]
		CZM_E8_RegularGarradorWith1C = 0x0D,   //[1C,0D]
		CZM_E8_ArmoredGarradorWith1C = 0x02,   //[1C,02]
	};
}

/// Weapon|damage types.
enum class CZM_EWT : uint8_t {
	CZM_E3_Punisher = 0x01,
	CZM_E3_Handgun = 0x02,
	CZM_E3_Red9 = 0x03,
	CZM_E3_Blacktail = 0x04,   // Leon or Ada
	CZM_E3_Matilda = 0x11,
	CZM_E3_TMP = 0x0B,   //with or w/o the stock.
	// Kick. As Leon or Ada.
	// * Leon. roundhouse kick (thai style).
	// * Leon. turnaround kick (on kneeling enemy).
	// * Ada jump-in kick.
	// * Ada turnaround kick (on kneeling enemy).
	// * ...
	CZM_E3_Kick = 0x14,
	CZM_E3_Knife = 0x10,  //Leon or Ada.
	CZM_E3_ChicagoTypewriter = 0x0C,  //Chicago Typewriter aka. Tommy Gun.
	CZM_E3_RocketLauncher = 0x12,   //single load
	CZM_E3_RiffleSemiauto = 0x0A,  //Sniper Riffle (military style)
	CZM_E3_HuntingRiffle = 0x09, // Riffle (hunting style, with or w/o the scope.)
	CZM_E3_BrokenButterfly = 0x05,
	CZM_E3_Killer7 = 0x06,
	CZM_E3_Handcannon = 0x0F,
	CZM_E3_MineThrower = 0x0E,   //the projectile shot, ie. not the explosion.
	CZM_E3_Shotgun = 0x07,  //base shotgun
	CZM_E3_Striker = 0x08,
	CZM_E3_RiotGun = 0x21,
	// Explosion damage type.
	// Incl. red explosive barrels, Mine Thrower grenade explosion,
	// Frag Grenade explosion.
	CZM_E3_Explosion = 0x13,
	CZM_E3_FlashGrenade = 0x17, //does 0 damage
	//...
};
/// Weapon group types.
enum class CZM_EWGR : int {
	CZM_E5_Pistols = 1,  /// Eg. \ref CZM_E3_Punisher.
	CZM_E5_Shotguns,
	CZM_E5_Rifles,
	CZM_E5_Magnums,
	CZM_E5_Mele,
	CZM_E5_Explosives,
	CZM_E5_CheatWeapons,
};

